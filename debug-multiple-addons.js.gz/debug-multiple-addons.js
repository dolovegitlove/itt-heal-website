/**
 * Debug Multiple Add-ons
 * Tests what happens when multiple add-ons are selected and submitted
 */

const { chromium } = require('playwright');

async function debugMultipleAddons() {
    console.log('🔍 Debug Multiple Add-ons Issue');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check available add-ons
        const availableAddons = await page.locator('#editAddonsContainer input[name="addons[]"]').count();
        console.log(`📋 Available add-ons: ${availableAddons}`);

        if (availableAddons >= 2) {
            console.log('✅ Selecting multiple add-ons...');
            
            // Select first two add-ons
            await page.locator('#editAddonsContainer input[name="addons[]"]').nth(0).check();
            await page.waitForTimeout(500);
            await page.locator('#editAddonsContainer input[name="addons[]"]').nth(1).check();
            await page.waitForTimeout(500);
            
            // Get add-on details
            const addon1Value = await page.locator('#editAddonsContainer input[name="addons[]"]').nth(0).getAttribute('value');
            const addon2Value = await page.locator('#editAddonsContainer input[name="addons[]"]').nth(1).getAttribute('value');
            console.log(`📋 Selected add-ons: ${addon1Value}, ${addon2Value}`);

            // Monitor the API request
            let apiRequestData = null;
            let apiResponseData = null;
            
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    const postData = request.postData();
                    if (postData) {
                        try {
                            apiRequestData = JSON.parse(postData);
                            console.log('\n📡 API REQUEST DATA:');
                            console.log('   - addons array length:', apiRequestData.addons?.length || 0);
                            console.log('   - addons content:', JSON.stringify(apiRequestData.addons, null, 2));
                            console.log('   - special_requests:', `"${apiRequestData.special_requests}"`);
                            
                            // Check if special_requests contains both add-ons
                            if (apiRequestData.special_requests) {
                                const hasAddon1 = apiRequestData.special_requests.includes(addon1Value) || 
                                                apiRequestData.special_requests.includes('Reflexology') ||
                                                apiRequestData.special_requests.includes('Aromatherapy');
                                const hasAddon2 = apiRequestData.special_requests.includes(addon2Value) ||
                                                apiRequestData.special_requests.includes('Hot Stones');
                                console.log('   - special_requests contains addon1:', hasAddon1);
                                console.log('   - special_requests contains addon2:', hasAddon2);
                            }
                        } catch (e) {
                            console.log('📡 API data (non-JSON):', postData.substring(0, 300));
                        }
                    }
                }
            });

            page.on('response', async response => {
                if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                    try {
                        apiResponseData = await response.json();
                        console.log('\n📡 API RESPONSE DATA:');
                        console.log('   - success:', apiResponseData.success);
                        if (apiResponseData.booking) {
                            console.log('   - returned special_requests:', `"${apiResponseData.booking.special_requests}"`);
                            
                            // Check if response contains both add-ons
                            if (apiResponseData.booking.special_requests) {
                                const responseHasAddon1 = apiResponseData.booking.special_requests.includes('Reflexology') ||
                                                        apiResponseData.booking.special_requests.includes('Aromatherapy');
                                const responseHasAddon2 = apiResponseData.booking.special_requests.includes('Hot Stones');
                                console.log('   - response contains addon1:', responseHasAddon1);
                                console.log('   - response contains addon2:', responseHasAddon2);
                            }
                        }
                    } catch (e) {
                        console.log('📡 Response parsing error:', e.message);
                    }
                }
            });

            console.log('💾 Submitting with multiple add-ons...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(4000);

            // Check final result
            console.log('🔍 Checking final booking state...');
            await page.waitForTimeout(2000);
            
            const updatedBookingText = await firstBooking.textContent();
            console.log('📋 Updated booking text:', updatedBookingText?.substring(0, 300));

            // Count add-ons in the display
            const addonMatches = updatedBookingText?.match(/\(\+\$\d+\)/g) || [];
            console.log(`📊 Add-ons shown in card: ${addonMatches.length}`);
            
            if (addonMatches.length > 0) {
                console.log('📋 Add-on price indicators found:', addonMatches);
            }

            // Re-open edit modal to verify persistence
            console.log('🔍 Re-opening edit modal to verify persistence...');
            await firstBooking.locator('.btn:has-text("Edit")').click();
            await page.waitForTimeout(2000);
            
            const finalCheckedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📋 Add-ons checked after save: ${finalCheckedAddons}`);

            // Analysis
            console.log('\n📊 ANALYSIS:');
            if (apiRequestData) {
                const sentMultipleAddons = apiRequestData.addons && apiRequestData.addons.length >= 2;
                console.log(`✅ Frontend sent multiple add-ons: ${sentMultipleAddons}`);
                
                const specialRequestsHasMultiple = apiRequestData.special_requests && 
                    (apiRequestData.special_requests.split(',').length >= 2 || 
                     apiRequestData.special_requests.split('(+$').length >= 3);
                console.log(`✅ special_requests contains multiple: ${specialRequestsHasMultiple}`);
            }
            
            if (apiResponseData) {
                const backendSavedMultiple = apiResponseData.booking?.special_requests &&
                    (apiResponseData.booking.special_requests.split(',').length >= 2 ||
                     apiResponseData.booking.special_requests.split('(+$').length >= 3);
                console.log(`❌ Backend saved multiple: ${backendSavedMultiple}`);
            }
            
            console.log(`❌ UI shows multiple add-ons: ${addonMatches.length >= 2}`);
            console.log(`❌ Form shows multiple checked: ${finalCheckedAddons >= 2}`);

        } else {
            console.log('❌ Not enough add-ons available to test multiple selection');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Debug failed:', error.message);
        await page.screenshot({ path: 'debug-multiple-addons-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    debugMultipleAddons().catch(error => {
        console.error('💥 Debug execution failed:', error);
        process.exit(1);
    });
}

module.exports = { debugMultipleAddons };