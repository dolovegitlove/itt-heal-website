const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false, slowMo: 800 });
  const page = await browser.newPage();
  
  // Listen for console logs and errors
  page.on('console', msg => {
    if (msg.type() === 'error') {
      console.log('🔴 PAGE ERROR:', msg.text());
    } else if (msg.text().includes('delete') || msg.text().includes('Delete')) {
      console.log('🗑️ DELETE LOG:', msg.text());
    }
  });
  
  page.on('pageerror', error => console.log('💥 PAGE EXCEPTION:', error.message));
  
  try {
    console.log('🔍 COMPREHENSIVE DELETE FUNCTIONALITY TEST');
    console.log('📋 Testing why delete booking button is not working');
    
    await page.goto('https://ittheal.com/admin.html');
    await page.waitForTimeout(3000);
    
    // Navigate to bookings
    await page.locator('[data-section="bookings"]').click();
    await page.waitForTimeout(3000); // Wait longer for data to load
    
    console.log('✅ Navigated to bookings section');
    
    // Check if booking cards loaded
    const cardCount = await page.locator('.booking-card').count();
    console.log(`📋 Found ${cardCount} booking cards`);
    
    if (cardCount > 0) {
      // Get booking details for verification
      const firstCard = page.locator('.booking-card').first();
      const clientName = await firstCard.locator('.booking-client').textContent();
      console.log(`👤 First booking client: ${clientName}`);
      
      // Check if delete button exists in the card
      const deleteButtonExists = await firstCard.locator('button:has-text("Delete")').count() > 0;
      console.log(`🗑️ Delete button exists: ${deleteButtonExists ? 'YES' : 'NO'}`);
      
      if (deleteButtonExists) {
        // Check button properties
        const deleteButton = firstCard.locator('button:has-text("Delete")');
        const isVisible = await deleteButton.isVisible();
        const isEnabled = await deleteButton.isEnabled();
        const onclick = await deleteButton.getAttribute('onclick');
        
        console.log(`👁️ Delete button visible: ${isVisible}`);
        console.log(`✋ Delete button enabled: ${isEnabled}`);
        console.log(`🎯 Delete button onclick: ${onclick}`);
        
        // Test the delete function manually
        console.log('\n🧪 Testing delete function directly:');
        
        // Set up dialog handler before triggering delete
        let dialogAppeared = false;
        page.on('dialog', async dialog => {
          dialogAppeared = true;
          console.log(`✅ Confirmation dialog appeared: "${dialog.message()}"`);
          await dialog.dismiss(); // Cancel to avoid actual deletion in test
        });
        
        // Execute delete function via JavaScript
        const deleteResult = await page.evaluate((onclickAttr) => {
          try {
            if (onclickAttr) {
              // Extract booking ID from onclick
              const match = onclickAttr.match(/deleteBooking\\('([^']*)'\\)/);
              if (match) {
                const bookingId = match[1];
                console.log('Calling deleteBooking with ID:', bookingId);
                
                // Call the function directly
                if (typeof deleteBooking === 'function') {
                  deleteBooking(bookingId);
                  return 'Delete function called successfully';
                } else {
                  return 'deleteBooking function not found';
                }
              } else {
                return 'Could not extract booking ID from onclick';
              }
            } else {
              return 'No onclick attribute found';
            }
          } catch (error) {
            return 'Error calling delete function: ' + error.message;
          }
        }, onclick);
        
        console.log(`🎯 Delete function result: ${deleteResult}`);
        
        // Wait to see if dialog appeared
        await page.waitForTimeout(2000);
        console.log(`📋 Confirmation dialog appeared: ${dialogAppeared ? 'YES' : 'NO'}`);
        
        // Also test direct button click
        console.log('\n🖱️ Testing direct button click:');
        try {
          // Force click with JavaScript
          await page.evaluate(() => {
            const deleteBtn = document.querySelector('.booking-card button[onclick*="deleteBooking"]');
            if (deleteBtn) {
              deleteBtn.click();
              return 'Button clicked';
            } else {
              return 'Button not found';
            }
          });
          
          await page.waitForTimeout(1000);
          console.log('✅ Direct button click executed');
          
        } catch (clickError) {
          console.log(`❌ Direct click failed: ${clickError.message}`);
        }
        
      } else {
        console.log('❌ Delete button not found in booking card');
        
        // Check the card HTML structure
        const cardHTML = await firstCard.innerHTML();
        console.log('\n📄 Card HTML structure:');
        console.log(cardHTML.substring(0, 500) + '...');
      }
      
    } else {
      console.log('❌ No booking cards found - data may not be loading');
      
      // Check if there's a loading state or error
      const loadingElement = await page.locator('.loading').count();
      const errorElement = await page.locator('.alert-error').count();
      
      console.log(`⏳ Loading elements: ${loadingElement}`);
      console.log(`🚨 Error elements: ${errorElement}`);
    }
    
    // Test the API directly from the browser
    console.log('\n🌐 Testing API from browser:');
    const apiTest = await page.evaluate(async () => {
      try {
        const response = await fetch('/api/admin/bookings', {
          headers: { 'x-admin-access': 'dr-shiffer-emergency-access' }
        });
        
        if (response.ok) {
          const data = await response.json();
          return `API working - ${data.count} bookings found`;
        } else {
          return `API error - ${response.status}`;
        }
      } catch (error) {
        return `API exception - ${error.message}`;
      }
    });
    
    console.log(`🔗 API test result: ${apiTest}`);
    
    console.log('\n🎉 DELETE FUNCTIONALITY DIAGNOSIS COMPLETE');
    console.log('📋 Check the logs above to identify the issue');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await browser.close();
  }
})();