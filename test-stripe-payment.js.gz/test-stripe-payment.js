const { chromium } = require('playwright');

(async () => {
  console.log('🔍 STRIPE INTEGRATION TEST - Payment Step Focus');
  console.log('=======================================================');
  
  const browser = await chromium.launch({
    headless: false,           // Show real browser
    slowMo: 500,              // Human-speed interactions
    args: [
      '--window-size=1920,1080',
      '--no-sandbox',
      '--disable-setuid-sandbox'
    ]
  });

  const page = await browser.newPage();
  
  try {
    console.log('📊 Loading ITT website...');
    await page.goto('https://ittheal.com');
    await page.waitForLoadState('networkidle');
    
    // Complete booking flow to payment step
    console.log('\n🎯 STEP 1: Navigate to payment step');
    await page.locator('[data-service="90min"]').click();
    await page.locator('#next-btn').click();
    await page.waitForTimeout(2000);
    
    // Enter date
    await page.locator('#booking-date').click();
    await page.keyboard.press('Control+a');
    await page.keyboard.type('2025-07-14');
    await page.keyboard.press('Tab');
    await page.waitForTimeout(4000);
    
    // Select time
    await page.locator('#booking-time').click();
    await page.waitForTimeout(1000);
    const firstOption = page.locator('#booking-time option:not([value=""])').first();
    await firstOption.click();
    await page.waitForTimeout(1000);
    
    await page.locator('#next-btn').click();
    await page.waitForTimeout(2000);
    
    // Enter contact info
    await page.locator('#client-name').click();
    await page.keyboard.type('Stripe Test User');
    await page.locator('#client-email').click();
    await page.keyboard.type('stripetest@test.com');
    await page.locator('#client-phone').click();
    await page.keyboard.type('555-123-4567');
    
    await page.locator('#next-btn').click();
    await page.waitForTimeout(3000);
    
    console.log('\n💳 STEP 2: Analyze Payment Step');
    
    // Check if payment step is visible
    const paymentVisible = await page.locator('#payment-info').isVisible();
    console.log(`   📊 Payment step visible: ${paymentVisible}`);
    
    if (!paymentVisible) {
      const currentStep = await page.locator('.step.active').getAttribute('id');
      console.log(`   ❌ Current step: ${currentStep}`);
      throw new Error('Payment step not reached');
    }
    
    // Check Stripe script loading
    const stripeLoaded = await page.evaluate(() => {
      return typeof window.Stripe !== 'undefined';
    });
    console.log(`   📊 Stripe script loaded: ${stripeLoaded}`);
    
    // Check Stripe elements container
    const stripeContainer = await page.locator('#stripe-card-element').isVisible();
    console.log(`   📊 Stripe card element container: ${stripeContainer}`);
    
    // Check if Stripe element is initialized
    const stripeElementExists = await page.evaluate(() => {
      const container = document.getElementById('stripe-card-element');
      return container && container.children.length > 0;
    });
    console.log(`   📊 Stripe element initialized: ${stripeElementExists}`);
    
    // Check for Stripe errors
    const stripeErrors = await page.locator('#stripe-card-errors').textContent();
    console.log(`   📊 Stripe errors: "${stripeErrors}"`);
    
    // Check payment method selection
    const creditCardSelected = await page.locator('#payment-method-card').isChecked();
    console.log(`   📊 Credit card payment selected: ${creditCardSelected}`);
    
    // Check total price display
    const totalPrice = await page.locator('#payment-total-price').textContent();
    console.log(`   📊 Total price displayed: ${totalPrice}`);
    
    console.log('\n🔍 STRIPE INITIALIZATION DETAILS:');
    
    // Get detailed Stripe initialization status
    const stripeDetails = await page.evaluate(() => {
      const details = {};
      
      // Check Stripe global
      details.stripeGlobal = typeof window.Stripe;
      
      // Check if our Stripe instance exists
      details.stripeInstance = window.stripe ? 'initialized' : 'not found';
      
      // Check elements
      details.elementsInstance = window.elements ? 'initialized' : 'not found';
      
      // Check card element
      details.cardElement = window.cardElement ? 'initialized' : 'not found';
      
      // Check container content
      const container = document.getElementById('stripe-card-element');
      details.containerHTML = container ? container.innerHTML : 'container not found';
      
      return details;
    });
    
    console.log('   Stripe Details:', JSON.stringify(stripeDetails, null, 2));
    
    if (!stripeElementExists) {
      console.log('\n🔧 ATTEMPTING STRIPE INITIALIZATION...');
      
      // Try to trigger Stripe initialization manually
      await page.evaluate(() => {
        if (typeof initializeStripeElements === 'function') {
          initializeStripeElements();
        }
      });
      
      await page.waitForTimeout(2000);
      
      const afterInit = await page.evaluate(() => {
        const container = document.getElementById('stripe-card-element');
        return container && container.children.length > 0;
      });
      
      console.log(`   📊 After manual init: ${afterInit}`);
    }
    
    console.log('\n✅ STRIPE INTEGRATION ANALYSIS COMPLETE');
    
    await page.waitForTimeout(30000); // Keep open for inspection
    
  } catch (error) {
    console.error('\n❌ STRIPE TEST FAILED:', error.message);
    await page.screenshot({ path: 'stripe-integration-failure.png', fullPage: true });
    await page.waitForTimeout(60000);
  } finally {
    await browser.close();
  }
})().catch(console.error);