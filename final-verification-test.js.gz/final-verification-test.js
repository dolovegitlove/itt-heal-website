/**
 * Final Verification Test
 * Simple verification that both fixes are working
 */

const { chromium } = require('playwright');

async function finalVerificationTest() {
    console.log('✅ Final Verification - Both Fixes Working');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check 1: Multiple add-ons restoration working
        const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
        console.log(`📊 Add-ons automatically restored: ${checkedAddons}`);
        
        const multipleAddonsWorking = checkedAddons >= 2;
        console.log(`✅ Multiple add-ons restoration: ${multipleAddonsWorking ? 'WORKING' : 'FAILED'}`);

        // Check 2: Loading state management
        console.log('⏳ Testing loading state...');
        
        let loadingDetected = false;
        let buttonStateNormal = false;
        
        // Monitor button changes
        const submitButton = page.locator('#editBookingForm button[type="submit"]');
        const originalText = await submitButton.textContent();
        
        page.on('console', msg => {
            if (msg.text().includes('Restored addon in edit form')) {
                console.log('✅ Add-on restoration working:', msg.text());
            }
        });

        // Make a small change to trigger submit
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.press('End');
        await page.keyboard.type(' TEST');

        console.log('💾 Submitting edit...');
        await submitButton.click();
        
        // Check for loading state
        await page.waitForTimeout(500);
        const buttonTextDuringSubmit = await submitButton.textContent();
        loadingDetected = buttonTextDuringSubmit?.includes('Updating...');
        
        console.log(`📊 Loading state detected: ${loadingDetected ? '✅' : '❌'} ("${buttonTextDuringSubmit}")`);
        
        // Wait for completion
        await page.waitForTimeout(3000);
        
        // Check if button returned to normal
        const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
        buttonStateNormal = modalClosed;
        
        console.log(`📊 Modal closed properly: ${buttonStateNormal ? '✅' : '❌'}`);

        // Final results
        console.log('\n📊 Final Verification Results:');
        console.log(`✅ Multiple Add-ons Restoration: ${multipleAddonsWorking ? 'WORKING' : 'FAILED'}`);
        console.log(`✅ Loading State Management: ${(loadingDetected && buttonStateNormal) ? 'WORKING' : 'FAILED'}`);
        
        const allWorking = multipleAddonsWorking && loadingDetected && buttonStateNormal;
        console.log(`\n🎯 OVERALL STATUS: ${allWorking ? '✅ ALL FIXES WORKING' : '❌ SOME ISSUES REMAIN'}`);

        if (allWorking) {
            console.log('\n🎉 SUCCESS! Both issues have been resolved:');
            console.log('   1. ✅ Loading circle no longer gets stuck');
            console.log('   2. ✅ Multiple add-ons are properly saved and restored');
            console.log('   3. ✅ Edit functionality is working correctly');
            console.log('\nYou can now edit bookings without issues!');
        }

        await page.waitForTimeout(2000);

    } catch (error) {
        console.error('❌ Verification failed:', error.message);
        await page.screenshot({ path: 'final-verification-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    finalVerificationTest().catch(error => {
        console.error('💥 Verification execution failed:', error);
        process.exit(1);
    });
}

module.exports = { finalVerificationTest };