/**
 * Debug Add-on Persistence - Check actual database state
 */
const { chromium } = require('playwright');

async function debugAddonPersistence() {
    console.log('🔍 Debugging Add-on Persistence Issue');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        // Enable console logging to see frontend logs
        page.on('console', msg => {
            if (msg.text().includes('add-on') || msg.text().includes('Add-on') || msg.text().includes('special_requests')) {
                console.log(`🌐 Frontend: ${msg.text()}`);
            }
        });
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        // Wait for bookings to load
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        // Check if we have bookings
        const bookingsExist = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingsExist} bookings`);
        
        if (bookingsExist === 0) {
            console.log('⚠️ No bookings found. Let me create a test booking with add-ons...');
            
            // Create a booking with add-ons for testing
            await page.locator('button:has-text("Create Booking")').click();
            await page.waitForSelector('#createBookingModal.active', { timeout: 5000 });
            
            // Fill in basic booking info
            await page.locator('#clientName').fill('Test Addon User');
            await page.locator('#clientEmail').fill('test@addon.com');
            await page.locator('#clientPhone').fill('555-123-4567');
            await page.locator('#serviceType').selectOption('60min');
            await page.locator('#scheduledDate').fill('2025-07-15T14:00');
            
            // Add some add-ons
            const addonCheckboxes = await page.locator('#addonsContainer input[type="checkbox"]');
            const addonCount = await addonCheckboxes.count();
            if (addonCount > 0) {
                await addonCheckboxes.first().check();
                console.log('✅ Added addon to test booking');
            }
            
            // Submit the form
            await page.locator('#createBookingForm button[type="submit"]').click();
            await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
            
            // Wait for booking to appear
            await page.waitForTimeout(2000);
            await page.waitForSelector('.booking-card', { timeout: 10000 });
            
            console.log('✅ Test booking created with add-ons');
        }
        
        // Get the first booking
        const firstBooking = await page.locator('.booking-card').first();
        
        // Get booking ID if possible
        const bookingId = await firstBooking.getAttribute('data-booking-id') || 'unknown';
        console.log(`📋 Testing booking ID: ${bookingId}`);
        
        console.log('\n📝 STEP 1: Opening edit form...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check what add-ons are currently checked
        const checkedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        console.log(`📊 Current add-ons checked: ${checkedAddons}`);
        
        // Get the current special requests value
        const specialRequestsInput = page.locator('#editSpecialRequests');
        const originalSpecialRequests = await specialRequestsInput.inputValue();
        console.log(`📋 Original special requests: "${originalSpecialRequests}"`);
        
        if (checkedAddons > 0) {
            console.log('\n🔲 STEP 2: Unchecking all add-ons...');
            
            // Uncheck all add-ons
            const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
            const count = await checkboxes.count();
            for (let i = 0; i < count; i++) {
                await checkboxes.nth(0).click();
                await page.waitForTimeout(200);
            }
            
            const remainingChecked = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
            console.log(`📊 Add-ons checked after removal: ${remainingChecked}`);
            
            // Check what special requests shows now
            const clearedSpecialRequests = await specialRequestsInput.inputValue();
            console.log(`📋 Special requests after unchecking: "${clearedSpecialRequests}"`);
        }
        
        console.log('\n💾 STEP 3: Saving changes...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        console.log('✅ Save completed');
        
        // Wait for modal to close
        await page.waitForTimeout(2000);
        
        console.log('\n🔄 STEP 4: Re-opening to verify persistence...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check add-ons state after reopening
        const finalCheckedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const finalSpecialRequests = await specialRequestsInput.inputValue();
        
        console.log(`📊 Final add-ons checked: ${finalCheckedAddons}`);
        console.log(`📋 Final special requests: "${finalSpecialRequests}"`);
        
        // Analysis
        console.log('\n📊 ANALYSIS:');
        console.log(`Original add-ons: ${checkedAddons}`);
        console.log(`Expected add-ons: 0`);
        console.log(`Actual add-ons: ${finalCheckedAddons}`);
        console.log(`Special requests contains "Add-ons:": ${finalSpecialRequests.includes('Add-ons:')}`);
        
        if (finalCheckedAddons === 0 && !finalSpecialRequests.includes('Add-ons:')) {
            console.log('\n✅ SUCCESS: Add-ons were properly removed and not restored!');
        } else {
            console.log('\n❌ ISSUE: Add-ons are still present after save/reload');
            console.log('This indicates the persistence bug is still occurring');
        }
        
    } catch (error) {
        console.error('❌ Debug failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the debug
debugAddonPersistence();