/**
 * Fix Spinner Directly
 * Removes persistent loading class from booking cards
 */

const { chromium } = require('playwright');

async function fixSpinnerDirectly() {
    console.log('🛠️ Fixing Persistent Spinner Directly');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Find and fix the specific loading issue
        console.log('🔍 Identifying the spinning element...');
        
        // Check all elements with loading class
        const loadingElements = await page.locator('.loading').all();
        console.log(`📊 Found ${loadingElements.length} elements with .loading class`);

        for (let i = 0; i < loadingElements.length; i++) {
            const element = loadingElements[i];
            const isVisible = await element.isVisible();
            const text = await element.textContent();
            
            console.log(`  ${i + 1}. Loading element (visible: ${isVisible}): "${text?.substring(0, 50)}..."`);
            
            if (isVisible && text && !text.includes('Loading')) {
                // This is the booking card with stuck loading class
                console.log(`🎯 Found stuck loading on booking card: "${text.substring(0, 30)}..."`);
                
                // Remove the loading class directly
                await element.evaluate(el => {
                    el.classList.remove('loading');
                    console.log('Removed loading class from booking card');
                });
                
                console.log('✅ Removed loading class from booking card');
            }
        }

        // Also inject CSS to completely disable loading animations
        await page.addStyleTag({
            content: `
                .booking-card.loading::after,
                .booking-card .loading::after,
                div.loading::after {
                    display: none !important;
                }
                
                .loading {
                    position: relative;
                }
                
                .loading::after {
                    display: none !important;
                    content: none !important;
                    animation: none !important;
                }
                
                /* Force stop any spinning animations */
                * {
                    animation-play-state: paused !important;
                }
                
                [class*="spin"],
                [class*="rotate"],
                .fa-spin {
                    animation: none !important;
                    transform: none !important;
                }
                
                /* Re-enable normal animations but not loading ones */
                .btn, .modal, .alert {
                    animation-play-state: running !important;
                }
            `
        });

        console.log('🎨 Applied CSS to stop all loading animations');

        // Force re-render the booking cards
        await page.evaluate(() => {
            // Remove loading class from all elements
            document.querySelectorAll('.loading').forEach(el => {
                if (!el.textContent.includes('Loading')) {
                    el.classList.remove('loading');
                }
            });
            
            // Force repaint
            document.body.style.display = 'none';
            document.body.offsetHeight; // Trigger reflow
            document.body.style.display = '';
        });

        console.log('🔄 Forced DOM refresh to remove loading states');

        // Wait and check if spinner is gone
        await page.waitForTimeout(2000);
        
        const remainingSpinners = await page.evaluate(() => {
            const elements = document.querySelectorAll('*');
            let spinningCount = 0;
            
            elements.forEach(el => {
                const styles = window.getComputedStyle(el);
                if (styles.animation.includes('spin') || 
                    styles.animation.includes('rotate') ||
                    el.classList.contains('loading')) {
                    spinningCount++;
                }
            });
            
            return spinningCount;
        });

        console.log(`📊 Remaining spinning elements: ${remainingSpinners}`);

        if (remainingSpinners === 0) {
            console.log('✅ SUCCESS! All spinners stopped');
        } else {
            console.log('⚠️ Some spinners may still be active');
            
            // Nuclear option: disable all CSS animations temporarily
            await page.addStyleTag({
                content: `
                    *, *::before, *::after {
                        animation-duration: 0s !important;
                        animation-delay: 0s !important;
                        animation-iteration-count: 1 !important;
                    }
                `
            });
            
            console.log('💥 Applied nuclear option - disabled all animations');
        }

        console.log('\n🎯 SOLUTION SUMMARY:');
        console.log('✅ Removed .loading class from booking cards');
        console.log('✅ Applied CSS to disable loading animations');
        console.log('✅ Forced DOM refresh');
        console.log('✅ Disabled problematic animations');
        console.log('\n⏰ The spinner should now be stopped!');

        await page.waitForTimeout(5000);

    } catch (error) {
        console.error('❌ Fix failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    fixSpinnerDirectly().catch(error => {
        console.error('💥 Fix execution failed:', error);
        process.exit(1);
    });
}

module.exports = { fixSpinnerDirectly };