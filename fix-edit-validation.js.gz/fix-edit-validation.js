/**
 * Fix Edit Form Validation Issues
 * Identifies and fixes form validation problems preventing submission
 */

const { chromium } = require('playwright');

async function fixEditValidation() {
    console.log('🔧 Fixing Edit Form Validation Issues');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Click edit button
        console.log('✏️ Opening edit modal...');
        const editButton = page.locator('.booking-card .btn:has-text("Edit")').first();
        await editButton.click();
        await page.waitForTimeout(2000);

        // Wait for modal
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Analyze validation issues
        console.log('🔍 Analyzing form validation...');
        
        const validationAnalysis = await page.evaluate(() => {
            const form = document.getElementById('editBookingForm');
            if (!form) return { error: 'Form not found' };
            
            // Find all required fields
            const requiredFields = Array.from(form.querySelectorAll('[required]'));
            const invalidFields = [];
            const emptyFields = [];
            
            requiredFields.forEach(field => {
                const isValid = field.checkValidity();
                const isEmpty = !field.value || field.value.trim() === '';
                
                invalidFields.push({
                    id: field.id || field.name || 'unknown',
                    type: field.type || field.tagName.toLowerCase(),
                    value: field.value,
                    isValid,
                    isEmpty,
                    validationMessage: field.validationMessage
                });
                
                if (isEmpty) {
                    emptyFields.push(field.id || field.name || 'unknown');
                }
            });
            
            return {
                totalRequired: requiredFields.length,
                invalidFields,
                emptyFields,
                formValid: form.checkValidity()
            };
        });
        
        console.log('📊 Validation Analysis:');
        console.log(`Total required fields: ${validationAnalysis.totalRequired}`);
        console.log(`Form is valid: ${validationAnalysis.formValid}`);
        console.log(`Empty required fields: ${validationAnalysis.emptyFields.join(', ')}`);
        
        // Show details of invalid fields
        if (validationAnalysis.invalidFields) {
            console.log('\n📋 Required Field Details:');
            validationAnalysis.invalidFields.forEach((field, index) => {
                console.log(`${index + 1}. ${field.id}: ${field.isEmpty ? 'EMPTY' : 'HAS_VALUE'} (${field.type})`);
                if (field.validationMessage) {
                    console.log(`   Validation: ${field.validationMessage}`);
                }
            });
        }

        // Fill in missing required fields with reasonable defaults
        console.log('\n🔧 Filling missing required fields...');
        
        await page.evaluate(() => {
            // Fill empty required fields with defaults
            const form = document.getElementById('editBookingForm');
            const requiredFields = Array.from(form.querySelectorAll('[required]'));
            
            requiredFields.forEach(field => {
                if (!field.value || field.value.trim() === '') {
                    console.log(`Filling empty required field: ${field.id}`);
                    
                    switch (field.type || field.tagName.toLowerCase()) {
                        case 'email':
                            field.value = 'test@example.com';
                            break;
                        case 'tel':
                        case 'phone':
                            field.value = '555-0123';
                            break;
                        case 'datetime-local':
                            // Set to tomorrow at 10 AM
                            const tomorrow = new Date();
                            tomorrow.setDate(tomorrow.getDate() + 1);
                            tomorrow.setHours(10, 0, 0, 0);
                            field.value = tomorrow.toISOString().slice(0, 16);
                            break;
                        case 'select':
                        case 'select-one':
                            if (field.options && field.options.length > 1) {
                                field.selectedIndex = 1; // Select first non-empty option
                            }
                            break;
                        case 'number':
                            field.value = '0';
                            break;
                        case 'text':
                        default:
                            if (field.id.includes('name') || field.id.includes('Name')) {
                                field.value = 'Test Name';
                            } else {
                                field.value = 'Test Value';
                            }
                            break;
                    }
                    
                    // Trigger change event
                    field.dispatchEvent(new Event('change', { bubbles: true }));
                }
            });
        });
        
        await page.waitForTimeout(1000);

        // Check validation again
        console.log('\n🔍 Checking validation after filling fields...');
        
        const postFillValidation = await page.evaluate(() => {
            const form = document.getElementById('editBookingForm');
            return {
                formValid: form.checkValidity(),
                invalidCount: Array.from(form.querySelectorAll(':invalid')).length
            };
        });
        
        console.log(`Form valid after filling: ${postFillValidation.formValid}`);
        console.log(`Invalid fields remaining: ${postFillValidation.invalidCount}`);

        // Try submission again
        if (postFillValidation.formValid) {
            console.log('✅ Form is now valid - attempting submission...');
            
            // Monitor network requests
            const networkRequests = [];
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    networkRequests.push({
                        url: request.url(),
                        method: request.method(),
                        postData: request.postData()
                    });
                    console.log('📡 PUT request detected:', request.url());
                }
            });
            
            page.on('response', response => {
                if (response.url().includes('/api/admin/bookings') && response.status() >= 200 && response.status() < 300) {
                    console.log('✅ Success response:', response.status());
                }
            });

            const submitButton = page.locator('#editBookingForm button[type="submit"]');
            await submitButton.click();
            
            await page.waitForTimeout(3000);
            
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            console.log('📋 Modal closed after submission:', modalClosed);
            
            if (networkRequests.length > 0) {
                console.log('📡 Network requests made:', networkRequests.length);
                networkRequests.forEach(req => {
                    console.log(`   ${req.method} ${req.url}`);
                });
            } else {
                console.log('❌ No network requests made - form submission still blocked');
            }
        } else {
            console.log('❌ Form still invalid after filling fields');
        }

        await page.screenshot({ path: 'fix-edit-validation.png', fullPage: true });
        console.log('📸 Screenshot saved');

    } catch (error) {
        console.error('❌ Fix attempt failed:', error.message);
        
        try {
            await page.screenshot({ path: 'fix-edit-validation-error.png', fullPage: true });
            console.log('📸 Error screenshot saved');
        } catch (e) {
            console.log('📸 Could not save screenshot');
        }
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    fixEditValidation().catch(error => {
        console.error('💥 Fix execution failed:', error);
        process.exit(1);
    });
}

module.exports = { fixEditValidation };