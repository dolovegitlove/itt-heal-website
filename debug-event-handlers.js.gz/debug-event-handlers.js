const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging event handlers on time select...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Track all console logs
  page.on('console', msg => console.log('PAGE:', msg.text()));
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  // Step 1: Service selection
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 2: Date selection
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  
  console.log('📅 Analyzing time select event handlers...');
  
  // Check what event listeners are attached
  const eventAnalysis = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    if (!timeSelect) return { error: 'Element not found' };
    
    // Check for any overlapping elements
    const rect = timeSelect.getBoundingClientRect();
    const centerX = rect.x + rect.width / 2;
    const centerY = rect.y + rect.height / 2;
    
    const elementsAtPoint = [];
    let currentElement = document.elementFromPoint(centerX, centerY);
    
    while (currentElement) {
      elementsAtPoint.push({
        tag: currentElement.tagName,
        id: currentElement.id,
        classes: Array.from(currentElement.classList),
        zIndex: getComputedStyle(currentElement).zIndex
      });
      
      // Move to parent
      currentElement = currentElement.parentElement;
      if (currentElement === document.body) break;
    }
    
    // Check if there are any click handlers on parent elements that might prevent bubbling
    const parentHandlers = [];
    let parent = timeSelect.parentElement;
    while (parent && parent !== document.body) {
      const hasClickHandler = parent.onclick !== null || 
                            parent.addEventListener !== undefined ||
                            parent.getAttribute('onclick') !== null;
      
      parentHandlers.push({
        tag: parent.tagName,
        id: parent.id,
        classes: Array.from(parent.classList),
        hasClickHandler: hasClickHandler,
        onclick: parent.onclick ? 'has onclick' : 'no onclick'
      });
      
      parent = parent.parentElement;
    }
    
    // Test if the select can actually change value
    const originalValue = timeSelect.value;
    timeSelect.value = '15:00';
    const changeWorked = timeSelect.value === '15:00';
    timeSelect.value = originalValue; // Reset
    
    return {
      timeSelectRect: rect,
      elementsAtPoint: elementsAtPoint,
      parentHandlers: parentHandlers,
      canChangeValue: changeWorked,
      currentValue: timeSelect.value,
      isDisabled: timeSelect.disabled,
      hasOnChange: timeSelect.onchange !== null,
      style: {
        pointerEvents: getComputedStyle(timeSelect).pointerEvents,
        userSelect: getComputedStyle(timeSelect).userSelect,
        zIndex: getComputedStyle(timeSelect).zIndex
      }
    };
  });
  
  console.log('📊 Event analysis:', JSON.stringify(eventAnalysis, null, 2));
  
  // Try to manually trigger events
  console.log('🎯 Testing manual event triggering...');
  
  const manualTest = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    if (!timeSelect) return { error: 'Element not found' };
    
    // Try to manually change value and trigger events
    const originalValue = timeSelect.value;
    
    // Change value
    timeSelect.value = '16:00';
    
    // Trigger change event
    const changeEvent = new Event('change', { bubbles: true });
    timeSelect.dispatchEvent(changeEvent);
    
    // Trigger input event
    const inputEvent = new Event('input', { bubbles: true });
    timeSelect.dispatchEvent(inputEvent);
    
    return {
      originalValue: originalValue,
      newValue: timeSelect.value,
      eventTriggered: true
    };
  });
  
  console.log('📋 Manual test result:', manualTest);
  
  await browser.close();
})().catch(console.error);