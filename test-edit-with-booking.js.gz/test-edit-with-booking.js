/**
 * Test Edit with Booking Creation
 * Creates a booking first, then tests edit functionality
 */

const { chromium } = require('playwright');

async function testEditWithBooking() {
    console.log('🧪 Testing Edit Functionality with Fresh Booking');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testResult = {
        bookingCreated: false,
        editModalOpened: false,
        editSubmitted: false,
        editSuccessful: false
    };

    try {
        // Step 1: Create a test booking
        console.log('📝 Creating test booking...');
        await page.goto('https://ittheal.com');
        await page.waitForTimeout(2000);

        // Navigate to booking section
        const bookBtn = page.locator('a[href="#booking"], .btn:has-text("Book")').first();
        await bookBtn.click();
        await page.waitForTimeout(1000);

        // Fill booking form
        console.log('📋 Filling booking form...');
        await page.locator('#clientName').fill('Test Edit Client');
        await page.locator('#clientEmail').fill('test-edit@example.com');
        await page.locator('#clientPhone').fill('555-0123');
        
        // Select service
        await page.locator('[data-service="60min"]').click();
        await page.waitForTimeout(500);
        
        // Select date (tomorrow)
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const dateStr = tomorrow.toISOString().split('T')[0];
        await page.locator('#appointmentDate').fill(dateStr);
        
        // Select time
        await page.locator('#appointmentTime').selectOption('10:00');
        
        // Submit booking
        console.log('💾 Submitting booking...');
        await page.locator('#bookingForm button[type="submit"]').click();
        await page.waitForTimeout(3000);
        
        // Check for success
        const successAlert = await page.locator('.alert-success').count();
        testResult.bookingCreated = successAlert > 0;
        console.log(`📊 Booking created: ${testResult.bookingCreated ? '✅' : '❌'}`);

        if (!testResult.bookingCreated) {
            throw new Error('Failed to create test booking');
        }

        // Step 2: Navigate to admin panel
        console.log('🔧 Navigating to admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        console.log('📋 Bookings loaded in admin panel');

        // Step 3: Test edit functionality
        console.log('✏️ Testing edit functionality...');
        
        // Find our test booking
        const testBooking = page.locator('.booking-card:has-text("Test Edit Client")');
        const editButton = testBooking.locator('.btn:has-text("Edit")');
        await editButton.click();
        await page.waitForTimeout(1000);

        // Check if modal opened
        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        testResult.editModalOpened = modalVisible;
        console.log(`📊 Edit modal opened: ${testResult.editModalOpened ? '✅' : '❌'}`);

        if (testResult.editModalOpened) {
            // Make edit
            console.log('📝 Making edit to client name...');
            const nameInput = page.locator('#editClientName');
            await nameInput.click();
            await nameInput.selectText();
            await page.keyboard.type('Test Edit Client MODIFIED');

            // Monitor API calls
            let apiCallMade = false;
            page.on('response', response => {
                if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                    apiCallMade = true;
                    console.log('✅ Edit API call successful');
                }
            });

            // Submit edit
            console.log('💾 Submitting edit...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);

            testResult.editSubmitted = true;
            testResult.editSuccessful = apiCallMade;

            // Check if modal closed
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            console.log(`📊 Edit submitted: ${testResult.editSubmitted ? '✅' : '❌'}`);
            console.log(`📊 API success: ${testResult.editSuccessful ? '✅' : '❌'}`);
            console.log(`📊 Modal closed: ${modalClosed ? '✅' : '❌'}`);
        }

        // Final results
        console.log('\n📊 Test Results Summary:');
        console.log(`✅ Booking Created: ${testResult.bookingCreated ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Modal Opened: ${testResult.editModalOpened ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Submitted: ${testResult.editSubmitted ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Successful: ${testResult.editSuccessful ? 'YES' : 'NO'}`);

        const overallSuccess = Object.values(testResult).every(result => result === true);
        console.log(`\n🎯 OVERALL RESULT: ${overallSuccess ? '✅ EDIT WORKING' : '❌ EDIT BROKEN'}`);

        if (overallSuccess) {
            console.log('\n🎉 EDIT FUNCTIONALITY IS WORKING CORRECTLY!');
        } else {
            console.log('\n❌ EDIT FUNCTIONALITY HAS ISSUES - Details above');
        }

        await page.waitForTimeout(5000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'test-edit-error.png', fullPage: true });
    } finally {
        await browser.close();
    }

    return testResult;
}

if (require.main === module) {
    testEditWithBooking().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testEditWithBooking };