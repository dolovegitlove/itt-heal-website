/**
 * Screenshot Admin Panel - See exactly what's displayed
 */
const { chromium } = require('playwright');

async function screenshotAdminPanel() {
    console.log('📸 Taking Screenshots of Admin Panel');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        console.log('📸 Taking screenshot of initial state...');
        await page.screenshot({ path: 'admin-initial.png', fullPage: true });
        
        console.log('🖱️ Clicking on Bookings Management...');
        const bookingsNav = page.locator('[data-section="bookings"]');
        await bookingsNav.click();
        await page.waitForTimeout(2000);
        
        console.log('📸 Taking screenshot after clicking bookings...');
        await page.screenshot({ path: 'admin-bookings.png', fullPage: true });
        
        // Check what's in the bookings section
        const bookingsContent = await page.locator('#bookings').innerHTML();
        console.log('📋 Bookings section content:');
        console.log(bookingsContent.substring(0, 500) + '...');
        
        // Look for any create buttons
        const createButtons = await page.locator('button').all();
        console.log('\n🔍 All buttons currently visible:');
        
        for (let i = 0; i < createButtons.length; i++) {
            const button = createButtons[i];
            const text = await button.textContent();
            const isVisible = await button.isVisible();
            const onclick = await button.getAttribute('onclick');
            
            if (isVisible) {
                console.log(`  ${i + 1}. VISIBLE: "${text.trim()}" ${onclick ? `onclick="${onclick}"` : ''}`);
            }
        }
        
        // Check if there's any JavaScript errors
        page.on('console', msg => {
            if (msg.type() === 'error') {
                console.log('🔴 JavaScript Error:', msg.text());
            }
        });
        
        console.log('\n📸 Screenshots saved:');
        console.log('  - admin-initial.png (initial state)');
        console.log('  - admin-bookings.png (after clicking bookings)');
        
        console.log('\n⏰ Keeping browser open for 15 seconds so you can inspect...');
        await page.waitForTimeout(15000);
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the screenshot test
screenshotAdminPanel();