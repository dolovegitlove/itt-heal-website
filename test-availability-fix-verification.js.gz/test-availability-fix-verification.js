/**
 * AVAILABILITY FIX VERIFICATION TEST
 * Tests that the availability loading fix works correctly
 * Tests both closed days and open days
 */

const { chromium } = require('playwright');

async function testAvailabilityFixVerification() {
    console.log('🚀 Starting Availability Fix Verification Test...');
    console.log('🔧 TESTING: Fixed availability loading with proper error handling');
    console.log('🌐 USING: Live backend at https://ittheal.com\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-web-security'
        ]
    });

    const page = await browser.newPage();
    
    let testResults = [];
    
    try {
        // Test 1: Closed Day (Tuesday) - Should show helpful error
        console.log('='.repeat(50));
        console.log('TEST 1: CLOSED DAY ERROR HANDLING');
        console.log('='.repeat(50));
        
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(2000);
        
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        console.log('📍 Select 60-minute service...');
        await page.locator('.service-option[data-service="60min"]').click();
        await page.waitForTimeout(1000);
        
        console.log('📍 Click Next...');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(2000);
        
        console.log('📍 Enter closed day (Tuesday)...');
        const dateInput = page.locator('#booking-date');
        await dateInput.click();
        await page.waitForTimeout(300);
        
        await page.keyboard.press('Control+a');
        await page.waitForTimeout(100);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(100);
        
        // Enter Tuesday July 29, 2025 (closed day)
        await page.keyboard.type('2025-07-29');
        await page.waitForTimeout(500);
        await page.keyboard.press('Tab');
        
        console.log('📍 Wait for error handling...');
        await page.waitForTimeout(5000);
        
        // Check for proper error message
        const errorMessage = await page.locator('#time-loading').textContent();
        const timeSelectDisabled = await page.locator('#booking-time').getAttribute('disabled');
        const suggestButton = await page.locator('button:has-text("Suggest Next Available Date")').isVisible();
        
        console.log(`   Error message shown: ${errorMessage?.includes('Closed Day') ? '✅' : '❌'}`);
        console.log(`   Time select disabled: ${timeSelectDisabled !== null ? '✅' : '❌'}`);
        console.log(`   Suggest button visible: ${suggestButton ? '✅' : '❌'}`);
        
        testResults.push({
            test: 'Closed Day Error Handling',
            errorShown: errorMessage?.includes('Closed Day'),
            selectDisabled: timeSelectDisabled !== null,
            suggestButtonVisible: suggestButton,
            status: errorMessage?.includes('Closed Day') && timeSelectDisabled !== null ? 'PASS' : 'FAIL'
        });
        
        // Test the suggest button
        if (suggestButton) {
            console.log('📍 Test suggest button...');
            await page.locator('button:has-text("Suggest Next Available Date")').click();
            await page.waitForTimeout(3000);
            
            const newDate = await dateInput.inputValue();
            console.log(`   Suggested date: ${newDate}`);
            
            // Check if new date is an open day
            const suggestionWorked = newDate && newDate !== '2025-07-29';
            console.log(`   Suggestion worked: ${suggestionWorked ? '✅' : '❌'}`);
            
            testResults[0].suggestionWorked = suggestionWorked;
        }
        
        console.log('\n' + '='.repeat(50));
        console.log('TEST 2: OPEN DAY SUCCESS HANDLING');
        console.log('='.repeat(50));
        
        // Reset and test with open day
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(2000);
        
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        console.log('📍 Select 60-minute service...');
        await page.locator('.service-option[data-service="60min"]').click();
        await page.waitForTimeout(1000);
        
        console.log('📍 Click Next...');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(2000);
        
        console.log('📍 Enter open day (Monday)...');
        const dateInput2 = page.locator('#booking-date');
        await dateInput2.click();
        await page.waitForTimeout(300);
        
        await page.keyboard.press('Control+a');
        await page.waitForTimeout(100);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(100);
        
        // Enter Monday July 14, 2025 (open day)
        await page.keyboard.type('2025-07-14');
        await page.waitForTimeout(500);
        await page.keyboard.press('Tab');
        
        console.log('📍 Wait for time slots to load...');
        
        // Wait for success - time slots should load
        let timeSlotsLoaded = false;
        let attempts = 0;
        const maxAttempts = 20;
        
        while (!timeSlotsLoaded && attempts < maxAttempts) {
            attempts++;
            await page.waitForTimeout(500);
            
            const isDisabled = await page.locator('#booking-time').getAttribute('disabled');
            const optionCount = await page.locator('#booking-time option[value]:not([value=""])').count();
            
            console.log(`   Attempt ${attempts}: ${optionCount} options, disabled: ${isDisabled}`);
            
            if (optionCount > 0 && !isDisabled) {
                timeSlotsLoaded = true;
                console.log(`   ✅ Time slots loaded successfully!`);
                
                // Test selection
                const firstOption = await page.locator('#booking-time option[value]:not([value=""])').first();
                const timeValue = await firstOption.getAttribute('value');
                const timeText = await firstOption.textContent();
                
                console.log(`   Available time: ${timeText} (${timeValue})`);
                
                await page.locator('#booking-time').selectOption(timeValue);
                await page.waitForTimeout(1000);
                
                const selectedValue = await page.locator('#booking-time').inputValue();
                const selectionWorked = selectedValue === timeValue;
                
                console.log(`   Selection persisted: ${selectionWorked ? '✅' : '❌'}`);
                
                testResults.push({
                    test: 'Open Day Success',
                    timeSlotsLoaded: true,
                    optionCount: optionCount,
                    selectionWorked: selectionWorked,
                    status: 'PASS'
                });
                break;
            }
        }
        
        if (!timeSlotsLoaded) {
            console.log(`   ❌ Time slots failed to load after ${maxAttempts * 500}ms`);
            testResults.push({
                test: 'Open Day Success',
                timeSlotsLoaded: false,
                status: 'FAIL'
            });
        }
        
        // Test 3: Multiple rapid selections (persistence test)
        console.log('\n' + '='.repeat(50));
        console.log('TEST 3: RAPID SELECTION PERSISTENCE');
        console.log('='.repeat(50));
        
        if (timeSlotsLoaded) {
            let persistenceResults = [];
            
            for (let i = 1; i <= 5; i++) {
                console.log(`📍 Rapid test ${i}/5...`);
                
                const options = await page.locator('#booking-time option[value]:not([value=""])').all();
                if (options.length > i) {
                    const optionValue = await options[i].getAttribute('value');
                    const optionText = await options[i].textContent();
                    
                    await page.locator('#booking-time').selectOption(optionValue);
                    await page.waitForTimeout(200);
                    
                    const selectedValue = await page.locator('#booking-time').inputValue();
                    const persisted = selectedValue === optionValue;
                    
                    console.log(`   ${i}: ${optionText} -> ${persisted ? '✅' : '❌'}`);
                    persistenceResults.push(persisted);
                }
            }
            
            const persistenceRate = (persistenceResults.filter(r => r).length / persistenceResults.length) * 100;
            console.log(`   Overall persistence: ${persistenceRate}%`);
            
            testResults.push({
                test: 'Rapid Selection Persistence',
                persistenceRate: persistenceRate,
                status: persistenceRate >= 80 ? 'PASS' : 'FAIL'
            });
        }
        
        // FINAL RESULTS
        console.log('\n' + '='.repeat(60));
        console.log('🏆 AVAILABILITY FIX VERIFICATION RESULTS');
        console.log('='.repeat(60));
        
        const passCount = testResults.filter(r => r.status === 'PASS').length;
        const totalTests = testResults.length;
        
        testResults.forEach(result => {
            console.log(`${result.status === 'PASS' ? '✅' : '❌'} ${result.test}: ${result.status}`);
        });
        
        console.log(`\n📊 Overall: ${passCount}/${totalTests} tests passed (${Math.round(passCount/totalTests*100)}%)`);
        
        if (passCount === totalTests) {
            console.log('\n🎉 ALL TESTS PASSED!');
            console.log('✅ Availability loading fix is working correctly');
            console.log('✅ Error handling improved');
            console.log('✅ User experience enhanced');
        } else {
            console.log('\n⚠️ Some tests failed - additional fixes needed');
        }
        
        // Keep browser open for inspection
        console.log('\n🔍 Keeping browser open for 20 seconds...');
        await page.waitForTimeout(20000);
        
    } catch (error) {
        console.error('\n💥 TEST FAILURE:', error.message);
        await page.screenshot({ path: 'availability-fix-test-failure.png', fullPage: true });
    } finally {
        await browser.close();
    }
    
    return testResults;
}

// Execute
if (require.main === module) {
    testAvailabilityFixVerification()
        .then((results) => {
            const passCount = results.filter(r => r.status === 'PASS').length;
            const totalTests = results.length;
            
            console.log('\n✅ Availability fix verification completed');
            
            if (passCount === totalTests) {
                console.log('🎉 FIX VERIFIED - BOOKING SYSTEM RELIABILITY IMPROVED!');
                process.exit(0);
            } else {
                console.log(`❌ FIX INCOMPLETE: ${passCount}/${totalTests} tests passed`);
                process.exit(1);
            }
        })
        .catch((error) => {
            console.error('\n❌ Verification failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testAvailabilityFixVerification };