const { chromium } = require('playwright');

async function testMenuFunctionality() {
    console.log('🧪 Testing menu functionality on live admin dashboard...');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    try {
        // Navigate to admin dashboard
        console.log('📍 Navigating to admin dashboard...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        // Set mobile viewport to trigger menu display
        console.log('📱 Setting mobile viewport...');
        await page.setViewportSize({ width: 375, height: 667 });
        
        // Wait for page to fully load
        await page.waitForTimeout(2000);
        
        // Check if menu toggle is visible
        console.log('🔍 Checking menu toggle visibility...');
        const menuToggle = page.locator('.menu-toggle');
        const isVisible = await menuToggle.isVisible();
        console.log(`Menu toggle visible: ${isVisible}`);
        
        if (isVisible) {
            // Test clicking the menu toggle
            console.log('🖱️ Clicking menu toggle...');
            await menuToggle.click();
            await page.waitForTimeout(1000);
            
            // Check if sidebar opened
            const sidebar = page.locator('#sidebar');
            const hasOpenClass = await sidebar.evaluate(el => el.classList.contains('open'));
            console.log(`Sidebar opened: ${hasOpenClass}`);
            
            // Check if overlay is active
            const overlay = page.locator('#sidebarOverlay');
            const overlayActive = await overlay.evaluate(el => el.classList.contains('active'));
            console.log(`Overlay active: ${overlayActive}`);
            
            if (overlayActive) {
                // Test clicking overlay to close
                console.log('🖱️ Clicking overlay to close...');
                await overlay.click();
                await page.waitForTimeout(1000);
                
                // Check if sidebar closed
                const sidebarClosed = await sidebar.evaluate(el => !el.classList.contains('open'));
                console.log(`Sidebar closed: ${sidebarClosed}`);
            }
        }
        
        // Test functions in browser console
        console.log('🔧 Testing functions in browser console...');
        const functionsExist = await page.evaluate(() => {
            return {
                toggleSidebar: typeof window.toggleSidebar === 'function',
                closeSidebar: typeof window.closeSidebar === 'function',
                sidebarElement: !!document.getElementById('sidebar'),
                overlayElement: !!document.getElementById('sidebarOverlay')
            };
        });
        
        console.log('Function availability:', functionsExist);
        
        // Check for JavaScript errors
        const errors = [];
        page.on('pageerror', (error) => {
            errors.push(error.message);
        });
        
        if (errors.length > 0) {
            console.log('❌ JavaScript errors detected:', errors);
        } else {
            console.log('✅ No JavaScript errors detected');
        }
        
        console.log('✅ Menu functionality test completed');
        
    } catch (error) {
        console.error('❌ Test failed:', error);
    } finally {
        await browser.close();
    }
}

testMenuFunctionality();