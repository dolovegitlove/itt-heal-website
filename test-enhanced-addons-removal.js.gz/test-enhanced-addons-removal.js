/**
 * Test Enhanced Add-ons Removal
 * Tests the new robust add-ons removal functionality
 */

const { chromium } = require('playwright');

async function testEnhancedAddonsRemoval() {
    console.log('🚀 Testing Enhanced Add-ons Removal');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testResults = {
        initialAddonsPresent: false,
        editModalOpened: false,
        addonsRemoved: false,
        apiCallMade: false,
        clearFlagsSet: false,
        clientValidationTriggered: false,
        finalResult: false
    };

    try {
        // Navigate to admin panel
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Find a booking with add-ons or add some
        const firstBooking = page.locator('.booking-card').first();
        let bookingText = await firstBooking.textContent();
        
        console.log('📋 Initial booking text:', bookingText?.substring(0, 200));
        testResults.initialAddonsPresent = bookingText?.includes('Add-ons:') && !bookingText?.includes('Add-ons: $0');
        
        // Open edit modal
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        testResults.editModalOpened = modalVisible;
        console.log(`📊 Edit modal opened: ${modalVisible ? '✅' : '❌'}`);

        if (modalVisible) {
            // Check current add-ons state
            let checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📋 Currently checked add-ons: ${checkedAddons}`);

            // If no add-ons are checked but the booking shows add-ons, this confirms the bug
            if (!testResults.initialAddonsPresent || checkedAddons === 0) {
                console.log('➕ Adding an add-on first to test removal...');
                const availableAddons = await page.locator('#editAddonsContainer input[name="addons[]"]').count();
                if (availableAddons > 0) {
                    await page.locator('#editAddonsContainer input[name="addons[]"]').first().check();
                    await page.waitForTimeout(1000);
                    checkedAddons = 1;
                    console.log('✅ Add-on added for testing');
                }
            }

            if (checkedAddons > 0) {
                console.log('❌ Removing all add-ons...');
                
                // Uncheck all add-ons
                const checkedBoxes = page.locator('#editAddonsContainer input[name="addons[]"]:checked');
                const count = await checkedBoxes.count();
                for (let i = 0; i < count; i++) {
                    await checkedBoxes.nth(i).uncheck();
                    await page.waitForTimeout(300);
                }
                
                testResults.addonsRemoved = true;
                console.log('✅ All add-ons unchecked');

                // Monitor API calls for the new flags
                let apiCallData = null;
                
                page.on('request', request => {
                    if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                        testResults.apiCallMade = true;
                        const postData = request.postData();
                        if (postData) {
                            try {
                                apiCallData = JSON.parse(postData);
                                console.log('\n📡 API Request Data:');
                                console.log('   - addons:', JSON.stringify(apiCallData.addons));
                                console.log('   - special_requests:', `"${apiCallData.special_requests}"`);
                                console.log('   - clear_addons:', apiCallData.clear_addons);
                                console.log('   - force_addons_update:', apiCallData.force_addons_update);
                                
                                testResults.clearFlagsSet = apiCallData.clear_addons === true && 
                                                          apiCallData.force_addons_update === true;
                            } catch (e) {
                                console.log('📡 API data (non-JSON):', postData.substring(0, 200));
                            }
                        }
                    }
                });

                // Monitor console for client-side validation
                page.on('console', msg => {
                    if (msg.text().includes('Backend did not clear add-ons, forcing client-side update')) {
                        testResults.clientValidationTriggered = true;
                        console.log('🔧 Client-side validation triggered - backend fix applied');
                    }
                });

                // Submit the edit
                console.log('💾 Submitting edit with enhanced removal...');
                await page.locator('#editBookingForm button[type="submit"]').click();
                await page.waitForTimeout(4000);

                // Check if modal closed
                const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
                console.log(`📊 Modal closed: ${modalClosed ? '✅' : '❌'}`);

                // Check final booking state
                console.log('🔍 Checking final booking state...');
                await page.waitForTimeout(2000);
                
                const updatedBookingText = await firstBooking.textContent();
                console.log('📋 Updated booking text:', updatedBookingText?.substring(0, 200));
                
                const stillHasAddons = updatedBookingText?.includes('Add-ons:') && 
                                     !updatedBookingText?.includes('Add-ons: $0');
                testResults.finalResult = !stillHasAddons;
                
                console.log(`📊 Add-ons successfully removed: ${testResults.finalResult ? '✅' : '❌'}`);

                // Also verify by re-opening edit modal
                console.log('🔍 Verifying via edit modal...');
                await firstBooking.locator('.btn:has-text("Edit")').click();
                await page.waitForTimeout(2000);
                
                const finalCheckedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
                console.log(`📋 Add-ons still checked in form: ${finalCheckedAddons}`);
                
                // Close modal
                await page.locator('.modal-close').click();
                await page.waitForTimeout(1000);
            }
        }

        // Results summary
        console.log('\n📊 Enhanced Add-ons Removal Test Results:');
        console.log(`✅ Initial Add-ons Present: ${testResults.initialAddonsPresent ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Modal Opened: ${testResults.editModalOpened ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons Removed in UI: ${testResults.addonsRemoved ? 'YES' : 'NO'}`);
        console.log(`✅ API Call Made: ${testResults.apiCallMade ? 'YES' : 'NO'}`);
        console.log(`✅ Clear Flags Set: ${testResults.clearFlagsSet ? 'YES' : 'NO'}`);
        console.log(`✅ Client Validation Triggered: ${testResults.clientValidationTriggered ? 'YES' : 'NO'}`);
        console.log(`✅ Final Result - Add-ons Removed: ${testResults.finalResult ? 'YES' : 'NO'}`);

        const overallSuccess = testResults.finalResult;
        console.log(`\n🎯 OVERALL RESULT: ${overallSuccess ? '✅ ENHANCED REMOVAL WORKING' : '❌ STILL HAS ISSUES'}`);

        if (overallSuccess) {
            console.log('\n🎉 ENHANCED ADD-ONS REMOVAL IS WORKING!');
            console.log('   - Robust frontend flags implemented');
            console.log('   - Client-side validation active');
            console.log('   - Add-ons successfully removed from display');
            console.log('   - Edit functionality now properly handles add-ons removal');
        } else {
            console.log('\n🔧 Areas that worked:');
            if (testResults.clearFlagsSet) console.log('   ✅ Clear flags properly set');
            if (testResults.apiCallMade) console.log('   ✅ API calls being made');
            if (testResults.clientValidationTriggered) console.log('   ✅ Client validation working');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'enhanced-addons-test-error.png', fullPage: true });
    } finally {
        await browser.close();
    }

    return testResults;
}

if (require.main === module) {
    testEnhancedAddonsRemoval().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testEnhancedAddonsRemoval };