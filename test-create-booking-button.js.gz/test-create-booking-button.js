/**
 * Test Create Booking Button - Check if it's visible and working
 */
const { chromium } = require('playwright');

async function testCreateBookingButton() {
    console.log('➕ Testing Create Booking Button');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        console.log('🔍 Looking for Create New Booking button...');
        
        // Check if the button exists
        const createButton = page.locator('button:has-text("Create New Booking")');
        const buttonExists = await createButton.count();
        
        console.log(`📋 Create button exists: ${buttonExists > 0 ? 'YES' : 'NO'}`);
        
        if (buttonExists > 0) {
            console.log('✅ Create New Booking button found');
            
            // Check if button is visible
            const isVisible = await createButton.isVisible();
            console.log(`👁️ Button is visible: ${isVisible ? 'YES' : 'NO'}`);
            
            // Check if button is enabled
            const isEnabled = await createButton.isEnabled();
            console.log(`🔘 Button is enabled: ${isEnabled ? 'YES' : 'NO'}`);
            
            if (isVisible && isEnabled) {
                console.log('🖱️ Clicking Create New Booking button...');
                await createButton.click();
                
                // Wait for modal to appear
                await page.waitForTimeout(1000);
                
                // Check if modal opened
                const modalExists = await page.locator('#createBookingModal.active').count();
                console.log(`📋 Modal opened: ${modalExists > 0 ? 'YES' : 'NO'}`);
                
                if (modalExists > 0) {
                    console.log('✅ Create booking modal opened successfully');
                    
                    // Check if form fields are present
                    const nameField = await page.locator('#clientName').count();
                    const emailField = await page.locator('#clientEmail').count();
                    const phoneField = await page.locator('#clientPhone').count();
                    const serviceField = await page.locator('#serviceType').count();
                    
                    console.log(`📋 Form fields present:`);
                    console.log(`  - Name field: ${nameField > 0 ? 'YES' : 'NO'}`);
                    console.log(`  - Email field: ${emailField > 0 ? 'YES' : 'NO'}`);
                    console.log(`  - Phone field: ${phoneField > 0 ? 'YES' : 'NO'}`);
                    console.log(`  - Service field: ${serviceField > 0 ? 'YES' : 'NO'}`);
                    
                    const allFieldsPresent = nameField && emailField && phoneField && serviceField;
                    console.log(`✅ All form fields present: ${allFieldsPresent ? 'YES' : 'NO'}`);
                    
                    // Close modal
                    await page.locator('#createBookingModal .modal-close').click();
                    await page.waitForTimeout(500);
                    
                    const modalClosed = await page.locator('#createBookingModal.active').count();
                    console.log(`📋 Modal closed: ${modalClosed === 0 ? 'YES' : 'NO'}`);
                    
                } else {
                    console.log('❌ Create booking modal did not open');
                }
            } else {
                console.log('❌ Create button is not visible or enabled');
            }
        } else {
            console.log('❌ Create New Booking button not found');
            
            // Check what buttons are available
            const allButtons = await page.locator('button').all();
            console.log('🔍 Available buttons:');
            for (const button of allButtons) {
                const text = await button.textContent();
                console.log(`  - "${text}"`);
            }
        }
        
        console.log('\n📊 CREATE BOOKING BUTTON TEST COMPLETE');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testCreateBookingButton();