/**
 * Test Add-ons Edit Fix
 * Tests that add-ons can be properly removed during booking editing
 */

const { chromium } = require('playwright');

async function testAddonsEditFix() {
    console.log('🧪 Testing Add-ons Edit Fix');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testResults = {
        bookingCreated: false,
        addonsInitiallySelected: false,
        editModalOpened: false,
        addonsRemoved: false,
        editSubmitted: false,
        addonsActuallyRemoved: false
    };

    try {
        // Step 1: Create a booking with add-ons
        console.log('📝 Creating booking with add-ons...');
        await page.goto('https://ittheal.com');
        await page.waitForTimeout(2000);

        // Navigate to booking section
        const bookBtn = page.locator('a[href="#booking"], .btn:has-text("Book")').first();
        await bookBtn.click();
        await page.waitForTimeout(1000);

        // Fill basic booking info
        await page.locator('#clientName').fill('Addons Test Client');
        await page.locator('#clientEmail').fill('addons-test@example.com');
        await page.locator('#clientPhone').fill('555-0199');
        
        // Select service
        await page.locator('[data-service="60min"]').click();
        await page.waitForTimeout(500);
        
        // Select add-ons (if available)
        const addonCheckboxes = await page.locator('input[name="addons[]"]').count();
        if (addonCheckboxes > 0) {
            await page.locator('input[name="addons[]"]').first().check();
            testResults.addonsInitiallySelected = true;
            console.log('✅ Add-on selected during booking creation');
        }
        
        // Select date (tomorrow)
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const dateStr = tomorrow.toISOString().split('T')[0];
        await page.locator('#appointmentDate').fill(dateStr);
        
        // Select time
        await page.locator('#appointmentTime').selectOption('10:00');
        
        // Submit booking
        console.log('💾 Submitting booking with add-ons...');
        await page.locator('#bookingForm button[type="submit"]').click();
        await page.waitForTimeout(3000);
        
        // Check for success
        const successAlert = await page.locator('.alert-success').count();
        testResults.bookingCreated = successAlert > 0;
        console.log(`📊 Booking created: ${testResults.bookingCreated ? '✅' : '❌'}`);

        if (!testResults.bookingCreated) {
            throw new Error('Failed to create test booking with add-ons');
        }

        // Step 2: Go to admin and edit the booking
        console.log('🔧 Navigating to admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Find our test booking and verify it has add-ons
        const testBooking = page.locator('.booking-card:has-text("Addons Test Client")');
        const bookingText = await testBooking.textContent();
        const hasAddonsInCard = bookingText?.includes('Add-ons:') || bookingText?.includes('Reflexology') || bookingText?.includes('+$');
        console.log(`📊 Booking card shows add-ons: ${hasAddonsInCard ? '✅' : '❌'}`);

        // Click edit button
        console.log('✏️ Opening edit modal...');
        const editButton = testBooking.locator('.btn:has-text("Edit")');
        await editButton.click();
        await page.waitForTimeout(2000);

        // Check if modal opened
        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        testResults.editModalOpened = modalVisible;
        console.log(`📊 Edit modal opened: ${testResults.editModalOpened ? '✅' : '❌'}`);

        if (testResults.editModalOpened) {
            // Step 3: Remove add-ons
            console.log('❌ Removing add-ons...');
            
            // Uncheck all add-on checkboxes
            const editAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📋 Found ${editAddons} checked add-ons in edit form`);
            
            if (editAddons > 0) {
                await page.locator('#editAddonsContainer input[name="addons[]"]:checked').uncheck();
                testResults.addonsRemoved = true;
                console.log('✅ Add-ons unchecked in edit form');
                
                // Wait for pricing to recalculate
                await page.waitForTimeout(1000);
            }

            // Monitor API calls
            let apiCallMade = false;
            let apiData = null;
            
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    apiCallMade = true;
                    const postData = request.postData();
                    if (postData) {
                        try {
                            apiData = JSON.parse(postData);
                            console.log('📡 API request data:', JSON.stringify(apiData, null, 2));
                        } catch (e) {
                            console.log('📡 API request (non-JSON):', postData.substring(0, 200));
                        }
                    }
                }
            });

            page.on('response', response => {
                if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                    console.log('✅ Edit API call successful');
                }
            });

            // Submit edit
            console.log('💾 Submitting edit without add-ons...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);

            testResults.editSubmitted = apiCallMade;
            console.log(`📊 Edit submitted: ${testResults.editSubmitted ? '✅' : '❌'}`);

            // Check if modal closed
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            console.log(`📊 Modal closed: ${modalClosed ? '✅' : '❌'}`);

            // Step 4: Verify add-ons were actually removed
            console.log('🔍 Verifying add-ons removal...');
            await page.waitForTimeout(2000);
            
            // Check booking card again
            const updatedBookingText = await testBooking.textContent();
            const stillHasAddons = updatedBookingText?.includes('Add-ons:') || updatedBookingText?.includes('Reflexology') || (updatedBookingText?.includes('+$') && !updatedBookingText?.includes('$0'));
            testResults.addonsActuallyRemoved = !stillHasAddons;
            
            console.log(`📊 Add-ons removed from card: ${testResults.addonsActuallyRemoved ? '✅' : '❌'}`);
            
            if (!testResults.addonsActuallyRemoved) {
                console.log('📋 Booking card still contains:', updatedBookingText?.substring(0, 200));
            }

            // Also test by reopening edit modal
            console.log('🔍 Re-opening edit modal to verify...');
            await editButton.click();
            await page.waitForTimeout(2000);
            
            const stillCheckedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📊 Add-ons still checked in form: ${stillCheckedAddons}`);
            
            // Close modal
            await page.locator('.modal-close').click();
            await page.waitForTimeout(1000);
        }

        // Summary
        console.log('\n📊 Test Results Summary:');
        console.log(`✅ Booking Created: ${testResults.bookingCreated ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons Initially Selected: ${testResults.addonsInitiallySelected ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Modal Opened: ${testResults.editModalOpened ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons Removed in Form: ${testResults.addonsRemoved ? 'YES' : 'NO'}`);
        console.log(`✅ Edit Submitted: ${testResults.editSubmitted ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons Actually Removed: ${testResults.addonsActuallyRemoved ? 'YES' : 'NO'}`);

        const overallSuccess = testResults.addonsActuallyRemoved && testResults.editSubmitted;
        console.log(`\n🎯 OVERALL RESULT: ${overallSuccess ? '✅ ADD-ONS EDIT FIX WORKING' : '❌ ADD-ONS EDIT STILL BROKEN'}`);

        if (overallSuccess) {
            console.log('\n🎉 ADD-ONS REMOVAL IN EDIT IS NOW WORKING!');
            console.log('   - Empty addons array is properly sent to backend');
            console.log('   - Add-ons line is removed from special_requests');
            console.log('   - Booking card correctly shows no add-ons');
        } else {
            console.log('\n❌ ADD-ONS REMOVAL STILL HAS ISSUES');
            console.log('   - Check API data logged above for debugging');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'test-addons-edit-error.png', fullPage: true });
    } finally {
        await browser.close();
    }

    return testResults;
}

if (require.main === module) {
    testAddonsEditFix().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testAddonsEditFix };