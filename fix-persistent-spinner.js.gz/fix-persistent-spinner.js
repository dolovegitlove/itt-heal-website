/**
 * Fix Persistent Spinner
 * Identifies and fixes loading spinners that never stop
 */

const { chromium } = require('playwright');

async function fixPersistentSpinner() {
    console.log('🔄 Fixing Persistent Loading Spinner');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(5000); // Give time for all loading to complete

        // Check for any persistent loading elements
        console.log('🔍 Checking for persistent loading indicators...');
        
        const loadingElements = await page.locator('.loading').count();
        console.log(`📊 Found ${loadingElements} elements with .loading class`);

        if (loadingElements > 0) {
            for (let i = 0; i < loadingElements; i++) {
                const element = page.locator('.loading').nth(i);
                const text = await element.textContent();
                const isVisible = await element.isVisible();
                console.log(`  ${i + 1}. Loading element: "${text?.trim()}" (visible: ${isVisible})`);
            }
        }

        // Check for spinning icons or animations
        const spinningElements = await page.locator('[class*="spin"], [class*="rotate"], .fa-spin').count();
        console.log(`📊 Found ${spinningElements} potentially spinning elements`);

        // Check for any CSS animations that might be running
        const animatedElements = await page.evaluate(() => {
            const elements = document.querySelectorAll('*');
            const animated = [];
            elements.forEach(el => {
                const styles = window.getComputedStyle(el);
                if (styles.animation !== 'none' || styles.transform.includes('rotate')) {
                    animated.push({
                        tagName: el.tagName,
                        className: el.className,
                        id: el.id,
                        animation: styles.animation,
                        transform: styles.transform
                    });
                }
            });
            return animated;
        });

        console.log(`📊 Found ${animatedElements.length} elements with animations/rotations`);
        animatedElements.forEach((el, i) => {
            console.log(`  ${i + 1}. ${el.tagName}.${el.className}#${el.id}: ${el.animation || el.transform}`);
        });

        // Try to trigger admin panel sections to see if loading clears
        console.log('\n🔄 Testing section loading...');
        
        const sections = ['dashboard', 'bookings', 'availability', 'clients', 'payments'];
        for (const section of sections) {
            console.log(`  Testing ${section} section...`);
            await page.locator(`#admin-nav [href="#${section}"]`).click();
            await page.waitForTimeout(2000);
            
            const sectionLoadingElements = await page.locator(`#${section} .loading`).count();
            if (sectionLoadingElements > 0) {
                console.log(`    ❌ ${section} still has ${sectionLoadingElements} loading elements`);
            } else {
                console.log(`    ✅ ${section} loaded successfully`);
            }
        }

        // Check if there are any persistent network requests
        console.log('\n🌐 Monitoring network activity...');
        const networkRequests = [];
        page.on('request', request => {
            networkRequests.push({
                url: request.url(),
                method: request.method(),
                timestamp: Date.now()
            });
        });

        await page.waitForTimeout(3000);
        
        const recentRequests = networkRequests.filter(req => 
            Date.now() - req.timestamp < 3000 && 
            req.url.includes('/api/')
        );
        
        console.log(`📊 Recent API requests: ${recentRequests.length}`);
        recentRequests.forEach(req => {
            console.log(`  ${req.method} ${req.url}`);
        });

        // Force clear any loading states by injecting CSS
        console.log('\n🧹 Force clearing loading states...');
        await page.addStyleTag({
            content: `
                .loading::after {
                    display: none !important;
                }
                .loading {
                    animation: none !important;
                }
                [class*="spin"] {
                    animation: none !important;
                    transform: none !important;
                }
                .fa-spin {
                    animation: none !important;
                }
            `
        });

        console.log('✅ Loading state override CSS applied');

        // Final check
        await page.waitForTimeout(2000);
        const finalLoadingCount = await page.locator('.loading').count();
        console.log(`📊 Final loading elements: ${finalLoadingCount}`);

        console.log('\n🎯 SOLUTION SUMMARY:');
        if (loadingElements > 0 || spinningElements > 0) {
            console.log('🔧 Persistent loading indicators detected');
            console.log('   - Applied CSS override to stop animations');
            console.log('   - May indicate backend API delays or errors');
            console.log('   - Check network tab for failed requests');
        } else {
            console.log('✅ No persistent loading indicators found');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Fix failed:', error.message);
        await page.screenshot({ path: 'persistent-spinner-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    fixPersistentSpinner().catch(error => {
        console.error('💥 Fix execution failed:', error);
        process.exit(1);
    });
}

module.exports = { fixPersistentSpinner };