/**
 * Test Loading Circle and Multiple Add-ons Fixes
 * Tests both the loading state fix and multiple add-ons persistence
 */

const { chromium } = require('playwright');

async function testLoadingAndMultipleAddons() {
    console.log('🧪 Testing Loading Circle and Multiple Add-ons Fixes');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testResults = {
        loadingStateWorks: false,
        multipleAddonsSelected: false,
        multipleAddonsSaved: false,
        multipleAddonsRestored: false,
        allTestsPassed: false
    };

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Test 1: Multiple Add-ons Selection
        console.log('📋 Testing multiple add-ons selection...');
        const availableAddons = await page.locator('#editAddonsContainer input[name="addons[]"]').count();
        console.log(`📊 Available add-ons: ${availableAddons}`);

        if (availableAddons >= 2) {
            // Clear any existing selections first
            await page.locator('#editAddonsContainer input[name="addons[]"]:checked').uncheck();
            await page.waitForTimeout(500);
            
            // Select multiple add-ons
            console.log('✅ Selecting multiple add-ons...');
            await page.locator('#editAddonsContainer input[name="addons[]"]').nth(0).check();
            await page.waitForTimeout(300);
            await page.locator('#editAddonsContainer input[name="addons[]"]').nth(1).check();
            await page.waitForTimeout(300);
            
            const selectedCount = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            testResults.multipleAddonsSelected = selectedCount >= 2;
            console.log(`📊 Multiple add-ons selected: ${testResults.multipleAddonsSelected ? '✅' : '❌'} (${selectedCount})`);

            // Test 2: Loading State Management
            console.log('⏳ Testing loading state management...');
            
            // Monitor button state changes
            let buttonStateChanges = [];
            let loadingStateWorked = false;
            
            const monitorButton = async () => {
                const submitButton = page.locator('#editBookingForm button[type="submit"]');
                while (true) {
                    try {
                        const disabled = await submitButton.getAttribute('disabled');
                        const text = await submitButton.textContent();
                        buttonStateChanges.push({ disabled: disabled !== null, text: text?.trim() });
                        
                        if (text?.includes('Updating...')) {
                            loadingStateWorked = true;
                            console.log('✅ Loading state detected: "Updating..."');
                        }
                        
                        await page.waitForTimeout(100);
                    } catch (e) {
                        break; // Modal closed
                    }
                }
            };
            
            // Start monitoring in background
            monitorButton();

            console.log('💾 Submitting edit...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            
            // Wait for submission to complete
            await page.waitForTimeout(4000);

            // Check if modal closed (indicates loading completed)
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            testResults.loadingStateWorks = loadingStateWorked && modalClosed;
            
            console.log(`📊 Loading state worked: ${testResults.loadingStateWorks ? '✅' : '❌'}`);
            console.log(`📊 Modal closed properly: ${modalClosed ? '✅' : '❌'}`);

            // Test 3: Multiple Add-ons Persistence
            console.log('🔍 Testing multiple add-ons persistence...');
            await page.waitForTimeout(2000);
            
            // Check booking card for multiple add-ons
            const bookingText = await firstBooking.textContent();
            const addonPriceMatches = bookingText?.match(/\(\+\$\d+\)/g) || [];
            testResults.multipleAddonsSaved = addonPriceMatches.length >= 2;
            
            console.log(`📊 Multiple add-ons in card: ${testResults.multipleAddonsSaved ? '✅' : '❌'} (found ${addonPriceMatches.length} price indicators)`);

            // Test 4: Multiple Add-ons Restoration in Edit Form
            console.log('🔄 Testing add-ons restoration in edit form...');
            await firstBooking.locator('.btn:has-text("Edit")').click();
            await page.waitForTimeout(2000);
            
            // Wait a bit longer for the setTimeout logic to run
            await page.waitForTimeout(500);
            
            const restoredCount = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            testResults.multipleAddonsRestored = restoredCount >= 2;
            
            console.log(`📊 Multiple add-ons restored: ${testResults.multipleAddonsRestored ? '✅' : '❌'} (${restoredCount} checked)`);

            // List which add-ons are checked
            const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').all();
            for (let i = 0; i < checkedAddons.length; i++) {
                const value = await checkedAddons[i].getAttribute('value');
                console.log(`   - Restored add-on: ${value}`);
            }

            // Close modal
            await page.locator('#editBookingModal .modal-close').click();
            await page.waitForTimeout(1000);

        } else {
            console.log('❌ Not enough add-ons available for testing');
        }

        // Overall results
        testResults.allTestsPassed = testResults.loadingStateWorks && 
                                   testResults.multipleAddonsSelected && 
                                   testResults.multipleAddonsSaved && 
                                   testResults.multipleAddonsRestored;

        console.log('\n📊 Test Results Summary:');
        console.log(`✅ Loading State Management: ${testResults.loadingStateWorks ? 'WORKING' : 'FAILED'}`);
        console.log(`✅ Multiple Add-ons Selection: ${testResults.multipleAddonsSelected ? 'WORKING' : 'FAILED'}`);
        console.log(`✅ Multiple Add-ons Saving: ${testResults.multipleAddonsSaved ? 'WORKING' : 'FAILED'}`);
        console.log(`✅ Multiple Add-ons Restoration: ${testResults.multipleAddonsRestored ? 'WORKING' : 'FAILED'}`);

        console.log(`\n🎯 OVERALL RESULT: ${testResults.allTestsPassed ? '✅ ALL FIXES WORKING' : '❌ SOME ISSUES REMAIN'}`);

        if (testResults.allTestsPassed) {
            console.log('\n🎉 SUCCESS! Both issues are now fixed:');
            console.log('   - Loading circle no longer gets stuck');
            console.log('   - Multiple add-ons are properly saved and restored');
            console.log('   - Edit functionality is working correctly');
        } else {
            console.log('\n🔧 Areas that need attention:');
            if (!testResults.loadingStateWorks) console.log('   ❌ Loading state management needs work');
            if (!testResults.multipleAddonsSaved) console.log('   ❌ Multiple add-ons saving needs work');
            if (!testResults.multipleAddonsRestored) console.log('   ❌ Multiple add-ons restoration needs work');
        }

        await page.waitForTimeout(2000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'loading-and-addons-test-error.png', fullPage: true });
    } finally {
        await browser.close();
    }

    return testResults;
}

if (require.main === module) {
    testLoadingAndMultipleAddons().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testLoadingAndMultipleAddons };