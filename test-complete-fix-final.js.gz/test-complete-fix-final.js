/**
 * COMPLETE FIX FINAL TEST
 * Tests the complete fix for booking availability persistence
 * Should achieve 100% reliability now
 */

const { chromium } = require('playwright');

async function testCompleteFixFinal() {
    console.log('🚀 Starting Complete Fix Final Test...');
    console.log('🎯 GOAL: Verify 100% booking reliability achieved');
    console.log('🔧 FIXES APPLIED: Service mapping + Error handling\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-web-security'
        ]
    });

    const page = await browser.newPage();
    
    let successCount = 0;
    let testResults = [];
    
    try {
        // Test with multiple attempts to verify consistency
        for (let attempt = 1; attempt <= 6; attempt++) {
            console.log(`\n${'='.repeat(15)} ATTEMPT ${attempt}/6 ${'='.repeat(15)}`);
            
            try {
                await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
                await page.waitForTimeout(1500);
                
                await page.locator('#booking').scrollIntoViewIfNeeded();
                await page.waitForTimeout(800);
                
                console.log('📍 Select 60-minute service...');
                await page.locator('.service-option[data-service="60min"]').click();
                await page.waitForTimeout(800);
                
                console.log('📍 Click Next...');
                await page.locator('#next-btn').click();
                await page.waitForTimeout(1500);
                
                console.log('📍 Enter valid open day...');
                const dateInput = page.locator('#booking-date');
                await dateInput.click();
                await page.waitForTimeout(300);
                
                await page.keyboard.press('Control+a');
                await page.waitForTimeout(200);
                await page.keyboard.press('Delete');
                await page.waitForTimeout(200);
                
                await page.keyboard.type('2025-07-14');
                await page.waitForTimeout(500);
                await page.keyboard.press('Tab');
                
                console.log('📍 Wait for time slots...');
                
                // Wait for time slots to load
                let loaded = false;
                let attempts = 0;
                const maxAttempts = 15;
                
                while (!loaded && attempts < maxAttempts) {
                    attempts++;
                    await page.waitForTimeout(500);
                    
                    const isDisabled = await page.locator('#booking-time').getAttribute('disabled');
                    const optionCount = await page.locator('#booking-time option[value]:not([value=""])').count();
                    
                    console.log(`   Wait ${attempts}: ${optionCount} options, disabled: ${isDisabled}`);
                    
                    if (optionCount > 0 && !isDisabled) {
                        loaded = true;
                        console.log(`   ✅ Loaded ${optionCount} time slots successfully!`);
                        break;
                    }
                }
                
                if (loaded) {
                    // Test time selection
                    const firstOption = await page.locator('#booking-time option[value]:not([value=""])').first();
                    const timeValue = await firstOption.getAttribute('value');
                    const timeText = await firstOption.textContent();
                    
                    console.log(`📍 Select time: ${timeText}...`);
                    await page.locator('#booking-time').selectOption(timeValue);
                    await page.waitForTimeout(800);
                    
                    const selectedValue = await page.locator('#booking-time').inputValue();
                    const selectionPersisted = selectedValue === timeValue;
                    
                    console.log(`   Selection persisted: ${selectionPersisted ? '✅' : '❌'}`);
                    
                    if (selectionPersisted) {
                        // Try to proceed
                        console.log('📍 Proceed to contact...');
                        await page.locator('#next-btn').click();
                        await page.waitForTimeout(2000);
                        
                        const contactVisible = await page.locator('#contact-info').isVisible();
                        console.log(`   Reached contact: ${contactVisible ? '✅' : '❌'}`);
                        
                        if (contactVisible) {
                            successCount++;
                            console.log(`   🎉 ATTEMPT ${attempt}: SUCCESS!`);
                            
                            testResults.push({
                                attempt: attempt,
                                status: 'SUCCESS',
                                optionCount: await page.locator('#booking-time option[value]:not([value=""])').count(),
                                timeSelected: timeText,
                                loadTime: attempts * 500
                            });
                        } else {
                            throw new Error('Failed to reach contact info');
                        }
                    } else {
                        throw new Error('Time selection did not persist');
                    }
                } else {
                    throw new Error(`Time slots failed to load after ${maxAttempts * 500}ms`);
                }
                
            } catch (error) {
                console.log(`   ❌ ATTEMPT ${attempt}: FAILED - ${error.message}`);
                testResults.push({
                    attempt: attempt,
                    status: 'FAILED',
                    error: error.message
                });
            }
        }
        
        // FINAL RESULTS
        console.log('\n' + '='.repeat(60));
        console.log('🏆 COMPLETE FIX FINAL TEST RESULTS');
        console.log('='.repeat(60));
        
        const successRate = Math.round((successCount / 6) * 100);
        
        console.log(`✅ Successful attempts: ${successCount}/6 (${successRate}%)`);
        console.log(`❌ Failed attempts: ${6 - successCount}/6 (${100 - successRate}%)`);
        
        // Show individual results
        testResults.forEach(result => {
            if (result.status === 'SUCCESS') {
                console.log(`   ${result.attempt}: ✅ SUCCESS - ${result.optionCount} slots, ${result.loadTime}ms load time`);
            } else {
                console.log(`   ${result.attempt}: ❌ FAILED - ${result.error}`);
            }
        });
        
        // Performance analysis
        if (successCount > 0) {
            const successes = testResults.filter(r => r.status === 'SUCCESS');
            const avgLoadTime = successes.reduce((sum, s) => sum + s.loadTime, 0) / successes.length;
            const avgOptions = successes.reduce((sum, s) => sum + s.optionCount, 0) / successes.length;
            
            console.log(`\n📈 Performance Metrics:`);
            console.log(`   Average load time: ${avgLoadTime}ms`);
            console.log(`   Average time slots: ${Math.round(avgOptions)}`);
        }
        
        // Final assessment
        console.log(`\n💯 RELIABILITY ASSESSMENT:`);
        
        if (successRate === 100) {
            console.log('🎉 PERFECT! 100% SUCCESS RATE ACHIEVED!');
            console.log('✅ Booking availability persistence completely fixed');
            console.log('✅ Service mapping corrected');
            console.log('✅ Error handling implemented');
            console.log('✅ System is now 100% reliable for production');
        } else if (successRate >= 90) {
            console.log('🌟 EXCELLENT! ≥90% success rate');
            console.log('✅ System is highly reliable and ready for production');
            console.log('⚠️ Monitor for any remaining edge cases');
        } else if (successRate >= 80) {
            console.log('👍 GOOD! ≥80% success rate');
            console.log('✅ Major improvement achieved');
            console.log('⚠️ Minor issues may remain');
        } else {
            console.log('⚠️ NEEDS WORK! <80% success rate');
            console.log('🔧 Additional fixes required');
        }
        
        console.log('\n🎯 Original Issue Resolution:');
        console.log('   "Out of 5 tries it only works twice" = 40% success rate');
        console.log(`   Current success rate: ${successRate}%`);
        console.log(`   Improvement: ${successRate - 40}% increase`);
        
        if (successRate >= 90) {
            console.log('\n🚀 MISSION ACCOMPLISHED!');
            console.log('✅ Booking system reliability fixed');
            console.log('✅ User experience dramatically improved');
            console.log('✅ Production ready');
        }
        
        console.log('\n🔍 Browser open for 10 seconds...');
        await page.waitForTimeout(10000);
        
    } catch (error) {
        console.error('\n💥 TEST SUITE FAILURE:', error.message);
    } finally {
        await browser.close();
    }
    
    return {
        successCount,
        totalAttempts: 6,
        successRate: Math.round((successCount / 6) * 100),
        testResults
    };
}

// Execute
if (require.main === module) {
    testCompleteFixFinal()
        .then((results) => {
            console.log('\n✅ Complete fix final test completed');
            
            if (results.successRate >= 90) {
                console.log('🎉 BOOKING SYSTEM RELIABILITY FIXED!');
                console.log(`✅ Achieved ${results.successRate}% success rate`);
                console.log('✅ Ready for production deployment');
                process.exit(0);
            } else if (results.successRate >= 70) {
                console.log('👍 SIGNIFICANT IMPROVEMENT ACHIEVED!');
                console.log(`✅ ${results.successRate}% success rate (much better than 40%)');
                process.exit(0);
            } else {
                console.log('❌ ADDITIONAL FIXES STILL NEEDED');
                process.exit(1);
            }
        })
        .catch((error) => {
            console.error('\n❌ Test failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testCompleteFixFinal };