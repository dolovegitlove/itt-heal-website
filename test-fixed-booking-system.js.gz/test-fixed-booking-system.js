const { chromium } = require('playwright');

async function testFixedBookingSystem() {
    console.log('🚀 Testing Fixed Booking System (No Refresh Loops)');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: ['--window-size=1920,1080', '--no-sandbox']
    });

    try {
        const page = await browser.newPage();
        
        // Track API calls to detect loops
        let apiCallCount = 0;
        const apiCalls = [];
        
        page.route('**/api/web-booking/availability/**', route => {
            apiCallCount++;
            apiCalls.push({
                url: route.request().url(),
                timestamp: new Date().toISOString()
            });
            console.log(`📡 API Call #${apiCallCount}: ${route.request().url()}`);
            route.continue();
        });
        
        // Listen for console messages
        page.on('console', msg => {
            if (msg.type() === 'error') {
                console.log(`❌ Browser Console Error: ${msg.text()}`);
            } else if (msg.text().includes('Time selection preserved') || msg.text().includes('Debug:')) {
                console.log(`📋 Booking Log: ${msg.text()}`);
            }
        });
        
        // Navigate to site
        console.log('📍 Loading https://ittheal.com');
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(2000);
        
        // Scroll to booking section
        console.log('📍 Scrolling to booking section');
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        // Select 30-minute service (as shown in your log)
        console.log('🎯 Selecting 30-minute service');
        await page.locator('[data-service-type="30min_massage"]').click();
        await page.waitForTimeout(1000);
        
        // Click Next to proceed to step 2
        console.log('➡️ Clicking Next button');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(1000);
        
        // Reset API call counter for date selection test
        apiCallCount = 0;
        apiCalls.length = 0;
        
        // Select date (this should trigger only ONE API call)
        console.log('📅 Selecting date: 2025-07-14');
        const dateInput = page.locator('#booking-date');
        await dateInput.click();
        await dateInput.fill('2025-07-14');
        await page.waitForTimeout(3000); // Wait for any potential cascading calls
        
        console.log(`\n📊 API Call Analysis after date selection:`);
        console.log(`   Total API calls: ${apiCallCount}`);
        console.log(`   Expected: 1 call`);
        console.log(`   Status: ${apiCallCount === 1 ? '✅ FIXED' : '❌ STILL BROKEN'}`);
        
        if (apiCallCount > 1) {
            console.log('\n🔍 Multiple API calls detected:');
            apiCalls.forEach((call, index) => {
                console.log(`   ${index + 1}. ${call.timestamp} - ${call.url}`);
            });
        }
        
        // Check if time slots loaded correctly
        const timeSlotStatus = await page.evaluate(() => {
            const timeSelect = document.getElementById('booking-time');
            return {
                optionCount: timeSelect ? timeSelect.options.length : 0,
                disabled: timeSelect ? timeSelect.disabled : null,
                value: timeSelect ? timeSelect.value : null
            };
        });
        
        console.log('⏰ Time Slot Status:', timeSlotStatus);
        
        // Test time selection persistence
        if (timeSlotStatus.optionCount > 1) {
            console.log('🎯 Testing time selection (11:30 AM)');
            await page.locator('#booking-time').selectOption('16:30');
            await page.waitForTimeout(1000);
            
            // Reset API counter for persistence test
            apiCallCount = 0;
            apiCalls.length = 0;
            
            // Re-select same date (should NOT trigger new API call due to persistence)
            console.log('🔄 Re-selecting same date to test persistence');
            await dateInput.click();
            await dateInput.fill('2025-07-14');
            await page.waitForTimeout(2000);
            
            console.log(`\n📊 Persistence Test:`);
            console.log(`   API calls on date re-selection: ${apiCallCount}`);
            console.log(`   Expected: 0-1 calls (with smart caching)`);
            
            // Check if time selection was preserved
            const finalTimeValue = await page.evaluate(() => {
                return document.getElementById('booking-time')?.value;
            });
            
            console.log(`   Time selection preserved: ${finalTimeValue === '16:30' ? '✅ YES' : '❌ NO'}`);
            console.log(`   Selected time: ${finalTimeValue}`);
        }
        
        console.log('\n✅ Booking system stability test completed');
        
    } catch (error) {
        console.error('❌ Test failed:', error);
    } finally {
        await browser.close();
    }
}

testFixedBookingSystem();