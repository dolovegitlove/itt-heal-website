const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging step transition from contact-info to payment-info...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Add console log listener to capture page logs
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', error => console.log('PAGE ERROR:', error.message));
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  console.log('📊 Initial page loaded');
  
  // Step 1: Service selection
  console.log('🎯 Step 1: Service selection');
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 2: Date/time
  console.log('📅 Step 2: Date/time selection');
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  await page.selectOption('#booking-time', { index: 1 });
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 3: Client info  
  console.log('👤 Step 3: Client information');
  await page.fill('#client-name', 'Test User');
  await page.fill('#client-email', 'test@example.com');
  await page.fill('#client-phone', '555-123-4567');
  
  console.log('📋 About to click Next button in step 3...');
  
  // Add JavaScript to monitor what happens when Next is clicked
  await page.evaluate(() => {
    console.log('Adding event listeners for debugging...');
    
    // Monitor currentStep variable
    window.addEventListener('click', (e) => {
      if (e.target.id === 'next-btn') {
        console.log('Next button clicked, currentStep before:', window.currentStep || 'undefined');
        
        // Add a small delay to check currentStep after
        setTimeout(() => {
          console.log('currentStep after click:', window.currentStep || 'undefined');
          
          // Check step visibility
          const steps = ['service-selection', 'datetime-selection', 'contact-info', 'payment-info', 'booking-summary'];
          steps.forEach(stepId => {
            const el = document.getElementById(stepId);
            if (el) {
              console.log(`Step ${stepId}: display=${getComputedStyle(el).display}, visible=${el.offsetParent !== null}`);
            }
          });
        }, 100);
      }
    });
  });
  
  await page.click('#next-btn');
  await page.waitForTimeout(3000);
  
  // Check final form state
  console.log('🔍 Final form step status...');
  const finalSteps = await page.evaluate(() => {
    const stepElements = [
      'service-selection',
      'datetime-selection', 
      'contact-info',
      'payment-info',
      'booking-summary'
    ];
    
    return stepElements.map(stepId => {
      const el = document.getElementById(stepId);
      return {
        id: stepId,
        exists: el !== null,
        visible: el ? el.offsetParent !== null : false,
        display: el ? getComputedStyle(el).display : 'none'
      };
    });
  });
  
  console.log('📊 Final form steps status:');
  finalSteps.forEach(step => {
    console.log(`  ${step.id}: exists=${step.exists}, visible=${step.visible}, display=${step.display}`);
  });
  
  await browser.close();
})().catch(console.error);