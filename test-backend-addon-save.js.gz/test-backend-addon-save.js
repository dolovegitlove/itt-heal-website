/**
 * Test Backend Add-on Save - Check if special_requests is properly updated
 */
const fetch = require('node-fetch');

async function testBackendAddonSave() {
    console.log('🔍 Testing Backend Add-on Save Behavior');
    
    const API_BASE = 'https://ittheal.com/api/admin';
    const API_KEY = 'itt-heal-admin-2024';
    
    try {
        // Get first booking with add-ons
        console.log('\n1️⃣ Fetching bookings...');
        const response = await fetch(`${API_BASE}/bookings`, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        const bookingWithAddons = data.bookings.find(b => 
            b.special_requests && b.special_requests.includes('Add-ons:')
        );
        
        if (!bookingWithAddons) {
            console.log('❌ No booking with add-ons found');
            return;
        }
        
        console.log(`\n2️⃣ Found booking ${bookingWithAddons.id} with add-ons`);
        console.log(`Original special_requests: "${bookingWithAddons.special_requests}"`);
        
        // Remove add-ons from special_requests
        const cleanedRequests = bookingWithAddons.special_requests
            .replace(/Add-ons:[^\n]*\n?/gi, '')
            .trim();
        
        console.log(`\n3️⃣ Updating booking to remove add-ons...`);
        console.log(`New special_requests: "${cleanedRequests}"`);
        
        const updateData = {
            special_requests: cleanedRequests,
            clear_addons: true,
            force_addons_update: true
        };
        
        const updateResponse = await fetch(`${API_BASE}/bookings/${bookingWithAddons.id}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updateData)
        });
        
        const updateResult = await updateResponse.json();
        console.log(`Update response:`, updateResult.success ? '✅ Success' : '❌ Failed');
        
        // Fetch the booking again to verify
        console.log(`\n4️⃣ Re-fetching booking to verify...`);
        const verifyResponse = await fetch(`${API_BASE}/bookings/${bookingWithAddons.id}`, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            }
        });
        
        const verifyData = await verifyResponse.json();
        const updatedBooking = verifyData.booking;
        
        console.log(`\n5️⃣ Verification Results:`);
        console.log(`Updated special_requests: "${updatedBooking.special_requests}"`);
        console.log(`Contains "Add-ons:"? ${updatedBooking.special_requests.includes('Add-ons:') ? '❌ YES (BUG!)' : '✅ NO'}`);
        
        if (updatedBooking.special_requests.includes('Add-ons:')) {
            console.log('\n❌ BACKEND BUG: Add-ons line was not removed from special_requests!');
            console.log('The backend is not properly updating the special_requests field.');
        } else {
            console.log('\n✅ Backend correctly removed add-ons from special_requests');
        }
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    }
}

// Run the test
testBackendAddonSave();