/**
 * Test Exact User Scenario - Match user's exact experience
 */
const { chromium } = require('playwright');

async function testExactScenario() {
    console.log('🔍 Testing Exact User Scenario');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 300
    });
    
    try {
        const page = await browser.newPage();
        
        // Enable console logging for debugging
        page.on('console', msg => {
            if (msg.text().includes('add-on') || msg.text().includes('Add-on') || msg.text().includes('special')) {
                console.log(`🌐 ${msg.text()}`);
            }
        });
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        // Look for any booking
        const bookingsCount = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingsCount} bookings`);
        
        if (bookingsCount === 0) {
            console.log('❌ No bookings found. Please create a booking with add-ons first.');
            return;
        }
        
        // Get the first booking
        const firstBooking = await page.locator('.booking-card').first();
        
        console.log('\n===== EXACT USER SCENARIO TEST =====');
        console.log('Following these exact steps:');
        console.log('1. Open booking edit');
        console.log('2. Remove add-ons from special features');
        console.log('3. Save');
        console.log('4. Reopen edit');
        console.log('5. Check if add-ons are still there');
        
        console.log('\n📝 STEP 1: Opening booking edit...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check what's in special requests initially
        const specialRequestsInput = page.locator('#editSpecialRequests');
        const initialValue = await specialRequestsInput.inputValue();
        console.log(`📋 Initial special requests: "${initialValue}"`);
        
        // Check initial add-ons
        const initialAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        console.log(`📊 Initial add-ons checked: ${initialAddons}`);
        
        if (initialAddons === 0) {
            console.log('⚠️ No add-ons to remove. Test cannot proceed.');
            return;
        }
        
        console.log('\n📝 STEP 2: Removing add-ons from special features...');
        
        // Method 1: Uncheck all add-ons
        const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
        const count = await checkboxes.count();
        console.log(`Unchecking ${count} add-ons...`);
        
        for (let i = 0; i < count; i++) {
            await checkboxes.nth(0).click();
            await page.waitForTimeout(300);
        }
        
        // Verify they're unchecked
        const afterUncheck = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        console.log(`📊 Add-ons after unchecking: ${afterUncheck}`);
        
        // Check special requests after unchecking
        const afterUncheckValue = await specialRequestsInput.inputValue();
        console.log(`📋 Special requests after unchecking: "${afterUncheckValue}"`);
        
        console.log('\n📝 STEP 3: Saving...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        console.log('✅ Saved successfully');
        
        // Wait for modal to close
        await page.waitForTimeout(2000);
        
        console.log('\n📝 STEP 4: Reopening edit...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        console.log('\n📝 STEP 5: Checking if add-ons are back...');
        const finalAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const finalSpecialRequests = await specialRequestsInput.inputValue();
        
        console.log(`📊 Final add-ons checked: ${finalAddons}`);
        console.log(`📋 Final special requests: "${finalSpecialRequests}"`);
        
        console.log('\n===== RESULTS =====');
        console.log(`Initial add-ons: ${initialAddons}`);
        console.log(`After removal: ${afterUncheck}`);
        console.log(`After save/reopen: ${finalAddons}`);
        
        if (finalAddons > 0) {
            console.log('\n❌ BUG CONFIRMED: Add-ons reappeared after save!');
            console.log('This matches the user\'s report exactly.');
            
            // Show which add-ons are checked
            const checkedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').all();
            console.log('Checked add-ons:');
            for (const checkbox of checkedAddons) {
                const id = await checkbox.getAttribute('id');
                const value = await checkbox.getAttribute('value');
                console.log(`  - ${id}: ${value}`);
            }
        } else {
            console.log('\n✅ NO BUG: Add-ons stayed removed after save.');
        }
        
        // Close modal
        await page.locator('#editBookingModal .close').click();
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testExactScenario();