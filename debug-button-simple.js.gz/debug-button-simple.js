/**
 * Simple debug - check if button exists
 */

console.log('🔍 Checking for Create New Booking button...');

// Check if we're in a browser environment
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    console.log('Running in browser environment');
    
    // Wait for DOM to load
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded, checking for button...');
        
        // Check if bookings section exists
        const bookingsSection = document.getElementById('bookings');
        console.log('Bookings section exists:', bookingsSection ? 'YES' : 'NO');
        
        // Look for the button
        const createButton = document.querySelector('button[onclick="openCreateBookingModal()"]');
        console.log('Create button found:', createButton ? 'YES' : 'NO');
        
        if (createButton) {
            console.log('Button text:', createButton.textContent);
            console.log('Button visible:', createButton.style.display !== 'none');
            
            // Highlight the button
            createButton.style.border = '3px solid red';
            createButton.style.backgroundColor = 'yellow';
            
            console.log('Button has been highlighted with red border and yellow background');
        } else {
            console.log('❌ Button not found');
            
            // Show all buttons
            const allButtons = document.querySelectorAll('button');
            console.log('All buttons found:', allButtons.length);
            
            allButtons.forEach((btn, index) => {
                console.log(`Button ${index + 1}:`, btn.textContent.trim());
            });
        }
    });
} else {
    console.log('Not in browser environment - run this in browser console');
}