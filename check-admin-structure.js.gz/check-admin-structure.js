/**
 * Check Admin Structure - See what's actually in the admin panel
 */
const { chromium } = require('playwright');

async function checkAdminStructure() {
    console.log('🔍 Checking Current Admin Panel Structure');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        console.log('\n🔍 CHECKING PAGE STRUCTURE:');
        
        // Check what sections exist
        const sections = await page.locator('section, div[id], main').all();
        console.log(`Found ${sections.length} sections/divs:`);
        
        for (let i = 0; i < sections.length; i++) {
            const section = sections[i];
            const id = await section.getAttribute('id');
            const className = await section.getAttribute('class');
            const tagName = await section.evaluate(el => el.tagName);
            
            if (id || className) {
                console.log(`  ${i + 1}. <${tagName} id="${id || ''}" class="${className || ''}">`);
            }
        }
        
        console.log('\n🔍 CHECKING NAVIGATION:');
        
        // Check navigation items
        const navItems = await page.locator('nav a, nav button, [data-section], .nav-item').all();
        console.log(`Found ${navItems.length} navigation items:`);
        
        for (let i = 0; i < navItems.length; i++) {
            const item = navItems[i];
            const text = await item.textContent();
            const href = await item.getAttribute('href');
            const dataSection = await item.getAttribute('data-section');
            const isActive = await item.evaluate(el => el.classList.contains('active'));
            
            console.log(`  ${i + 1}. "${text}" ${href ? `href="${href}"` : ''} ${dataSection ? `data-section="${dataSection}"` : ''} ${isActive ? '(ACTIVE)' : ''}`);
        }
        
        console.log('\n🔍 CHECKING ALL BUTTONS:');
        
        // Check all buttons on the page
        const allButtons = await page.locator('button').all();
        console.log(`Found ${allButtons.length} buttons:`);
        
        for (let i = 0; i < allButtons.length; i++) {
            const button = allButtons[i];
            const text = await button.textContent();
            const onclick = await button.getAttribute('onclick');
            const isVisible = await button.isVisible();
            
            console.log(`  ${i + 1}. "${text}" ${onclick ? `onclick="${onclick}"` : ''} ${isVisible ? '(VISIBLE)' : '(HIDDEN)'}`);
        }
        
        console.log('\n🔍 CHECKING FOR BOOKINGS SECTION:');
        
        // Check if bookings section exists
        const bookingsSection = page.locator('#bookings');
        const bookingsSectionExists = await bookingsSection.count();
        
        console.log(`Bookings section exists: ${bookingsSectionExists > 0 ? 'YES' : 'NO'}`);
        
        if (bookingsSectionExists > 0) {
            const isActive = await bookingsSection.evaluate(el => el.classList.contains('active'));
            console.log(`Bookings section active: ${isActive ? 'YES' : 'NO'}`);
            
            if (!isActive) {
                console.log('🖱️ Activating bookings section...');
                const bookingsNav = page.locator('[data-section="bookings"]');
                if (await bookingsNav.count() > 0) {
                    await bookingsNav.click();
                    await page.waitForTimeout(2000);
                    
                    console.log('✅ Bookings section activated');
                    
                    // Check for create button again
                    const createButton = page.locator('button:has-text("Create")');
                    const createButtonCount = await createButton.count();
                    
                    console.log(`Create buttons found: ${createButtonCount}`);
                    
                    if (createButtonCount > 0) {
                        const createButtons = await createButton.all();
                        for (let i = 0; i < createButtons.length; i++) {
                            const button = createButtons[i];
                            const text = await button.textContent();
                            const isVisible = await button.isVisible();
                            console.log(`  Create button ${i + 1}: "${text}" ${isVisible ? '(VISIBLE)' : '(HIDDEN)'}`);
                        }
                    }
                }
            }
        }
        
        console.log('\n📊 STRUCTURE CHECK COMPLETE');
        console.log('Browser window will stay open for 10 seconds so you can inspect...');
        await page.waitForTimeout(10000);
        
    } catch (error) {
        console.error('❌ Check failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the structure check
checkAdminStructure();