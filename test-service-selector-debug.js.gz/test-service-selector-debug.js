/**
 * SERVICE SELECTOR DEBUG TEST
 * Identifies the correct service selectors on the live site
 */

const { chromium } = require('playwright');

async function debugServiceSelectors() {
    console.log('🔍 Starting Service Selector Debug...');
    console.log('🌐 TESTING: Live site service selector attributes\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    try {
        // Navigate to live site
        console.log('📍 Navigating to live booking page...');
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(3000);
        
        // Scroll to booking section
        console.log('📍 Scrolling to booking section...');
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(2000);
        
        // Debug: Find all service-related elements
        console.log('🔍 DEBUGGING: Finding all service selection elements...\n');
        
        // Check for service options with various selector patterns
        const serviceSelectors = [
            '.service-option',
            '[data-service]',
            '[data-service-type]',
            '[onclick*="selectService"]',
            'button[onclick*="service"]',
            '.service-card',
            '.service-button',
            '[class*="service"]'
        ];
        
        for (const selector of serviceSelectors) {
            try {
                const elements = await page.locator(selector).all();
                if (elements.length > 0) {
                    console.log(`✅ Found ${elements.length} elements with selector: ${selector}`);
                    
                    for (let i = 0; i < Math.min(elements.length, 5); i++) {
                        const element = elements[i];
                        const text = await element.textContent();
                        const dataService = await element.getAttribute('data-service');
                        const dataServiceType = await element.getAttribute('data-service-type');
                        const onClick = await element.getAttribute('onclick');
                        const className = await element.getAttribute('class');
                        
                        console.log(`  Element ${i + 1}:`);
                        console.log(`    Text: "${text?.trim()}"`);
                        console.log(`    data-service: "${dataService}"`);
                        console.log(`    data-service-type: "${dataServiceType}"`);
                        console.log(`    onclick: "${onClick}"`);
                        console.log(`    class: "${className}"`);
                        console.log('');
                    }
                } else {
                    console.log(`❌ No elements found with selector: ${selector}`);
                }
            } catch (error) {
                console.log(`❌ Error with selector ${selector}: ${error.message}`);
            }
        }
        
        // Get the full booking section HTML for analysis
        console.log('📋 FULL BOOKING SECTION ANALYSIS:');
        console.log('='.repeat(50));
        
        const bookingSection = page.locator('#booking');
        const bookingHTML = await bookingSection.innerHTML();
        
        // Extract service-related parts
        const lines = bookingHTML.split('\n');
        const serviceLines = lines.filter(line => 
            line.includes('service') || 
            line.includes('button') || 
            line.includes('onclick') ||
            line.includes('data-')
        );
        
        console.log('Service-related HTML lines:');
        serviceLines.slice(0, 20).forEach((line, index) => {
            console.log(`${index + 1}: ${line.trim()}`);
        });
        
        console.log('\n📍 Attempting to click any service button...');
        
        // Try different service selection approaches
        const serviceTestSelectors = [
            'button:has-text("60")',
            'button:has-text("90")',
            'button:has-text("Minute")',
            '[onclick*="Service"]',
            '.service-option:first-of-type',
            'button[data-service]',
            'button[data-service-type]'
        ];
        
        for (const testSelector of serviceTestSelectors) {
            try {
                const element = page.locator(testSelector).first();
                const isVisible = await element.isVisible({ timeout: 2000 });
                
                if (isVisible) {
                    const text = await element.textContent();
                    console.log(`✅ Found clickable service element: ${testSelector}`);
                    console.log(`   Text: "${text?.trim()}"`);
                    
                    // Try clicking it
                    await element.click();
                    await page.waitForTimeout(1000);
                    
                    console.log(`✅ Successfully clicked: ${testSelector}`);
                    break;
                } else {
                    console.log(`❌ Element not visible: ${testSelector}`);
                }
            } catch (error) {
                console.log(`❌ Failed with ${testSelector}: ${error.message}`);
            }
        }
        
        // Take screenshot for visual analysis
        await page.screenshot({ path: 'service-debug-analysis.png', fullPage: true });
        console.log('\n📸 Screenshot saved: service-debug-analysis.png');
        
        // Keep browser open for manual inspection
        console.log('\n🔍 Keeping browser open for 30 seconds for manual inspection...');
        await page.waitForTimeout(30000);
        
    } catch (error) {
        console.error('\n💥 DEBUG TEST FAILURE:', error.message);
        await page.screenshot({ path: 'service-debug-failure.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

// Execute
if (require.main === module) {
    debugServiceSelectors()
        .then(() => {
            console.log('\n✅ Service selector debug completed');
            process.exit(0);
        })
        .catch((error) => {
            console.error('\n❌ Debug failed:', error.message);
            process.exit(1);
        });
}

module.exports = { debugServiceSelectors };