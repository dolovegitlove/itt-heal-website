/**
 * Test Specific Race Condition - Check if issue happens on same page without reload
 */
const { chromium } = require('playwright');

async function testRaceCondition() {
    console.log('🔍 Testing Race Condition - Same Page Edit');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        // First, let's create a booking with add-ons
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(2000);
        
        // Create a new booking with add-ons
        console.log('➕ Creating test booking with add-ons...');
        await page.locator('button:has-text("Create Booking")').click();
        await page.waitForSelector('#createBookingModal.active', { timeout: 5000 });
        
        // Fill in booking details
        await page.locator('#clientName').fill('Race Test User');
        await page.locator('#clientEmail').fill('race@test.com');
        await page.locator('#clientPhone').fill('555-999-8888');
        await page.locator('#serviceType').selectOption('60min');
        await page.locator('#scheduledDate').fill('2025-07-16T10:00');
        
        // Add at least one add-on
        const createAddonCheckboxes = await page.locator('#addonsContainer input[type="checkbox"]');
        const createAddonCount = await createAddonCheckboxes.count();
        if (createAddonCount > 0) {
            await createAddonCheckboxes.first().check();
            if (createAddonCount > 1) {
                await createAddonCheckboxes.nth(1).check();
            }
            console.log('✅ Added add-ons to new booking');
        }
        
        // Submit the booking
        await page.locator('#createBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        await page.waitForTimeout(2000);
        
        // Find the new booking (should be first/most recent)
        const newBooking = await page.locator('.booking-card').first();
        
        console.log('\n📝 STEP 1: First edit - check initial state');
        await newBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check initial add-ons
        const initialChecked = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const initialSpecialRequests = await page.locator('#editSpecialRequests').inputValue();
        
        console.log(`📊 Initial add-ons checked: ${initialChecked}`);
        console.log(`📋 Initial special requests: "${initialSpecialRequests}"`);
        
        // Close modal without changing anything
        await page.locator('#editBookingModal .close').click();
        await page.waitForTimeout(1000);
        
        console.log('\n📝 STEP 2: Second edit - remove add-ons');
        await newBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Uncheck all add-ons
        const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
        const count = await checkboxes.count();
        for (let i = 0; i < count; i++) {
            await checkboxes.nth(0).click();
            await page.waitForTimeout(200);
        }
        
        const afterUncheck = await page.locator('#editSpecialRequests').inputValue();
        console.log(`📋 After unchecking: "${afterUncheck}"`);
        
        // Save the changes
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        await page.waitForTimeout(2000);
        
        console.log('\n📝 STEP 3: Third edit - immediately check if add-ons returned');
        await newBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check if add-ons came back
        const finalChecked = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const finalSpecialRequests = await page.locator('#editSpecialRequests').inputValue();
        
        console.log(`📊 Final add-ons checked: ${finalChecked}`);
        console.log(`📋 Final special requests: "${finalSpecialRequests}"`);
        
        console.log('\n📊 RACE CONDITION TEST RESULTS:');
        console.log(`Step 1 (initial): ${initialChecked} add-ons`);
        console.log(`Step 2 (after remove): 0 add-ons (expected)`);
        console.log(`Step 3 (after save): ${finalChecked} add-ons`);
        
        if (finalChecked > 0) {
            console.log('\n❌ RACE CONDITION CONFIRMED');
            console.log('Add-ons are reappearing after save on same page');
            
            // Check if it's the same data being reloaded
            if (finalSpecialRequests === initialSpecialRequests) {
                console.log('❌ SAME DATA: Backend is not saving the cleared special_requests');
            } else {
                console.log('❌ DIFFERENT DATA: Frontend is re-parsing/restoring add-ons');
            }
        } else {
            console.log('\n✅ NO RACE CONDITION');
            console.log('Add-ons stay removed after save on same page');
        }
        
        // Close modal
        await page.locator('#editBookingModal .close').click();
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testRaceCondition();