/**
 * Edit Functionality Validator
 * Proactively detects edit form issues like loading states and data persistence
 */

const { chromium } = require('playwright');

async function validateEditFunctionality() {
    console.log('🔍 Validating Edit Functionality');
    
    const issues = [];
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    try {
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Check if edit functionality exists
        const editButtons = await page.locator('.btn:has-text("Edit")').count();
        if (editButtons === 0) {
            issues.push({
                type: 'CRITICAL',
                category: 'EDIT_FUNCTIONALITY',
                issue: 'No edit buttons found in admin panel',
                impact: 'Users cannot edit any records'
            });
            return issues;
        }

        // Test edit modal opening
        await page.locator('.btn:has-text("Edit")').first().click();
        await page.waitForTimeout(2000);

        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        if (!modalVisible) {
            issues.push({
                type: 'HIGH',
                category: 'MODAL_FUNCTIONALITY', 
                issue: 'Edit modal does not open when edit button clicked',
                impact: 'Edit functionality completely broken'
            });
        }

        if (modalVisible) {
            // Check for loading state management
            const submitButton = page.locator('#editBookingForm button[type="submit"]');
            const buttonExists = await submitButton.count() > 0;
            
            if (!buttonExists) {
                issues.push({
                    type: 'HIGH',
                    category: 'FORM_SUBMISSION',
                    issue: 'No submit button found in edit form',
                    impact: 'Cannot save edit changes'
                });
            } else {
                // Check if loading state logic exists
                const pageContent = await page.content();
                
                if (!pageContent.includes('submitButton.disabled = true')) {
                    issues.push({
                        type: 'MEDIUM',
                        category: 'LOADING_STATE',
                        issue: 'Submit button lacks loading state (disabled)',
                        impact: 'Users may double-click and cause issues'
                    });
                }
                
                if (!pageContent.includes('Updating...')) {
                    issues.push({
                        type: 'MEDIUM', 
                        category: 'LOADING_STATE',
                        issue: 'Submit button lacks loading text feedback',
                        impact: 'Users unsure if submission is in progress'
                    });
                }

                if (!pageContent.includes('finally {') || !pageContent.includes('submitButton.disabled = false')) {
                    issues.push({
                        type: 'HIGH',
                        category: 'LOADING_STATE',
                        issue: 'No finally block to reset button state on errors',
                        impact: 'Button may stay disabled if submission fails'
                    });
                }
            }

            // Check multiple add-ons support
            const addonCheckboxes = await page.locator('#editAddonsContainer input[name="addons[]"]').count();
            if (addonCheckboxes > 1) {
                // Check if restoration logic exists
                const pageContent = await page.content();
                
                if (!pageContent.includes('addonsToRestore')) {
                    issues.push({
                        type: 'HIGH',
                        category: 'DATA_PERSISTENCE',
                        issue: 'Multiple add-ons may not restore correctly in edit form',
                        impact: 'Add-ons appear to be lost when editing'
                    });
                }

                if (!pageContent.includes('setTimeout') || !pageContent.includes('populateEditAddons')) {
                    issues.push({
                        type: 'MEDIUM',
                        category: 'TIMING_ISSUE',
                        issue: 'Add-ons restoration may have timing issues',
                        impact: 'Add-ons may not show as selected in edit form'
                    });
                }

                if (!pageContent.includes('addons: []') || !pageContent.includes('clear_addons')) {
                    issues.push({
                        type: 'HIGH',
                        category: 'DATA_REMOVAL',
                        issue: 'Add-ons removal may not work properly',
                        impact: 'Cannot remove add-ons from bookings'
                    });
                }
            }

            // Check form field population
            const nameInput = await page.locator('#editClientName').count();
            const emailInput = await page.locator('#editClientEmail').count();
            
            if (nameInput === 0 || emailInput === 0) {
                issues.push({
                    type: 'HIGH',
                    category: 'FORM_POPULATION',
                    issue: 'Essential form fields missing in edit modal',
                    impact: 'Cannot edit basic booking information'
                });
            }
        }

    } catch (error) {
        issues.push({
            type: 'CRITICAL',
            category: 'SYSTEM_ERROR',
            issue: `Edit functionality validation failed: ${error.message}`,
            impact: 'Cannot validate edit system - may be completely broken'
        });
    } finally {
        await browser.close();
    }

    // Generate report
    console.log('\n📊 Edit Functionality Validation Report');
    console.log('==========================================');
    
    if (issues.length === 0) {
        console.log('✅ No edit functionality issues detected');
        return issues;
    }

    const critical = issues.filter(i => i.type === 'CRITICAL');
    const high = issues.filter(i => i.type === 'HIGH');
    const medium = issues.filter(i => i.type === 'MEDIUM');

    console.log(`🚨 CRITICAL Issues: ${critical.length}`);
    console.log(`⚠️  HIGH Issues: ${high.length}`);
    console.log(`⚡ MEDIUM Issues: ${medium.length}`);

    [...critical, ...high, ...medium].forEach((issue, index) => {
        console.log(`\n${index + 1}. [${issue.type}] ${issue.category}`);
        console.log(`   Issue: ${issue.issue}`);
        console.log(`   Impact: ${issue.impact}`);
    });

    console.log('\n💡 Recommendations:');
    if (critical.length > 0) {
        console.log('• Fix CRITICAL issues immediately - edit functionality may be broken');
    }
    if (high.length > 0) {
        console.log('• Address HIGH issues before next deployment');
    }
    if (medium.length > 0) {
        console.log('• Schedule MEDIUM issues for next development cycle');
    }

    return issues;
}

if (require.main === module) {
    validateEditFunctionality().then(issues => {
        const hasIssues = issues.length > 0;
        process.exit(hasIssues ? 1 : 0);
    }).catch(error => {
        console.error('💥 Validation failed:', error);
        process.exit(1);
    });
}

module.exports = { validateEditFunctionality };