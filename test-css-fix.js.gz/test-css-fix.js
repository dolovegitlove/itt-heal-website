/**
 * Test CSS Path Fix
 * Verifies that luxury-spa.css loads without 404 error
 */

const https = require('https');

async function testCSSFix() {
    console.log('🧪 Testing CSS Path Fix');
    
    try {
        // Check if the CSS file loads correctly
        const cssResponse = await new Promise((resolve, reject) => {
            const req = https.get('https://ittheal.com/dist/luxury-spa.css', (res) => {
                resolve({ status: res.statusCode, headers: res.headers });
            });
            req.on('error', reject);
            req.setTimeout(5000, () => reject(new Error('CSS request timeout')));
        });

        console.log(`📊 CSS file status: ${cssResponse.status}`);
        
        // Check if admin page has correct CSS path
        const adminResponse = await new Promise((resolve, reject) => {
            const req = https.get('https://ittheal.com/admin/', (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => resolve({ status: res.statusCode, data }));
            });
            req.on('error', reject);
            req.setTimeout(10000, () => reject(new Error('Admin request timeout')));
        });

        console.log(`📊 Admin page status: ${adminResponse.status}`);
        
        if (cssResponse.status === 200 && adminResponse.status === 200) {
            // Check if the CSS path in admin page is correct
            const hasOldPath = adminResponse.data.includes('href="./dist/luxury-spa.css"');
            const hasNewPath = adminResponse.data.includes('href="../dist/luxury-spa.css"');
            
            console.log('📊 CSS Path Analysis:');
            console.log(`✅ CSS file accessible: ${cssResponse.status === 200 ? 'YES' : 'NO'}`);
            console.log(`✅ Old broken path removed: ${!hasOldPath ? 'YES' : 'NO'}`);
            console.log(`✅ New correct path present: ${hasNewPath ? 'YES' : 'NO'}`);
            
            if (cssResponse.status === 200 && !hasOldPath && hasNewPath) {
                console.log('\n🎯 SUCCESS! CSS path fix is deployed');
                console.log('✅ luxury-spa.css file is accessible at /dist/luxury-spa.css');
                console.log('✅ Admin page now uses correct relative path ../dist/luxury-spa.css');
                console.log('✅ No more 404 errors for CSS file');
                console.log('\n🔧 The CSS 404 error should now be resolved!');
                return true;
            } else {
                console.log('\n❌ CSS path fix incomplete');
                if (cssResponse.status !== 200) console.log('   - CSS file not accessible');
                if (hasOldPath) console.log('   - Old broken path still present');
                if (!hasNewPath) console.log('   - New correct path not found');
                return false;
            }
        } else {
            console.log(`❌ Server issues: CSS=${cssResponse.status}, Admin=${adminResponse.status}`);
            return false;
        }
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
        return false;
    }
}

if (require.main === module) {
    testCSSFix().then(success => {
        if (success) {
            console.log('\n🎉 CSS path fix test PASSED');
            console.log('\n📝 WHAT WAS FIXED:');
            console.log('   Changed: href="./dist/luxury-spa.css"');
            console.log('   To:      href="../dist/luxury-spa.css"');
            console.log('   Reason:  Admin is in /admin/ subdirectory');
            process.exit(0);
        } else {
            console.log('\n💥 CSS path fix test FAILED');
            process.exit(1);
        }
    });
}

module.exports = { testCSSFix };