/**
 * Quick Debug Test - Check available elements on page
 */

const { chromium } = require('playwright');

async function debugPage() {
    console.log('🔍 Debug: Checking page elements...');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: ['--window-size=1920,1080', '--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    
    try {
        await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
        await page.waitForTimeout(3000);
        
        // Check what's on the page
        const title = await page.title();
        console.log('Page title:', title);
        
        // Look for booking related elements
        const bookingSection = await page.locator('#booking').isVisible().catch(() => false);
        const serviceOptions = await page.locator('.service-option').count().catch(() => 0);
        const nextBtn = await page.locator('#next-btn').isVisible().catch(() => false);
        
        console.log('Booking section visible:', bookingSection);
        console.log('Service options count:', serviceOptions);
        console.log('Next button visible:', nextBtn);
        
        // Get all sections/divs with IDs
        const allIds = await page.evaluate(() => {
            const elements = document.querySelectorAll('[id]');
            return Array.from(elements).map(el => el.id).filter(id => id);
        });
        
        console.log('Available element IDs:', allIds.slice(0, 20)); // Show first 20
        
        // Look for any element with "book" in the id or class
        const bookingElements = await page.evaluate(() => {
            const elements = document.querySelectorAll('[id*="book"], [class*="book"], [id*="service"], [class*="service"]');
            return Array.from(elements).map(el => ({
                tag: el.tagName,
                id: el.id,
                className: el.className,
                text: el.textContent?.substring(0, 50)
            }));
        });
        
        console.log('Booking-related elements:', bookingElements.slice(0, 10));
        
        await page.waitForTimeout(10000);
        
    } catch (error) {
        console.error('Debug error:', error.message);
        await page.screenshot({ path: 'debug-page.png' });
    } finally {
        await browser.close();
    }
}

debugPage().catch(console.error);