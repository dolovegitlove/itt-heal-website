const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging time selection persistence...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Track all events
  page.on('console', msg => console.log('PAGE:', msg.text()));
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  // Navigate to time selection
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  
  console.log('📅 Testing time selection persistence...');
  
  // Check initial state
  const initialValue = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    return timeSelect ? timeSelect.value : null;
  });
  console.log('Initial value:', initialValue);
  
  // Select a time
  await page.selectOption('#booking-time', '15:00');
  console.log('Selected 15:00');
  
  // Check if it persisted immediately
  const immediateValue = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    return timeSelect ? timeSelect.value : null;
  });
  console.log('Immediate value after selection:', immediateValue);
  
  // Wait a bit and check again
  await page.waitForTimeout(1000);
  const delayedValue = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    return timeSelect ? timeSelect.value : null;
  });
  console.log('Value after 1 second:', delayedValue);
  
  // Check if there are any event listeners that might be resetting it
  const eventInfo = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    if (!timeSelect) return null;
    
    // Try to trigger change event manually
    const originalValue = timeSelect.value;
    timeSelect.value = '16:00';
    
    const changeEvent = new Event('change', { bubbles: true });
    timeSelect.dispatchEvent(changeEvent);
    
    // Check if value persisted after event
    const afterEventValue = timeSelect.value;
    
    return {
      originalValue,
      afterEventValue,
      hasOnChange: timeSelect.onchange !== null,
      hasEventListeners: timeSelect.hasAttribute('onchange')
    };
  });
  
  console.log('Event test result:', eventInfo);
  
  // Check if there's any code that reloads time slots
  await page.evaluate(() => {
    // Monitor for any fetch calls that might reload times
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
      console.log('FETCH DETECTED:', args[0]);
      return originalFetch.apply(this, args);
    };
  });
  
  // Try selecting again and monitor for fetches
  await page.selectOption('#booking-time', '17:00');
  await page.waitForTimeout(2000);
  
  const finalValue = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    return timeSelect ? timeSelect.value : null;
  });
  console.log('Final value:', finalValue);
  
  await browser.close();
})().catch(console.error);