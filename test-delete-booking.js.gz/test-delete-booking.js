/**
 * Test Delete Booking - Check if deletion works properly
 */
const { chromium } = require('playwright');

async function testDeleteBooking() {
    console.log('🗑️ Testing Booking Deletion');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        // Enable console logging
        page.on('console', msg => {
            if (msg.text().includes('delete') || msg.text().includes('Delete') || msg.text().includes('error')) {
                console.log(`🌐 Frontend: ${msg.text()}`);
            }
        });
        
        // Monitor network requests
        page.on('request', request => {
            if (request.url().includes('/api/admin/bookings') && request.method() === 'DELETE') {
                console.log('\n📡 DELETE REQUEST:');
                console.log(`URL: ${request.url()}`);
                console.log(`Method: ${request.method()}`);
            }
        });
        
        page.on('response', response => {
            if (response.url().includes('/api/admin/bookings') && response.request().method() === 'DELETE') {
                console.log('\n📡 DELETE RESPONSE:');
                console.log(`Status: ${response.status()}`);
                response.json().then(data => {
                    console.log(`Success: ${data.success}`);
                    console.log(`Message: ${data.message}`);
                    if (data.deleted) {
                        console.log(`Deleted booking: ${data.deleted.client} - ${data.deleted.date}`);
                    }
                }).catch(e => console.log('Could not parse response JSON'));
            }
        });
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        const bookingsCount = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingsCount} bookings`);
        
        if (bookingsCount === 0) {
            console.log('⚠️ No bookings found to delete');
            return;
        }
        
        // Count initial bookings
        const initialCount = await page.locator('.booking-card').count();
        console.log(`📊 Initial booking count: ${initialCount}`);
        
        // Get the first booking
        const firstBooking = await page.locator('.booking-card').first();
        
        // Get booking details for verification
        const bookingId = await firstBooking.getAttribute('data-booking-id') || 'unknown';
        const clientName = await firstBooking.locator('h3').textContent();
        console.log(`📋 About to delete booking: ${clientName} (ID: ${bookingId})`);
        
        console.log('\n🗑️ STEP 1: Clicking delete button...');
        await firstBooking.locator('button:has-text("Delete")').click();
        
        // Wait for confirmation dialog
        console.log('⏳ Waiting for confirmation dialog...');
        await page.waitForTimeout(500);
        
        // Handle the confirmation dialog
        page.on('dialog', dialog => {
            console.log(`📋 Dialog: ${dialog.message()}`);
            dialog.accept();
        });
        
        // Click delete again to trigger the confirmation
        await firstBooking.locator('button:has-text("Delete")').click();
        
        // Wait for deletion to complete
        console.log('⏳ Waiting for deletion to complete...');
        await page.waitForTimeout(3000);
        
        // Check if booking was removed from UI
        const finalCount = await page.locator('.booking-card').count();
        console.log(`📊 Final booking count: ${finalCount}`);
        
        // Check for success alert
        const successAlert = await page.locator('.alert.alert-success').count();
        const errorAlert = await page.locator('.alert.alert-error').count();
        
        console.log(`✅ Success alerts: ${successAlert}`);
        console.log(`❌ Error alerts: ${errorAlert}`);
        
        console.log('\n📊 DELETION TEST RESULTS:');
        console.log(`Initial bookings: ${initialCount}`);
        console.log(`Final bookings: ${finalCount}`);
        console.log(`Expected change: -1`);
        console.log(`Actual change: ${finalCount - initialCount}`);
        
        if (finalCount === initialCount - 1) {
            console.log('\n✅ SUCCESS: Booking was deleted from UI');
        } else if (finalCount === initialCount) {
            console.log('\n❌ ISSUE: Booking was not removed from UI');
            console.log('The booking card is still visible after deletion');
        } else {
            console.log('\n⚠️ UNEXPECTED: Booking count changed by more than 1');
        }
        
        // Check if the specific booking is gone
        const bookingStillExists = await page.locator(`.booking-card:has-text("${clientName}")`).count();
        if (bookingStillExists === 0) {
            console.log('✅ Specific booking removed from UI');
        } else {
            console.log('❌ Specific booking still visible in UI');
        }
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testDeleteBooking();