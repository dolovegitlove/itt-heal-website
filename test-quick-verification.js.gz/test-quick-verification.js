const { chromium } = require('playwright');

(async () => {
  console.log('🚀 Quick verification test...');
  const browser = await chromium.launch({
    headless: false, 
    slowMo: 1000, 
    args: ['--no-sandbox', '--disable-web-security']
  });
  const page = await browser.newPage();
  
  try {
    await page.goto('https://ittheal.com');
    await page.waitForTimeout(2000);
    
    await page.locator('#booking').scrollIntoViewIfNeeded();
    await page.waitForTimeout(1000);
    
    console.log('📍 Select 60min service...');
    await page.locator('.service-option[data-service="60min"]').click();
    await page.waitForTimeout(1000);
    
    console.log('📍 Click Next...');
    await page.locator('#next-btn').click();
    await page.waitForTimeout(2000);
    
    console.log('📍 Enter valid date...');
    const dateInput = page.locator('#booking-date');
    await dateInput.fill('2025-07-14');
    await page.waitForTimeout(500);
    await page.keyboard.press('Tab');
    
    console.log('📍 Wait for time slots...');
    for (let i = 0; i < 8; i++) {
      await page.waitForTimeout(1000);
      const optionCount = await page.locator('#booking-time option[value]:not([value=""])').count();
      const isDisabled = await page.locator('#booking-time').getAttribute('disabled');
      console.log(`   Attempt ${i+1}: ${optionCount} options, disabled: ${isDisabled}`);
      
      if (optionCount > 0 && !isDisabled) {
        console.log('✅ SUCCESS! Time slots loaded correctly');
        const firstOption = await page.locator('#booking-time option[value]:not([value=""])').first();
        const timeValue = await firstOption.getAttribute('value');
        console.log(`✅ Found time slot: ${timeValue}`);
        break;
      }
    }
    
    console.log('🔍 Test completed');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    await browser.close();
  }
})();