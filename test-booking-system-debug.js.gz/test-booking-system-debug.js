const { chromium } = require('playwright');

async function debugBookingSystem() {
    console.log('🚀 Starting Booking System Debug Test');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: ['--window-size=1920,1080', '--no-sandbox']
    });

    try {
        const page = await browser.newPage();
        
        // Listen for console messages
        page.on('console', msg => {
            if (msg.type() === 'error') {
                console.log(`❌ Browser Console Error: ${msg.text()}`);
            } else if (msg.text().includes('BookingAvailability') || msg.text().includes('Booking')) {
                console.log(`📋 Booking Log: ${msg.text()}`);
            }
        });
        
        // Navigate to site
        console.log('📍 Loading https://ittheal.com');
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        
        // Wait for page to fully load
        await page.waitForTimeout(3000);
        
        // Check if BookingAvailability module loaded
        const moduleStatus = await page.evaluate(() => {
            return {
                BookingAvailabilityExists: typeof window.BookingAvailability !== 'undefined',
                initMethodExists: window.BookingAvailability && typeof window.BookingAvailability.init === 'function',
                refreshMethodExists: window.BookingAvailability && typeof window.BookingAvailability.refresh === 'function'
            };
        });
        
        console.log('📊 Module Status:', moduleStatus);
        
        if (!moduleStatus.BookingAvailabilityExists) {
            console.log('❌ BookingAvailability module is not loaded!');
            return;
        }
        
        // Scroll to booking section
        console.log('📍 Scrolling to booking section');
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        // Select a service first to show step 2
        console.log('🎯 Selecting 60-minute service');
        await page.locator('[data-service-type="60min_massage"]').click();
        await page.waitForTimeout(1000);
        
        // Check if datetime-selection div became visible
        const step2Visible = await page.evaluate(() => {
            const step2 = document.getElementById('datetime-selection');
            return {
                exists: !!step2,
                display: step2 ? window.getComputedStyle(step2).display : null
            };
        });
        console.log('📅 Step 2 visibility after service selection:', step2Visible);
        
        // Click Next button to proceed to step 2
        console.log('➡️ Clicking Next button to proceed to step 2');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(1000);
        
        // Check if step 2 is now visible
        const step2AfterNext = await page.evaluate(() => {
            const step2 = document.getElementById('datetime-selection');
            return {
                exists: !!step2,
                display: step2 ? window.getComputedStyle(step2).display : null
            };
        });
        console.log('📅 Step 2 visibility after Next button:', step2AfterNext);
        
        // Try to select a date
        console.log('📅 Selecting date: 2025-07-14');
        const dateInput = page.locator('#booking-date');
        await dateInput.click();
        await dateInput.fill('2025-07-14');
        await page.waitForTimeout(2000);
        
        // Check if time slots loaded
        const timeSelectStatus = await page.evaluate(() => {
            const timeSelect = document.getElementById('booking-time');
            return {
                exists: !!timeSelect,
                disabled: timeSelect ? timeSelect.disabled : null,
                optionCount: timeSelect ? timeSelect.options.length : 0,
                innerHTML: timeSelect ? timeSelect.innerHTML.substring(0, 200) : null
            };
        });
        
        console.log('⏰ Time Select Status:', timeSelectStatus);
        
        // Check if loading indicator is working
        const loadingStatus = await page.evaluate(() => {
            const loadingDiv = document.getElementById('time-loading');
            return {
                exists: !!loadingDiv,
                display: loadingDiv ? window.getComputedStyle(loadingDiv).display : null,
                innerHTML: loadingDiv ? loadingDiv.innerHTML.substring(0, 200) : null
            };
        });
        
        console.log('⏳ Loading Status:', loadingStatus);
        
        // Wait a bit more to see if anything changes
        await page.waitForTimeout(3000);
        
        // Check final status
        const finalStatus = await page.evaluate(() => {
            const timeSelect = document.getElementById('booking-time');
            return {
                timeSelectOptions: timeSelect ? timeSelect.options.length : 0,
                timeSelectDisabled: timeSelect ? timeSelect.disabled : null,
                timeSelectValue: timeSelect ? timeSelect.value : null
            };
        });
        
        console.log('✅ Final Status:', finalStatus);
        
        // Try clicking retry button if it exists
        const retryButtonExists = await page.locator('button:has-text("Retry")').count();
        if (retryButtonExists > 0) {
            console.log('🔄 Found retry button, clicking it');
            await page.locator('button:has-text("Retry")').click();
            await page.waitForTimeout(3000);
            
            const retryResult = await page.evaluate(() => {
                const timeSelect = document.getElementById('booking-time');
                return {
                    optionsAfterRetry: timeSelect ? timeSelect.options.length : 0
                };
            });
            
            console.log('🔄 Retry Result:', retryResult);
        }
        
        console.log('✅ Booking system debug completed');
        
    } catch (error) {
        console.error('❌ Debug failed:', error);
    } finally {
        await browser.close();
    }
}

debugBookingSystem();