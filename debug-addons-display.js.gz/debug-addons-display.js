/**
 * Debug Add-ons Display
 * Checks what's actually in the special_requests field after edit
 */

const { chromium } = require('playwright');

async function debugAddonsDisplay() {
    console.log('🔍 Debug Add-ons Display');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Get first booking
        const firstBooking = page.locator('.booking-card').first();
        
        // Click edit
        console.log('✏️ Opening edit modal to check current state...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check special_requests field content
        const specialRequestsValue = await page.locator('#editSpecialRequests').inputValue();
        console.log('📋 Current special_requests value:');
        console.log(`"${specialRequestsValue}"`);
        
        if (specialRequestsValue) {
            console.log('📋 Contains "Add-ons:"?', specialRequestsValue.includes('Add-ons:'));
            console.log('📋 Lines in special_requests:', specialRequestsValue.split('\n'));
        }

        // Check checked add-ons
        const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
        console.log(`📋 Currently checked add-ons: ${checkedAddons}`);

        if (checkedAddons === 0) {
            // Add an add-on
            console.log('➕ Adding an add-on...');
            await page.locator('#editAddonsContainer input[name="addons[]"]').first().check();
            await page.waitForTimeout(1000);
            
            // Monitor the submission
            let apiData = null;
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    const postData = request.postData();
                    if (postData) {
                        try {
                            apiData = JSON.parse(postData);
                            console.log('\n📡 API Data Being Sent:');
                            console.log('   - addons:', JSON.stringify(apiData.addons));
                            console.log('   - special_requests:', `"${apiData.special_requests}"`);
                        } catch (e) {
                            console.log('📡 API data (non-JSON):', postData.substring(0, 200));
                        }
                    }
                }
            });

            // Submit with add-on
            console.log('💾 Submitting with add-on...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);

            // Now remove the add-on
            console.log('✏️ Re-opening edit modal...');
            await firstBooking.locator('.btn:has-text("Edit")').click();
            await page.waitForTimeout(2000);

            console.log('❌ Removing the add-on...');
            await page.locator('#editAddonsContainer input[name="addons[]"]:checked').uncheck();
            await page.waitForTimeout(1000);

            // Check special_requests field after unchecking
            const specialRequestsAfterUncheck = await page.locator('#editSpecialRequests').inputValue();
            console.log('📋 special_requests after unchecking:');
            console.log(`"${specialRequestsAfterUncheck}"`);

            // Submit without add-on
            console.log('💾 Submitting without add-on...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);

            // Check final result
            console.log('🔍 Checking final booking display...');
            const bookingText = await firstBooking.textContent();
            console.log('📋 Final booking card text:', bookingText?.substring(0, 300));
            
            // Check if it still shows add-ons
            const stillShowsAddons = bookingText?.includes('Add-ons:') && !bookingText?.includes('Add-ons: $0');
            console.log(`📊 Still shows add-ons: ${stillShowsAddons ? '❌ YES' : '✅ NO'}`);

            // Also check the raw API data
            console.log('\n📊 Summary:');
            if (apiData) {
                console.log(`   - API sent addons: ${JSON.stringify(apiData.addons)}`);
                console.log(`   - API sent special_requests: "${apiData.special_requests}"`);
                
                // Check if special_requests still contains Add-ons line
                const hasAddonsLine = apiData.special_requests && apiData.special_requests.includes('Add-ons:');
                console.log(`   - special_requests contains "Add-ons:": ${hasAddonsLine ? '❌ YES' : '✅ NO'}`);
            }
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Debug failed:', error.message);
        await page.screenshot({ path: 'debug-addons-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    debugAddonsDisplay().catch(error => {
        console.error('💥 Debug execution failed:', error);
        process.exit(1);
    });
}

module.exports = { debugAddonsDisplay };