/**
 * Test Edit Form JavaScript Errors
 * Captures any JavaScript errors that prevent form submission
 */

const { chromium } = require('playwright');

async function testEditJSErrors() {
    console.log('🐛 Testing for JavaScript Errors in Edit Form');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    const jsErrors = [];
    const consoleMessages = [];

    // Capture JavaScript errors
    page.on('pageerror', error => {
        jsErrors.push(error.message);
        console.log('💥 JavaScript Error:', error.message);
    });

    // Capture all console messages
    page.on('console', msg => {
        const message = `${msg.type()}: ${msg.text()}`;
        consoleMessages.push(message);
        if (msg.type() === 'error') {
            console.log('🔴 Console Error:', msg.text());
        } else if (msg.type() === 'warn') {
            console.log('🟡 Console Warning:', msg.text());
        }
    });

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Click edit button
        console.log('✏️ Opening edit modal...');
        const editButton = page.locator('.booking-card .btn:has-text("Edit")').first();
        await editButton.click();
        await page.waitForTimeout(2000);

        // Wait for modal
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Make a small change
        console.log('📝 Making a small change...');
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.fill('Test Error Check');

        // Clear previous console messages to focus on submission
        consoleMessages.length = 0;
        jsErrors.length = 0;

        // Try to submit form and capture what happens
        console.log('💾 Attempting form submission...');
        
        // First, let's check if the form element exists and is properly set up
        const formExists = await page.locator('#editBookingForm').count();
        console.log('📋 Edit form exists:', formExists > 0);

        if (formExists > 0) {
            // Check if the submit button is enabled
            const submitButton = page.locator('#editBookingForm button[type="submit"]');
            const isEnabled = await submitButton.isEnabled();
            const isVisible = await submitButton.isVisible();
            console.log('📋 Submit button enabled:', isEnabled);
            console.log('📋 Submit button visible:', isVisible);

            // Try to submit via button click
            await submitButton.click();
            console.log('✅ Submit button clicked');
            
            // Wait to see what happens
            await page.waitForTimeout(3000);
            
            // Check if any form validation errors appeared
            const validationErrors = await page.locator('.form-error, .invalid-feedback, :invalid').count();
            console.log('📋 Validation errors found:', validationErrors);
            
            if (validationErrors > 0) {
                const firstError = await page.locator('.form-error, .invalid-feedback, :invalid').first().textContent();
                console.log('📋 First validation error:', firstError);
            }

            // Also try submitting via form.submit() to bypass any event listeners
            console.log('🔄 Trying direct form submission...');
            await page.evaluate(() => {
                const form = document.getElementById('editBookingForm');
                if (form) {
                    console.log('Form found, attempting programmatic submission...');
                    
                    // Check if form has any validation issues
                    const isValid = form.checkValidity();
                    console.log('Form is valid:', isValid);
                    
                    if (!isValid) {
                        console.log('Form validation failed');
                        form.reportValidity();
                    } else {
                        // Try to trigger the submit event
                        const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
                        const result = form.dispatchEvent(submitEvent);
                        console.log('Submit event dispatched:', result);
                    }
                } else {
                    console.log('Form not found');
                }
            });
            
            await page.waitForTimeout(2000);
        }

        // Check if modal closed
        const modalOpen = await page.locator('#editBookingModal.active').isVisible();
        console.log('📋 Modal still open:', modalOpen);

        // Report findings
        console.log('\n📊 Summary:');
        console.log('JavaScript Errors:', jsErrors.length);
        console.log('Console Messages:', consoleMessages.length);
        
        if (jsErrors.length > 0) {
            console.log('\n💥 JavaScript Errors Found:');
            jsErrors.forEach((error, index) => {
                console.log(`${index + 1}. ${error}`);
            });
        }

        console.log('\n📝 Recent Console Messages:');
        consoleMessages.slice(-10).forEach((msg, index) => {
            console.log(`${index + 1}. ${msg}`);
        });

        await page.screenshot({ path: 'edit-js-errors-test.png', fullPage: true });
        console.log('📸 Screenshot saved');

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        
        try {
            await page.screenshot({ path: 'edit-js-errors-error.png', fullPage: true });
            console.log('📸 Error screenshot saved');
        } catch (e) {
            console.log('📸 Could not save screenshot');
        }
    } finally {
        await browser.close();
    }

    return { jsErrors, consoleMessages };
}

if (require.main === module) {
    testEditJSErrors().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testEditJSErrors };