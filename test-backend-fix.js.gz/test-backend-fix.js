/**
 * Test Backend Fix - Verify special_requests field updates properly
 */
const { chromium } = require('playwright');

async function testBackendFix() {
    console.log('🔧 Testing Backend Fix - Special Requests Update');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 300
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Find the first booking
        const firstBooking = await page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit form...');
        await firstBooking.locator('button:has-text("Edit")').click();
        
        // Wait for modal to open
        await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
        console.log('📝 Edit modal opened');
        
        // Wait for form to populate
        await page.waitForTimeout(1000);
        
        // Check current special requests
        const specialRequestsInput = page.locator('#editSpecialRequests');
        const originalRequests = await specialRequestsInput.inputValue();
        console.log(`📋 Original special requests: "${originalRequests}"`);
        
        // Clear the special requests field completely
        await specialRequestsInput.click();
        await specialRequestsInput.selectText();
        await specialRequestsInput.press('Delete');
        
        // Verify it's empty
        const clearedRequests = await specialRequestsInput.inputValue();
        console.log(`🧹 Cleared special requests: "${clearedRequests}"`);
        
        // Save the form
        console.log('💾 Saving form...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        
        // Wait for success
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        console.log('✅ Success alert appeared');
        
        // Wait for modal to close
        await page.waitForSelector('#editBookingModal.active', { state: 'hidden', timeout: 5000 });
        console.log('🔒 Modal closed');
        
        // Wait for UI refresh
        await page.waitForTimeout(2000);
        
        // Re-open the same booking to verify
        console.log('\n🔄 Re-opening booking to verify backend save...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
        await page.waitForTimeout(1000);
        
        // Check if special requests is actually empty
        const verifyRequests = await specialRequestsInput.inputValue();
        console.log(`✅ Verified special requests: "${verifyRequests}"`);
        
        if (verifyRequests === '' || verifyRequests === clearedRequests) {
            console.log('\n🎉 SUCCESS: Backend properly saved empty special_requests!');
            console.log('✅ The bug has been fixed - special_requests field updates correctly');
        } else {
            console.log('\n❌ FAIL: Backend did not save the cleared special_requests');
            console.log(`Expected: "" or "${clearedRequests}"`);
            console.log(`Got: "${verifyRequests}"`);
        }
        
        // Close modal
        await page.locator('#editBookingModal .close').click();
        
        console.log('\n✅ Backend Fix Test Complete!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testBackendFix();