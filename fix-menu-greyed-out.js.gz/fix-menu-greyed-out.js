/**
 * Fix greyed out menu - run in browser console
 */

console.log('🔧 Fixing greyed out menu...');

// Remove any disabled attributes
document.querySelectorAll('.nav-item').forEach(item => {
    item.removeAttribute('disabled');
    item.style.pointerEvents = 'auto';
    item.style.cursor = 'pointer';
    item.style.opacity = '1';
    item.style.color = '';
    
    console.log('Fixed nav item:', item.textContent.trim());
});

// Force enable navigation clicks
document.querySelectorAll('[data-section]').forEach(nav => {
    nav.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const section = this.getAttribute('data-section');
        console.log('Clicked section:', section);
        
        // Remove active from all sections
        document.querySelectorAll('.admin-section').forEach(s => {
            s.classList.remove('active');
        });
        
        // Remove active from all nav items
        document.querySelectorAll('.nav-item').forEach(n => {
            n.classList.remove('active');
        });
        
        // Add active to clicked section
        const targetSection = document.getElementById(section);
        if (targetSection) {
            targetSection.classList.add('active');
            this.classList.add('active');
            console.log('Activated section:', section);
        }
    });
});

// Enable bookings specifically
const bookingsNav = document.querySelector('[data-section="bookings"]');
if (bookingsNav) {
    bookingsNav.click();
    console.log('✅ Bookings section activated');
}

console.log('✅ Menu should now be clickable');