const { chromium } = require('playwright');

async function testAdminRendering() {
  console.log('Testing admin page rendering...');
  
  const browser = await chromium.launch({
    headless: false,
    slowMo: 500
  });

  try {
    const page = await browser.newPage();
    
    // Navigate to admin page
    await page.goto('https://ittheal.com/admin-dashboard.html', {
      waitUntil: 'networkidle'
    });

    // Wait for page to load
    await page.waitForTimeout(2000);

    // Check for console errors
    page.on('console', msg => {
      if (msg.type() === 'error') {
        console.error('Console error:', msg.text());
      }
    });

    // Check for failed resource loads
    page.on('requestfailed', request => {
      console.error('Failed request:', request.url(), request.failure().errorText);
    });

    // Take screenshot
    await page.screenshot({ 
      path: 'admin-rendering-test.png',
      fullPage: true 
    });
    console.log('Screenshot saved as admin-rendering-test.png');

    // Check computed styles
    const bodyStyles = await page.evaluate(() => {
      const body = document.body;
      const computed = window.getComputedStyle(body);
      return {
        fontFamily: computed.fontFamily,
        background: computed.background,
        color: computed.color
      };
    });
    console.log('Body computed styles:', bodyStyles);

    // Check if buttons exist and their styles
    const buttonStyles = await page.evaluate(() => {
      const buttons = document.querySelectorAll('button, .btn, .nav-tab');
      const styles = [];
      buttons.forEach(btn => {
        const computed = window.getComputedStyle(btn);
        styles.push({
          text: btn.textContent.trim(),
          background: computed.background,
          color: computed.color,
          fontSize: computed.fontSize,
          display: computed.display
        });
      });
      return styles;
    });
    console.log('Button styles:', JSON.stringify(buttonStyles, null, 2));

    // Check for images
    const images = await page.evaluate(() => {
      const imgs = document.querySelectorAll('img');
      return Array.from(imgs).map(img => ({
        src: img.src,
        alt: img.alt,
        width: img.width,
        height: img.height,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight
      }));
    });
    console.log('Images found:', images);

    // Check if any styles are being blocked
    const blockedResources = await page.evaluate(() => {
      const links = document.querySelectorAll('link[rel="stylesheet"]');
      const blocked = [];
      links.forEach(link => {
        if (!link.sheet) {
          blocked.push(link.href);
        }
      });
      return blocked;
    });
    console.log('Blocked stylesheets:', blockedResources);

  } catch (error) {
    console.error('Test failed:', error);
  } finally {
    await browser.close();
  }
}

testAdminRendering();