/**
 * Test Edit UI Refresh - Verifies immediate UI update after booking edit
 */
const { chromium } = require('playwright');

async function testEditUIRefresh() {
    console.log('🔄 Testing Edit UI Refresh - Immediate Update Verification');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 300
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Get the first booking card
        const firstBooking = await page.locator('.booking-card').first();
        
        // Get original customer name
        const originalName = await firstBooking.locator('h3').textContent();
        console.log(`📋 Original customer name: ${originalName}`);
        
        // Click edit button
        console.log('✏️ Clicking edit button...');
        await firstBooking.locator('button:has-text("Edit")').click();
        
        // Wait for modal to open
        await page.waitForSelector('#editBookingModal.show', { timeout: 5000 });
        console.log('📝 Edit modal opened');
        
        // Modify the customer name
        const nameInput = page.locator('#editCustomerName');
        await nameInput.click();
        await nameInput.clear();
        const newName = `Test User ${Date.now()}`;
        await nameInput.type(newName);
        console.log(`✍️ Changed name to: ${newName}`);
        
        // Submit the form
        console.log('💾 Submitting edit form...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        
        // Wait for success alert
        await page.waitForSelector('.alert.alert-success:has-text("Booking updated successfully")', { timeout: 10000 });
        console.log('✅ Success alert appeared');
        
        // Wait for modal to close
        await page.waitForSelector('#editBookingModal.show', { state: 'hidden', timeout: 5000 });
        console.log('🔒 Modal closed');
        
        // Check if the booking card updated immediately
        console.log('🔍 Checking for immediate UI update...');
        
        // Wait a short moment for DOM update
        await page.waitForTimeout(1000);
        
        // Find the booking card with the new name
        const updatedBooking = await page.locator(`.booking-card:has(h3:has-text("${newName}"))`).first();
        const isVisible = await updatedBooking.isVisible();
        
        if (isVisible) {
            console.log('✅ SUCCESS: UI refreshed immediately - new name is visible!');
            
            // Verify the card shows the updated name
            const displayedName = await updatedBooking.locator('h3').textContent();
            console.log(`✅ Confirmed: Booking card shows: ${displayedName}`);
            
            // Also check that the old name is gone
            const oldNameCards = await page.locator(`.booking-card:has(h3:has-text("${originalName}"))`).count();
            if (oldNameCards === 0) {
                console.log('✅ Old name successfully replaced in UI');
            }
        } else {
            console.log('❌ FAIL: UI did not refresh - new name not visible');
            console.log('Current bookings visible:');
            const allNames = await page.locator('.booking-card h3').allTextContents();
            allNames.forEach((name, i) => console.log(`  ${i + 1}. ${name}`));
        }
        
        // Test refresh persistence
        console.log('\n🔄 Testing persistence after manual refresh...');
        await page.reload({ waitUntil: 'networkidle' });
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const persistedBooking = await page.locator(`.booking-card:has(h3:has-text("${newName}"))`).first();
        const isPersisted = await persistedBooking.isVisible();
        
        if (isPersisted) {
            console.log('✅ Edit persisted correctly in database');
        } else {
            console.log('❌ Edit did not persist after refresh');
        }
        
        console.log('\n✅ Edit UI Refresh Test Complete!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testEditUIRefresh();