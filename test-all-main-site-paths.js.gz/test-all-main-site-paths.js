/**
 * Test All Main Site Paths
 * Comprehensive check of all asset and resource paths in main site
 */

const https = require('https');

async function testAllMainSitePaths() {
    console.log('🧪 Testing ALL Main Site Paths');
    
    const pathsToTest = [
        {
            name: 'Tailwind CSS',
            url: 'https://ittheal.com/dist/tailwind.css',
            expected: 200
        },
        {
            name: 'Luxury Spa CSS',
            url: 'https://ittheal.com/dist/luxury-spa.css',
            expected: 200
        },
        {
            name: 'Favicon 32px',
            url: 'https://ittheal.com/assets/logos/itt-heal-lotus-32.png',
            expected: 200
        },
        {
            name: 'Apple Touch Icon 256px',
            url: 'https://ittheal.com/assets/logos/itt-heal-lotus-256.png',
            expected: 200
        },
        {
            name: 'Main Logo',
            url: 'https://ittheal.com/assets/logos/itt-heal-lotus.png',
            expected: 200
        },
        {
            name: 'Therapist Photo',
            url: 'https://ittheal.com/assets/therapist-photo.jpg',
            expected: 200
        },
        {
            name: 'Luxury Mobile JS',
            url: 'https://ittheal.com/js/luxury-mobile.js',
            expected: 200
        },
        {
            name: 'Pricing Booking JS',
            url: 'https://ittheal.com/js/pricing-booking.js',
            expected: 200
        },
        {
            name: 'Native Booking JS',
            url: 'https://ittheal.com/js/native-booking.js',
            expected: 200
        },
        {
            name: 'Error Handler JS',
            url: 'https://ittheal.com/js/error-handler.js',
            expected: 200
        },
        {
            name: 'Booking Availability JS',
            url: 'https://ittheal.com/js/booking-availability.js',
            expected: 200
        },
        {
            name: 'Main Site Index',
            url: 'https://ittheal.com/',
            expected: 200
        }
    ];
    
    const results = [];
    
    for (const path of pathsToTest) {
        try {
            console.log(`📡 Testing ${path.name}...`);
            
            const response = await new Promise((resolve, reject) => {
                const req = https.get(path.url, (res) => {
                    resolve({ status: res.statusCode, headers: res.headers });
                });
                req.on('error', reject);
                req.setTimeout(5000, () => reject(new Error('Request timeout')));
            });
            
            const success = response.status === path.expected;
            results.push({
                ...path,
                actual: response.status,
                success
            });
            
            console.log(`   ${success ? '✅' : '❌'} ${path.name}: ${response.status}`);
            
        } catch (error) {
            results.push({
                ...path,
                actual: 'ERROR',
                success: false,
                error: error.message
            });
            console.log(`   ❌ ${path.name}: ERROR - ${error.message}`);
        }
    }
    
    // Check main site page for problematic path references
    try {
        console.log('\n📄 Checking Main Site Path References...');
        
        const siteResponse = await new Promise((resolve, reject) => {
            const req = https.get('https://ittheal.com/', (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => resolve({ status: res.statusCode, data }));
            });
            req.on('error', reject);
            req.setTimeout(10000, () => reject(new Error('Request timeout')));
        });
        
        if (siteResponse.status === 200) {
            const pathChecks = [
                {
                    name: 'No Broken Manifest Reference',
                    pattern: 'manifest.json',
                    found: siteResponse.data.includes('manifest.json'),
                    shouldExist: false
                },
                {
                    name: 'Therapist Photo Relative Path',
                    pattern: 'src="./assets/therapist-photo.jpg"',
                    found: siteResponse.data.includes('src="./assets/therapist-photo.jpg"'),
                    shouldExist: true
                },
                {
                    name: 'No Absolute Asset Paths',
                    pattern: 'src="/assets/',
                    found: siteResponse.data.includes('src="/assets/'),
                    shouldExist: false
                },
                {
                    name: 'CSS Files Use Relative Paths',
                    pattern: 'href="./dist/',
                    found: siteResponse.data.includes('href="./dist/'),
                    shouldExist: true
                },
                {
                    name: 'JS Files Use Relative Paths',
                    pattern: 'src="./js/',
                    found: siteResponse.data.includes('src="./js/'),
                    shouldExist: true
                }
            ];
            
            pathChecks.forEach(check => {
                const isCorrect = check.shouldExist ? check.found : !check.found;
                console.log(`   ${isCorrect ? '✅' : '❌'} ${check.name}: ${isCorrect ? 'CORRECT' : 'ISSUE FOUND'}`);
                if (!isCorrect && check.shouldExist) {
                    console.log(`      Missing: ${check.pattern}`);
                } else if (!isCorrect && !check.shouldExist) {
                    console.log(`      Found problematic: ${check.pattern}`);
                }
            });
            
            const allPathsCorrect = pathChecks.every(check => 
                check.shouldExist ? check.found : !check.found
            );
            const allResourcesLoading = results.every(result => result.success);
            
            console.log('\n📊 SUMMARY:');
            console.log(`✅ All resources accessible: ${allResourcesLoading ? 'YES' : 'NO'}`);
            console.log(`✅ All paths correctly formatted: ${allPathsCorrect ? 'YES' : 'NO'}`);
            
            if (allResourcesLoading && allPathsCorrect) {
                console.log('\n🎯 SUCCESS! All main site paths are correct');
                console.log('✅ No 404 errors for any resources');
                console.log('✅ All paths use consistent relative formatting');
                console.log('✅ No broken references to missing files');
                console.log('✅ CSS, images, and JavaScript files all load properly');
                return true;
            } else {
                console.log('\n❌ Some paths still have issues');
                results.forEach(result => {
                    if (!result.success) {
                        console.log(`   - ${result.name}: ${result.actual} (expected ${result.expected})`);
                    }
                });
                return false;
            }
        }
        
    } catch (error) {
        console.error('❌ Failed to check main site paths:', error.message);
        return false;
    }
}

if (require.main === module) {
    testAllMainSitePaths().then(success => {
        if (success) {
            console.log('\n🎉 All main site paths test PASSED');
            console.log('\n📝 PATH CORRECTIONS MADE:');
            console.log('   Removed: Non-existent manifest.json reference');
            console.log('   Fixed: src="/assets/therapist-photo.jpg" → src="./assets/therapist-photo.jpg"');
            console.log('   Verified: All other assets use correct relative paths');
            process.exit(0);
        } else {
            console.log('\n💥 Main site paths test FAILED');
            process.exit(1);
        }
    });
}

module.exports = { testAllMainSitePaths };