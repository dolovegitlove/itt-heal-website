const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging time slot loading issue...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Track console logs
  page.on('console', msg => console.log('PAGE:', msg.text()));
  page.on('pageerror', error => console.log('ERROR:', error.message));
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  console.log('📊 Page loaded');
  
  // Step 1: Service selection
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  console.log('📅 Step 2: About to fill date');
  
  // Fill date and check what happens
  await page.fill('#booking-date', '2025-07-14');
  console.log('📅 Date filled, waiting for time slots...');
  
  await page.waitForTimeout(5000);
  
  // Check dropdown state
  const timeSelectState = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    if (!timeSelect) return { exists: false };
    
    const options = Array.from(timeSelect.options);
    return {
      exists: true,
      disabled: timeSelect.disabled,
      optionCount: options.length,
      options: options.map(opt => ({ value: opt.value, text: opt.textContent }))
    };
  });
  
  console.log('⏰ Time select state:', JSON.stringify(timeSelectState, null, 2));
  
  // Check if BookingAvailability is working
  const availabilityCheck = await page.evaluate(() => {
    return {
      BookingAvailabilityExists: typeof window.BookingAvailability !== 'undefined',
      loadTimeSlotsFunction: typeof window.BookingAvailability?.loadTimeSlots === 'function'
    };
  });
  
  console.log('📋 Availability module check:', availabilityCheck);
  
  await browser.close();
})().catch(console.error);