const { chromium } = require('playwright');

async function testBookingFlow() {
  console.log('🖥️  Starting Complete Booking Test (X11)...\n');
  
  const browser = await chromium.launch({
    headless: false, // Show browser for X11
    slowMo: 500, // Slower for observation
    args: [
      '--disable-blink-features=AutomationControlled',
      '--disable-web-security', 
      '--window-size=1920,1080',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-software-rasterizer'
    ]
  });

  let testResults = {
    step1: 'pending',
    step2: 'pending', 
    step3: 'pending',
    step4: 'pending',
    step5: 'pending'
  };

  try {
    const context = await browser.newContext({
      viewport: { width: 1920, height: 1080 }
    });

    const page = await context.newPage();

    console.log('📊 Navigating to ITT website...');
    await page.goto('https://ittheal.com');
    await page.waitForLoadState('networkidle');
    
    console.log('✅ Page loaded successfully');

    // Step 1: Service Selection
    console.log('\n🎯 STEP 1: Service Selection');
    await page.waitForSelector('.service-option', { timeout: 10000 });
    
    console.log('   🖱️  Selecting 90-Min Full Reset...');
    await page.click('[data-service="90min"]');
    await page.waitForTimeout(2000);
    
    console.log('   🖱️  Clicking Next Step...');
    await page.click('#next-btn');
    await page.waitForTimeout(3000);
    
    testResults.step1 = 'completed';
    console.log('✅ Step 1 completed');

    // Step 2: Date/Time Selection
    console.log('\n📅 STEP 2: Date/Time Selection');
    await page.waitForSelector('#datetime-selection', { visible: true, timeout: 10000 });
    
    console.log('   📅 Selecting valid business day...');
    
    // Use a known business day: Monday 2025-07-14
    const testDate = new Date('2025-07-14');
    const dateStr = '2025-07-14';
    console.log(`   📅 Selected date: ${dateStr} (${testDate.toLocaleDateString('en-US', { weekday: 'long' })})`);
    
    // Real user interaction for date input (CLAUDE.md compliance)
    await page.locator('#booking-date').click();
    await page.waitForTimeout(300);
    await page.keyboard.press('Control+a');
    await page.waitForTimeout(200);
    await page.keyboard.type(dateStr);
    await page.waitForTimeout(300);
    await page.waitForTimeout(3000); // Wait for times to load
    
    console.log('   ⏰ Waiting for available times...');
    // Wait for time options to be populated (looking for options with time values)
    await page.waitForFunction(() => {
      const timeSelect = document.getElementById('booking-time');
      if (!timeSelect) return false;
      const options = timeSelect.querySelectorAll('option[value]:not([value=""])');
      return options.length > 0;
    }, { timeout: 15000 });
    
    console.log('   🖱️  Selecting first available time...');
    await page.selectOption('#booking-time', { index: 1 });
    await page.waitForTimeout(1000);
    
    console.log('   🖱️  Clicking Next Step...');
    await page.click('#next-btn');
    await page.waitForTimeout(2000);
    
    testResults.step2 = 'completed';
    console.log('✅ Step 2 completed');

    // Step 3: Client Information
    console.log('\n👤 STEP 3: Client Information');
    await page.waitForSelector('#contact-info', { visible: true, timeout: 10000 });
    
    console.log('   ✍️  Filling client information with real typing (CLAUDE.md compliance)...');
    
    // Real typing for client name
    await page.locator('#client-name').click();
    await page.waitForTimeout(300);
    await page.keyboard.type('Test User');
    await page.waitForTimeout(300);
    
    // Real typing for email
    await page.locator('#client-email').click();
    await page.waitForTimeout(300);
    await page.keyboard.type('test@example.com');
    await page.waitForTimeout(300);
    
    // Real typing for phone
    await page.locator('#client-phone').click();
    await page.waitForTimeout(300);
    await page.keyboard.type('555-123-4567');
    await page.waitForTimeout(300);
    await page.waitForTimeout(1000);
    
    console.log('   🖱️  Clicking Next Step...');
    await page.click('#next-btn');
    await page.waitForTimeout(2000);
    
    testResults.step3 = 'completed';
    console.log('✅ Step 3 completed');

    // Step 4: Payment Information
    console.log('\n💳 STEP 4: Payment Information');
    
    // Wait a bit for any transition to complete
    await page.waitForTimeout(3000);
    
    // Check if payment info is visible, if not try to make it visible
    const paymentInfoVisible = await page.isVisible('#payment-info');
    console.log(`   💳 Payment info visible: ${paymentInfoVisible}`);
    
    if (!paymentInfoVisible) {
      console.log('   ⚠️  Payment info not visible, checking form state...');
      
      // Debug what step we're on
      const currentState = await page.evaluate(() => {
        const steps = ['service-selection', 'datetime-selection', 'contact-info', 'payment-info', 'booking-summary'];
        return steps.map(stepId => {
          const el = document.getElementById(stepId);
          return {
            id: stepId,
            visible: el ? el.offsetParent !== null : false,
            display: el ? getComputedStyle(el).display : 'none'
          };
        });
      });
      
      console.log('   📊 Current form state:');
      currentState.forEach(step => {
        console.log(`     ${step.id}: visible=${step.visible}, display=${step.display}`);
      });
      
      // Try to manually show payment-info for testing
      await page.evaluate(() => {
        const contactInfo = document.getElementById('contact-info');
        const paymentInfo = document.getElementById('payment-info');
        if (contactInfo && paymentInfo) {
          contactInfo.style.display = 'none';
          paymentInfo.style.display = 'block';
          paymentInfo.style.opacity = '1';
          console.log('Manually transitioned to payment step for testing');
        }
      });
    }
    
    // Now wait for payment info to be visible
    await page.waitForSelector('#payment-info', { visible: true, timeout: 5000 });
    
    // Check if regular payment is selected by default
    const isRegularSelected = await page.isChecked('input[name="payment-method"][value="regular"]');
    if (!isRegularSelected) {
      console.log('   🖱️  Selecting regular payment...');
      await page.click('input[name="payment-method"][value="regular"]');
      await page.waitForTimeout(1000);
    }
    
    console.log('   💰 Adding tip...');
    await page.click('input[name="tip"][value="20"]');
    await page.waitForTimeout(1000);
    
    console.log('   💳 Filling payment details...');
    await page.fill('#card-number', '4242424242424242');
    await page.fill('#card-expiry', '12/25');
    await page.fill('#card-cvc', '123');
    await page.fill('#card-name', 'Test User');
    await page.waitForTimeout(1000);
    
    console.log('   🖱️  Clicking Next Step...');
    await page.click('#next-btn');
    await page.waitForTimeout(2000);
    
    testResults.step4 = 'completed';
    console.log('✅ Step 4 completed');

    // Step 5: Booking Confirmation
    console.log('\n📋 STEP 5: Booking Confirmation');
    await page.waitForSelector('#booking-summary', { visible: true, timeout: 10000 });
    
    console.log('   📊 Reviewing booking summary...');
    const totalPrice = await page.textContent('#total-price');
    console.log(`   💰 Total price: ${totalPrice}`);
    
    console.log('   🖱️  Confirming booking...');
    await page.click('#confirm-booking-btn');
    
    console.log('   ⏳ Waiting for booking confirmation...');
    await page.waitForSelector('.booking-success, .success-message', { timeout: 30000 });
    
    testResults.step5 = 'completed';
    console.log('✅ Step 5 completed');

    console.log('\n🎉 BOOKING TEST COMPLETED SUCCESSFULLY!');
    console.log('📊 Test Results:', testResults);

    // Keep browser open for 10 seconds to observe results
    console.log('\n⏳ Keeping browser open for 10 seconds...');
    await page.waitForTimeout(10000);

  } catch (error) {
    console.error('❌ Booking test failed:', error.message);
    console.log('📊 Test Results at failure:', testResults);
    
    // Take screenshot of failure
    try {
      await page.screenshot({ path: 'booking-test-failure.png', fullPage: true });
      console.log('📸 Screenshot saved as booking-test-failure.png');
    } catch (screenshotError) {
      console.log('❌ Could not take screenshot:', screenshotError.message);
    }
    
    // Keep browser open for debugging
    console.log('\n🔍 Keeping browser open for debugging (30 seconds)...');
    await page.waitForTimeout(30000);
  } finally {
    await browser.close();
  }
}

// Run the test
testBookingFlow().catch(console.error);