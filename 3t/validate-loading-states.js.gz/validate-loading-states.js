/**
 * Loading States Validator
 * Detects forms and buttons missing proper loading state management
 */

const fs = require('fs');
const path = require('path');

function validateLoadingStates() {
    console.log('⏳ Validating Loading States Across All Forms');
    
    const issues = [];
    const htmlFiles = [
        'index.html',
        'admin/index.html',
        'booking-confirmation.html'
    ];

    htmlFiles.forEach(filePath => {
        const fullPath = path.join(__dirname, filePath);
        if (!fs.existsSync(fullPath)) return;

        const content = fs.readFileSync(fullPath, 'utf8');
        console.log(`🔍 Checking ${filePath}...`);

        // Find all forms
        const formMatches = content.match(/<form[^>]*id="([^"]*)"[^>]*>/g) || [];
        
        formMatches.forEach(formTag => {
            const formIdMatch = formTag.match(/id="([^"]*)"/);
            if (!formIdMatch) return;
            
            const formId = formIdMatch[1];
            console.log(`  📝 Analyzing form: ${formId}`);

            // Check if form has submit event listener
            const submitListenerRegex = new RegExp(`document\\.getElementById\\('${formId}'\\)\\.addEventListener\\('submit'`, 'g');
            const hasSubmitListener = submitListenerRegex.test(content);

            if (!hasSubmitListener) {
                issues.push({
                    file: filePath,
                    form: formId,
                    type: 'HIGH',
                    category: 'FORM_SUBMISSION',
                    issue: 'Form has no submit event listener',
                    impact: 'Form may not function at all'
                });
                return;
            }

            // Find the submit listener code block
            const submitRegex = new RegExp(
                `document\\.getElementById\\('${formId}'\\)\\.addEventListener\\('submit'[\\s\\S]*?\\}\\);`,
                'g'
            );
            const submitMatch = content.match(submitRegex);
            
            if (!submitMatch) return;
            
            const submitCode = submitMatch[0];

            // Check for loading state patterns
            const loadingStateChecks = [
                {
                    pattern: /submitButton\.disabled\s*=\s*true/,
                    issue: 'Submit button not disabled during submission',
                    impact: 'Users may double-click and cause issues'
                },
                {
                    pattern: /textContent\s*=\s*['"][^'"]*ing\.\.\.['"]|innerHTML\s*=\s*['"][^'"]*ing\.\.\.['"]/, 
                    issue: 'No loading text feedback (like "Saving..." or "Updating...")',
                    impact: 'Users unsure if submission is in progress'
                },
                {
                    pattern: /finally\s*\{[\s\S]*submitButton\.disabled\s*=\s*false/,
                    issue: 'No finally block to reset button state',
                    impact: 'Button may stay disabled if submission fails'
                },
                {
                    pattern: /finally\s*\{[\s\S]*textContent\s*=\s*originalText/,
                    issue: 'Button text not reset in finally block',
                    impact: 'Button may show loading text permanently on error'
                }
            ];

            loadingStateChecks.forEach(check => {
                if (!check.pattern.test(submitCode)) {
                    issues.push({
                        file: filePath,
                        form: formId,
                        type: 'MEDIUM',
                        category: 'LOADING_STATE',
                        issue: check.issue,
                        impact: check.impact
                    });
                }
            });

            // Check for proper error handling
            if (!submitCode.includes('catch')) {
                issues.push({
                    file: filePath,
                    form: formId,
                    type: 'HIGH',
                    category: 'ERROR_HANDLING',
                    issue: 'No error handling in form submission',
                    impact: 'Errors may cause unhandled exceptions'
                });
            }

            // Check for fetch or API calls
            if (!submitCode.includes('fetch(') && !submitCode.includes('$.post') && !submitCode.includes('$.ajax')) {
                issues.push({
                    file: filePath,
                    form: formId,
                    type: 'CRITICAL',
                    category: 'API_INTEGRATION',
                    issue: 'Form submission has no API call',
                    impact: 'Form appears to work but saves nothing'
                });
            }
        });

        // Check for standalone buttons that might need loading states
        const buttonMatches = content.match(/<button[^>]*onclick="[^"]*"[^>]*>/g) || [];
        buttonMatches.forEach(buttonTag => {
            const onclickMatch = buttonTag.match(/onclick="([^"]*)"/);
            if (!onclickMatch) return;

            const onclick = onclickMatch[1];
            
            // Check if onclick calls functions that might need loading states
            const asyncFunctionCalls = ['save', 'update', 'delete', 'create', 'submit'];
            const callsAsyncFunction = asyncFunctionCalls.some(func => onclick.includes(func));
            
            if (callsAsyncFunction && !content.includes(`function ${onclick.split('(')[0]}`)) {
                issues.push({
                    file: filePath,
                    button: onclick,
                    type: 'MEDIUM',
                    category: 'BUTTON_LOADING',
                    issue: 'Button calls async function but may lack loading state',
                    impact: 'Button may not provide feedback during async operations'
                });
            }
        });
    });

    // Generate report
    console.log('\n📊 Loading States Validation Report');
    console.log('====================================');
    
    if (issues.length === 0) {
        console.log('✅ All forms have proper loading state management');
        return issues;
    }

    const critical = issues.filter(i => i.type === 'CRITICAL');
    const high = issues.filter(i => i.type === 'HIGH');
    const medium = issues.filter(i => i.type === 'MEDIUM');

    console.log(`🚨 CRITICAL Issues: ${critical.length}`);
    console.log(`⚠️  HIGH Issues: ${high.length}`);
    console.log(`⚡ MEDIUM Issues: ${medium.length}`);

    // Group by file
    const issuesByFile = {};
    issues.forEach(issue => {
        if (!issuesByFile[issue.file]) {
            issuesByFile[issue.file] = [];
        }
        issuesByFile[issue.file].push(issue);
    });

    Object.keys(issuesByFile).forEach(file => {
        console.log(`\n📁 ${file}:`);
        issuesByFile[file].forEach((issue, index) => {
            const formInfo = issue.form ? ` (Form: ${issue.form})` : issue.button ? ` (Button: ${issue.button})` : '';
            console.log(`  ${index + 1}. [${issue.type}] ${issue.issue}${formInfo}`);
            console.log(`     Impact: ${issue.impact}`);
        });
    });

    console.log('\n🔧 Quick Fixes:');
    console.log('• Add submitButton.disabled = true before async calls');
    console.log('• Add loading text: submitButton.textContent = "Saving..."');
    console.log('• Use finally {} blocks to reset button states');
    console.log('• Add proper error handling with try/catch');

    return issues;
}

if (require.main === module) {
    const issues = validateLoadingStates();
    const hasIssues = issues.length > 0;
    process.exit(hasIssues ? 1 : 0);
}

module.exports = { validateLoadingStates };