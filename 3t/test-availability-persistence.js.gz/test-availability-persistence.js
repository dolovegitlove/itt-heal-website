/**
 * FOCUSED AVAILABILITY PERSISTENCE TEST
 * Tests the specific issue with available times persisting
 * Uses LIVE backend and real browser interactions
 */

const { chromium } = require('playwright');

async function testAvailabilityPersistence() {
    console.log('🚀 Starting Availability Persistence Test with Live Backend...');
    console.log('🎯 TESTING: Available times loading and persistence');
    console.log('🌐 USING: Live backend at https://ittheal.com\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    let successCount = 0;
    let failureCount = 0;
    const testResults = [];
    
    try {
        for (let testRun = 1; testRun <= 12; testRun++) {
            console.log(`\n=== TEST RUN ${testRun}/12 ===`);
            
            try {
                // Step 1: Navigate to live site
                console.log('📍 Navigating to live booking page...');
                await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
                await page.waitForTimeout(2000);
                
                // Scroll to booking section
                await page.locator('#booking').scrollIntoViewIfNeeded();
                await page.waitForTimeout(1000);
                
                // Step 2: Select service
                console.log('📍 Selecting 60-minute massage service...');
                const serviceOption = page.locator('[data-service-type="60min_massage"]');
                await serviceOption.click();
                await page.waitForTimeout(1000);
                
                // Step 3: Click Next
                console.log('📍 Clicking Next to proceed...');
                await page.locator('#next-btn').click();
                await page.waitForTimeout(2000);
                
                // Step 4: Select a valid future date
                console.log('📍 Selecting a valid future date...');
                const dateInput = page.locator('#booking-date');
                await dateInput.click();
                await page.waitForTimeout(500);
                
                // Clear and enter a date 2 weeks from now (business day)
                await page.keyboard.press('Control+a');
                await page.waitForTimeout(200);
                await page.keyboard.press('Delete');
                await page.waitForTimeout(200);
                
                // Calculate a Monday 2 weeks from now
                const futureDate = new Date();
                futureDate.setDate(futureDate.getDate() + 14);
                while (futureDate.getDay() !== 1) { // Make it a Monday
                    futureDate.setDate(futureDate.getDate() + 1);
                }
                
                const dateString = futureDate.toLocaleDateString('en-US', {
                    month: '2-digit',
                    day: '2-digit',
                    year: 'numeric'
                }).replace(/\//g, '');
                
                await page.keyboard.type(dateString);
                await page.waitForTimeout(500);
                await page.keyboard.press('Tab');
                
                console.log(`Date entered: ${dateString}`);
                
                // Step 5: CRITICAL TEST - Wait for availability to load
                console.log('📍 CRITICAL: Waiting for availability to load...');
                
                // Monitor the time select dropdown
                const timeSelect = page.locator('#booking-time');
                
                // Wait up to 10 seconds for options to load
                let optionsLoaded = false;
                let loadAttempts = 0;
                const maxAttempts = 20; // 10 seconds with 500ms intervals
                
                while (!optionsLoaded && loadAttempts < maxAttempts) {
                    loadAttempts++;
                    await page.waitForTimeout(500);
                    
                    const optionCount = await timeSelect.locator('option').count();
                    const isDisabled = await timeSelect.getAttribute('disabled');
                    
                    console.log(`  Attempt ${loadAttempts}: ${optionCount} options, disabled: ${isDisabled}`);
                    
                    if (optionCount > 1 && !isDisabled) {
                        optionsLoaded = true;
                        console.log(`✅ Availability loaded successfully after ${loadAttempts * 500}ms`);
                    }
                }
                
                if (!optionsLoaded) {
                    throw new Error(`❌ Availability failed to load after ${maxAttempts * 500}ms`);
                }
                
                // Step 6: Test time selection persistence
                console.log('📍 Testing time selection persistence...');
                
                // Get available options
                const options = await timeSelect.locator('option:not([value=""])').all();
                if (options.length === 0) {
                    throw new Error('❌ No time options available');
                }
                
                // Select first available time
                const firstOption = options[0];
                const timeValue = await firstOption.getAttribute('value');
                const timeText = await firstOption.textContent();
                
                console.log(`  Selecting time: ${timeText} (${timeValue})`);
                
                // Real user interaction - click dropdown then option
                await timeSelect.click();
                await page.waitForTimeout(300);
                await firstOption.click();
                await page.waitForTimeout(1000);
                
                // Verify selection persisted
                const selectedValue = await timeSelect.inputValue();
                if (selectedValue !== timeValue) {
                    throw new Error(`❌ Time selection did not persist: expected ${timeValue}, got ${selectedValue}`);
                }
                
                console.log(`✅ Time selection persisted: ${selectedValue}`);
                
                // Step 7: Test clicking away and back
                console.log('📍 Testing selection persistence after focus change...');
                
                // Click somewhere else to lose focus
                await page.locator('body').click();
                await page.waitForTimeout(500);
                
                // Check if selection is still there
                const persistedValue = await timeSelect.inputValue();
                if (persistedValue !== timeValue) {
                    throw new Error(`❌ Time selection lost after focus change: expected ${timeValue}, got ${persistedValue}`);
                }
                
                console.log(`✅ Time selection survived focus change: ${persistedValue}`);
                
                // Step 8: Try to proceed to next step
                console.log('📍 Testing proceeding to next step...');
                
                const nextBtn = page.locator('#next-btn');
                await nextBtn.click();
                await page.waitForTimeout(2000);
                
                // Check if we progressed or got an error
                const contactVisible = await page.locator('#contact-info').isVisible();
                const errorVisible = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').count();
                
                if (contactVisible) {
                    console.log(`✅ Successfully progressed to contact info`);
                    successCount++;
                    testResults.push({
                        run: testRun,
                        status: 'SUCCESS',
                        timeValue: timeValue,
                        timeText: timeText,
                        loadTime: loadAttempts * 500
                    });
                } else if (errorVisible > 0) {
                    const errorText = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').first().textContent();
                    throw new Error(`❌ Validation error prevented progress: ${errorText}`);
                } else {
                    throw new Error('❌ Failed to progress - unknown reason');
                }
                
            } catch (error) {
                console.error(`❌ TEST RUN ${testRun} FAILED: ${error.message}`);
                failureCount++;
                testResults.push({
                    run: testRun,
                    status: 'FAILURE',
                    error: error.message
                });
            }
            
            // Reset for next test
            if (testRun < 12) {
                console.log('🔄 Resetting for next test...');
                await page.goto('about:blank');
                await page.waitForTimeout(1000);
            }
        }
        
        // Final Results
        console.log('\n' + '='.repeat(60));
        console.log('📊 AVAILABILITY PERSISTENCE TEST RESULTS');
        console.log('='.repeat(60));
        console.log(`✅ Successful tests: ${successCount}/12 (${Math.round(successCount/12*100)}%)`);
        console.log(`❌ Failed tests: ${failureCount}/12 (${Math.round(failureCount/12*100)}%)`);
        
        if (successCount < 12) {
            console.log('\n🚨 PERSISTENCE ISSUES DETECTED:');
            const failures = testResults.filter(r => r.status === 'FAILURE');
            failures.forEach(failure => {
                console.log(`  Run ${failure.run}: ${failure.error}`);
            });
        }
        
        if (successCount >= 10) {
            console.log('\n✅ MOSTLY RELIABLE (≥83% success rate)');
        } else if (successCount >= 8) {
            console.log('\n⚠️ MODERATELY RELIABLE (67-82% success rate)');
        } else {
            console.log('\n❌ UNRELIABLE (<67% success rate) - NEEDS FIXING');
        }
        
        // Success pattern analysis
        if (successCount > 0) {
            const successes = testResults.filter(r => r.status === 'SUCCESS');
            const avgLoadTime = successes.reduce((sum, s) => sum + s.loadTime, 0) / successes.length;
            console.log(`\n📈 Average successful load time: ${avgLoadTime}ms`);
            
            const loadTimes = successes.map(s => s.loadTime);
            console.log(`📈 Load time range: ${Math.min(...loadTimes)}ms - ${Math.max(...loadTimes)}ms`);
        }
        
        console.log('\n🎯 Target: 100% success rate required for production');
        
        // Keep browser open for inspection
        console.log('\n🔍 Keeping browser open for 30 seconds for inspection...');
        await page.waitForTimeout(30000);
        
    } catch (error) {
        console.error('\n💥 OVERALL TEST FAILURE:', error.message);
        await page.screenshot({ path: 'availability-test-failure.png', fullPage: true });
    } finally {
        await browser.close();
    }
    
    return {
        successCount,
        failureCount,
        totalTests: 12,
        successRate: Math.round(successCount/12*100),
        testResults
    };
}

// Execute
if (require.main === module) {
    testAvailabilityPersistence()
        .then((results) => {
            console.log('\n✅ Availability persistence test completed');
            if (results.successRate < 100) {
                console.log(`❌ ISSUE CONFIRMED: Only ${results.successRate}% success rate`);
                process.exit(1);
            } else {
                console.log(`✅ PERFECT: 100% success rate achieved`);
                process.exit(0);
            }
        })
        .catch((error) => {
            console.error('\n❌ Test execution failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testAvailabilityPersistence };