const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging form step visibility...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  console.log('📊 Initial page loaded');
  
  // Step 1: Service selection
  console.log('🎯 Step 1: Service selection');
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 2: Date/time
  console.log('📅 Step 2: Date/time selection');
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  await page.selectOption('#booking-time', { index: 1 });
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 3: Client info  
  console.log('👤 Step 3: Client information');
  await page.fill('#client-name', 'Test User');
  await page.fill('#client-email', 'test@example.com');
  await page.fill('#client-phone', '555-123-4567');
  await page.click('#next-btn');
  await page.waitForTimeout(3000);
  
  // Check current form state
  console.log('🔍 Checking form steps visibility...');
  const steps = await page.evaluate(() => {
    const stepElements = [
      'service-selection',
      'datetime-selection', 
      'contact-info',
      'payment-info',
      'booking-summary'
    ];
    
    return stepElements.map(stepId => {
      const el = document.getElementById(stepId);
      return {
        id: stepId,
        exists: el !== null,
        visible: el ? el.offsetParent !== null : false,
        display: el ? getComputedStyle(el).display : 'none',
        classList: el ? Array.from(el.classList) : []
      };
    });
  });
  
  console.log('📊 Form steps status:');
  steps.forEach(step => {
    console.log(`  ${step.id}: exists=${step.exists}, visible=${step.visible}, display=${step.display}, classes=[${step.classList.join(', ')}]`);
  });
  
  // Check if there are any error messages
  const errors = await page.evaluate(() => {
    const errorElements = document.querySelectorAll('.error, .error-message, .validation-error');
    return Array.from(errorElements).map(el => ({
      text: el.textContent.trim(),
      visible: el.offsetParent !== null
    }));
  });
  
  if (errors.length > 0) {
    console.log('❌ Error messages found:');
    errors.forEach(error => console.log(`  - ${error.text} (visible: ${error.visible})`));
  }
  
  // Check form validation state
  const formState = await page.evaluate(() => {
    const form = document.querySelector('#booking-form');
    if (!form) return { exists: false };
    
    const requiredFields = form.querySelectorAll('[required]');
    const validationState = Array.from(requiredFields).map(field => ({
      id: field.id,
      name: field.name,
      value: field.value,
      valid: field.checkValidity(),
      required: field.hasAttribute('required')
    }));
    
    return {
      exists: true,
      formValid: form.checkValidity(),
      requiredFields: validationState
    };
  });
  
  console.log('📋 Form validation state:', JSON.stringify(formState, null, 2));
  
  await browser.close();
})().catch(console.error);