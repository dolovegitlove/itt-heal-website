const { chromium } = require('playwright');

async function debugRecurringError() {
  const browser = await chromium.launch({ 
    headless: false,
    slowMo: 800, // Even slower to mimic real user
    args: ['--window-size=1200,900']
  });

  try {
    const page = await browser.newPage();
    
    // Capture ALL interactions and errors
    const allLogs = [];
    page.on('console', msg => {
      const text = msg.text();
      allLogs.push(`[${msg.type().toUpperCase()}] ${text}`);
      console.log(`[DEBUG] ${text}`);
    });
    
    // Capture any alerts that appear
    page.on('dialog', dialog => {
      console.log(`🚨 ALERT: "${dialog.message()}"`);
      dialog.accept();
    });
    
    await page.goto('https://ittheal.com/3t/');
    
    console.log('🔍 INVESTIGATING: Why error keeps coming back...\n');
    
    // Step 1: Service selection
    console.log('👤 Real user flow - selecting service...');
    await page.click('[data-service="90min"]');
    await page.waitForTimeout(3000);
    
    // Check initial date value
    const initialState = await page.evaluate(() => {
      const dateInput = document.getElementById('booking-date');
      const timeSelect = document.getElementById('booking-time');
      
      return {
        dateValue: dateInput?.value || 'no value',
        dateType: dateInput?.type || 'no type',
        timeValue: timeSelect?.value || 'no value',
        timeSelectedIndex: timeSelect?.selectedIndex || -1,
        closedDatesCount: window.closedDates?.length || 0
      };
    });
    
    console.log('📊 Initial state after service selection:', initialState);
    
    // Real user interaction - click on calendar
    console.log('\n👤 User clicks on calendar to select date...');
    
    // Wait for calendar to be ready
    await page.waitForTimeout(2000);
    
    // Click on the first available calendar cell
    const calendarInteraction = await page.evaluate(() => {
      const cells = document.querySelectorAll('[role="gridcell"]');
      const availableCells = Array.from(cells).filter(cell => 
        !cell.classList.contains('disabled') && 
        cell.textContent.trim() !== ''
      );
      
      console.log('📅 Total calendar cells:', cells.length);
      console.log('📅 Available cells:', availableCells.length);
      
      if (availableCells.length > 0) {
        const firstAvailable = availableCells[0];
        console.log('📅 Clicking cell with text:', firstAvailable.textContent);
        firstAvailable.click();
        
        return {
          success: true,
          cellText: firstAvailable.textContent,
          cellClicked: true
        };
      }
      
      return { success: false, reason: 'No available cells' };
    });
    
    console.log('Calendar interaction:', calendarInteraction);
    await page.waitForTimeout(2000);
    
    // Check date value after calendar click
    const afterCalendarState = await page.evaluate(() => {
      const dateInput = document.getElementById('booking-date');
      const timeSelect = document.getElementById('booking-time');
      
      return {
        dateValue: dateInput?.value || 'no value',
        timeOptionsCount: timeSelect?.options?.length || 0,
        timeValue: timeSelect?.value || 'no value'
      };
    });
    
    console.log('📊 After calendar click:', afterCalendarState);
    
    // User selects time
    console.log('\n👤 User selects time from dropdown...');
    
    // Click on time dropdown
    await page.click('#booking-time');
    await page.waitForTimeout(500);
    
    // Select first available time
    await page.selectOption('#booking-time', { index: 1 });
    await page.waitForTimeout(1000);
    
    const afterTimeSelection = await page.evaluate(() => {
      const timeSelect = document.getElementById('booking-time');
      return {
        selectedIndex: timeSelect?.selectedIndex || -1,
        selectedValue: timeSelect?.value || 'no value',
        selectedText: timeSelect?.options?.[timeSelect.selectedIndex]?.text || 'no text'
      };
    });
    
    console.log('⏰ After time selection:', afterTimeSelection);
    
    // Check final validation state
    const preValidationState = await page.evaluate(() => {
      const dateInput = document.getElementById('booking-date');
      const timeSelect = document.getElementById('booking-time');
      const date = dateInput?.value;
      const time = timeSelect?.value;
      const isTimeSelected = time && time.trim() !== '' && timeSelect?.selectedIndex > 0;
      const isClosedDate = typeof isDateClosed === 'function' ? isDateClosed(date) : 'function not found';
      
      return {
        date: date,
        time: time,
        dateValid: !!date && date.length > 0,
        timeValid: !!time && time.length > 0,
        isTimeSelected: isTimeSelected,
        isClosedDate: isClosedDate,
        willPassBasicValidation: !(!date || !time || date.trim() === '' || !isTimeSelected),
        willPassClosedDateValidation: isClosedDate !== true
      };
    });
    
    console.log('\n📊 PRE-VALIDATION STATE:');
    console.log('Date:', preValidationState.date);
    console.log('Time:', preValidationState.time);
    console.log('Date valid:', preValidationState.dateValid);
    console.log('Time valid:', preValidationState.timeValid);
    console.log('Is time selected:', preValidationState.isTimeSelected);
    console.log('Is closed date:', preValidationState.isClosedDate);
    console.log('Will pass basic validation:', preValidationState.willPassBasicValidation);
    console.log('Will pass closed date validation:', preValidationState.willPassClosedDateValidation);
    
    // User clicks Next
    console.log('\n👤 User clicks Next button...');
    await page.click('#next-btn');
    
    // Wait for any processing
    await page.waitForTimeout(5000);
    
    // Check final state
    const finalState = await page.evaluate(() => {
      const contactStep = document.getElementById('contact-info');
      const datetimeStep = document.getElementById('datetime-selection');
      
      return {
        currentStep: window.currentStep,
        onContactStep: contactStep && window.getComputedStyle(contactStep).display !== 'none',
        stillOnDatetime: datetimeStep && window.getComputedStyle(datetimeStep).display !== 'none',
        url: window.location.href
      };
    });
    
    console.log('\n📊 FINAL STATE:');
    console.log('Current step:', finalState.currentStep);
    console.log('On contact step:', finalState.onContactStep);
    console.log('Still on datetime:', finalState.stillOnDatetime);
    console.log('URL:', finalState.url);
    
    if (finalState.stillOnDatetime) {
      console.log('\n❌ USER IS STUCK ON DATETIME STEP!');
      console.log('This is the recurring error users experience.');
      
      // Look for the specific validation that failed
      const validationLogs = allLogs.filter(log => 
        log.includes('validation') || 
        log.includes('closed') || 
        log.includes('Date/time') ||
        log.includes('alert') ||
        log.includes('❌')
      );
      
      console.log('\n🔍 VALIDATION LOGS:');
      validationLogs.forEach((log, i) => console.log(`${i+1}. ${log}`));
      
    } else if (finalState.onContactStep) {
      console.log('\n✅ User successfully progressed');
    }
    
    await page.waitForTimeout(3000);
    
  } catch (error) {
    console.error('❌ Recurring error debug failed:', error);
  } finally {
    await browser.close();
  }
}

debugRecurringError().catch(console.error);