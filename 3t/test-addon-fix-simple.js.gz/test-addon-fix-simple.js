/**
 * Simple Add-on Fix Test - Direct test for persistence
 */
const { chromium } = require('playwright');

async function testAddonFix() {
    console.log('🔧 Testing Add-on Fix - Simple Direct Test');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        // Wait longer for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        // Check if we have bookings
        const bookingsExist = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingsExist} bookings`);
        
        if (bookingsExist === 0) {
            console.log('⚠️ No bookings found, cannot test add-on persistence');
            return;
        }
        
        // Get the first booking
        const firstBooking = await page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit form...');
        await firstBooking.locator('button:has-text("Edit")').click();
        
        // Wait for modal with longer timeout
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        console.log('📝 Edit modal opened');
        
        // Wait for form to populate
        await page.waitForTimeout(1500);
        
        // Focus on special requests field
        const specialRequestsInput = page.locator('#editSpecialRequests');
        const originalValue = await specialRequestsInput.inputValue();
        console.log(`📋 Original special requests: "${originalValue}"`);
        
        // Clear it by setting to empty string
        await specialRequestsInput.fill('');
        const clearedValue = await specialRequestsInput.inputValue();
        console.log(`🧹 Cleared to: "${clearedValue}"`);
        
        // Submit the form
        console.log('💾 Submitting form...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        
        // Wait for success alert
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        console.log('✅ Success alert appeared');
        
        // Wait for modal to close
        await page.waitForTimeout(2000);
        
        // Re-open the same booking
        console.log('\n🔄 Re-opening to verify...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check if it's still empty
        const verifyValue = await specialRequestsInput.inputValue();
        console.log(`✅ Verified value: "${verifyValue}"`);
        
        if (verifyValue === '' || verifyValue === clearedValue) {
            console.log('\n🎉 SUCCESS: Backend fix works! Special requests cleared successfully.');
        } else {
            console.log('\n❌ FAIL: Backend did not save the cleared value');
            console.log(`Expected: "" or "${clearedValue}"`);
            console.log(`Got: "${verifyValue}"`);
        }
        
        console.log('\n✅ Test complete!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testAddonFix();