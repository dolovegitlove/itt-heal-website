/**
 * Test Backend Add-ons Clearing
 * Tests what happens when we send empty addons array to backend
 */

const { chromium } = require('playwright');

async function testBackendAddonsClearing() {
    console.log('🧪 Testing Backend Add-ons Clearing');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Get first booking
        const firstBooking = page.locator('.booking-card').first();
        
        // Click edit
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check current state
        const beforeSpecialRequests = await page.locator('#editSpecialRequests').inputValue();
        console.log('📋 BEFORE - special_requests:', `"${beforeSpecialRequests}"`);

        // Force clear the special_requests field manually to simulate proper clearing
        console.log('🧹 Manually clearing special_requests to test...');
        await page.locator('#editSpecialRequests').fill('');
        await page.waitForTimeout(500);

        // Monitor API calls
        let requestData = null;
        let responseData = null;
        
        page.on('request', async request => {
            if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                const postData = request.postData();
                if (postData) {
                    try {
                        requestData = JSON.parse(postData);
                        console.log('\n📡 REQUEST TO BACKEND:');
                        console.log('   - addons:', JSON.stringify(requestData.addons));
                        console.log('   - special_requests:', `"${requestData.special_requests}"`);
                    } catch (e) {
                        console.log('📡 Request data (non-JSON):', postData.substring(0, 200));
                    }
                }
            }
        });

        page.on('response', async response => {
            if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                try {
                    responseData = await response.json();
                    console.log('\n📡 RESPONSE FROM BACKEND:');
                    console.log('   - success:', responseData.success);
                    if (responseData.booking) {
                        console.log('   - returned special_requests:', `"${responseData.booking.special_requests || ''}"`);
                        console.log('   - returned addons field:', responseData.booking.addons);
                    }
                } catch (e) {
                    console.log('📡 Response parsing error:', e.message);
                }
            }
        });

        // Submit the edit
        console.log('💾 Submitting edit with empty special_requests...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForTimeout(3000);

        // Wait for page refresh
        await page.waitForTimeout(2000);

        // Check what happened after edit
        console.log('🔍 Checking booking after edit...');
        const updatedBookingText = await firstBooking.textContent();
        console.log('📋 Updated booking card:', updatedBookingText?.substring(0, 200));

        // Re-open edit modal to see what backend actually saved
        console.log('✏️ Re-opening edit modal to see what was saved...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        const afterSpecialRequests = await page.locator('#editSpecialRequests').inputValue();
        console.log('📋 AFTER - special_requests in database:', `"${afterSpecialRequests}"`);

        // Analysis
        console.log('\n📊 ANALYSIS:');
        if (requestData) {
            console.log(`✅ Frontend sent empty addons: ${JSON.stringify(requestData.addons) === '[]'}`);
            console.log(`✅ Frontend sent empty special_requests: ${requestData.special_requests === ''}`);
        }
        
        const stillHasAddonsInDB = afterSpecialRequests && afterSpecialRequests.includes('Add-ons:');
        console.log(`❌ Backend still has add-ons in special_requests: ${stillHasAddonsInDB}`);
        
        const stillHasAddonsInCard = updatedBookingText?.includes('Add-ons:') && !updatedBookingText?.includes('Add-ons: $0');
        console.log(`❌ Card still shows add-ons: ${stillHasAddonsInCard}`);

        if (stillHasAddonsInDB) {
            console.log('\n🔧 ISSUE IDENTIFIED:');
            console.log('   The backend is NOT properly clearing the special_requests field');
            console.log('   when addons: [] is sent. The backend needs to be updated to:');
            console.log('   1. Remove "Add-ons:" lines from special_requests when addons is empty');
            console.log('   2. Or use the special_requests value sent from frontend');
        } else {
            console.log('\n✅ Backend clearing works correctly!');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'backend-test-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    testBackendAddonsClearing().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testBackendAddonsClearing };