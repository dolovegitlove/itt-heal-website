/**
 * FIXED DROPDOWN INTERACTION TEST
 * Properly tests dropdown selection using selectOption() method
 * Tests the specific availability persistence issue
 */

const { chromium } = require('playwright');

async function testDropdownInteractionFix() {
    console.log('🚀 Starting FIXED Dropdown Interaction Test...');
    console.log('🔧 TESTING: Proper dropdown selection with persistence');
    console.log('🌐 USING: Live backend at https://ittheal.com\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 600,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    let successCount = 0;
    let failureCount = 0;
    const testResults = [];
    
    try {
        for (let testRun = 1; testRun <= 12; testRun++) {
            console.log(`\n=== TEST RUN ${testRun}/12 ===`);
            
            try {
                // Step 1: Navigate to live site
                console.log('📍 Navigating to live booking page...');
                await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
                await page.waitForTimeout(2000);
                
                // Scroll to booking section
                await page.locator('#booking').scrollIntoViewIfNeeded();
                await page.waitForTimeout(1000);
                
                // Step 2: Select service
                console.log('📍 Selecting 90-minute service...');
                const serviceOption = page.locator('[data-service-type="fascial-release-90"]');
                await serviceOption.click();
                await page.waitForTimeout(1000);
                
                // Step 3: Click Next
                console.log('📍 Clicking Next to proceed...');
                await page.locator('#next-btn').click();
                await page.waitForTimeout(2000);
                
                // Step 4: Select a valid future date
                console.log('📍 Selecting a valid future date...');
                const dateInput = page.locator('#booking-date');
                await dateInput.click();
                await page.waitForTimeout(500);
                
                // Clear and enter a date 2 weeks from now (business day)
                await page.keyboard.press('Control+a');
                await page.waitForTimeout(200);
                await page.keyboard.press('Delete');
                await page.waitForTimeout(200);
                
                // Calculate a Monday 2 weeks from now
                const futureDate = new Date();
                futureDate.setDate(futureDate.getDate() + 14);
                while (futureDate.getDay() !== 1) { // Make it a Monday
                    futureDate.setDate(futureDate.getDate() + 1);
                }
                
                const dateString = futureDate.toISOString().split('T')[0]; // YYYY-MM-DD format
                await page.keyboard.type(dateString);
                await page.waitForTimeout(500);
                await page.keyboard.press('Tab');
                
                console.log(`Date entered: ${dateString}`);
                
                // Step 5: Wait for availability to load
                console.log('📍 Waiting for availability to load...');
                
                const timeSelect = page.locator('#booking-time');
                
                // Wait for options to load (more robust approach)
                await page.waitForFunction(() => {
                    const select = document.getElementById('booking-time');
                    if (!select) return false;
                    
                    const options = select.querySelectorAll('option[value]:not([value=""])');
                    return options.length > 0 && !select.disabled;
                }, { timeout: 15000 });
                
                console.log('✅ Availability loaded successfully');
                
                // Step 6: Get available options and select one
                console.log('📍 Testing time selection...');
                
                const availableOptions = await page.locator('#booking-time option[value]:not([value=""])').all();
                if (availableOptions.length === 0) {
                    throw new Error('❌ No time options available');
                }
                
                // Get the first available time value
                const firstOptionValue = await availableOptions[0].getAttribute('value');
                const firstOptionText = await availableOptions[0].textContent();
                
                console.log(`  Available options: ${availableOptions.length}`);
                console.log(`  Selecting: ${firstOptionText} (${firstOptionValue})`);
                
                // CORRECT WAY: Use selectOption() for dropdown
                await timeSelect.selectOption(firstOptionValue);
                await page.waitForTimeout(1000);
                
                // Verify selection persisted
                const selectedValue = await timeSelect.inputValue();
                if (selectedValue !== firstOptionValue) {
                    throw new Error(`❌ Time selection did not persist: expected ${firstOptionValue}, got ${selectedValue}`);
                }
                
                console.log(`✅ Time selection persisted: ${selectedValue}`);
                
                // Step 7: Test persistence after focus change
                console.log('📍 Testing selection persistence after focus change...');
                
                // Click somewhere else to lose focus
                await page.locator('body').click();
                await page.waitForTimeout(500);
                
                // Check if selection is still there
                const persistedValue = await timeSelect.inputValue();
                if (persistedValue !== firstOptionValue) {
                    throw new Error(`❌ Time selection lost after focus change: expected ${firstOptionValue}, got ${persistedValue}`);
                }
                
                console.log(`✅ Time selection survived focus change: ${persistedValue}`);
                
                // Step 8: Test proceeding to next step
                console.log('📍 Testing proceeding to next step...');
                
                const nextBtn = page.locator('#next-btn');
                await nextBtn.click();
                await page.waitForTimeout(3000);
                
                // Check if we progressed successfully
                const contactVisible = await page.locator('#contact-info').isVisible();
                const errorElements = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').count();
                
                if (contactVisible) {
                    console.log(`✅ Successfully progressed to contact info`);
                    successCount++;
                    testResults.push({
                        run: testRun,
                        status: 'SUCCESS',
                        timeValue: firstOptionValue,
                        timeText: firstOptionText,
                        availableOptions: availableOptions.length
                    });
                } else if (errorElements > 0) {
                    const errorText = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').first().textContent();
                    throw new Error(`❌ Validation error: ${errorText}`);
                } else {
                    throw new Error('❌ Failed to progress - no error shown but not on contact page');
                }
                
            } catch (error) {
                console.error(`❌ TEST RUN ${testRun} FAILED: ${error.message}`);
                failureCount++;
                testResults.push({
                    run: testRun,
                    status: 'FAILURE',
                    error: error.message
                });
                
                // Take screenshot on failure
                await page.screenshot({ 
                    path: `booking-failure-run-${testRun}.png`, 
                    fullPage: true 
                });
                console.log(`📸 Failure screenshot saved: booking-failure-run-${testRun}.png`);
            }
            
            // Reset for next test
            if (testRun < 12) {
                console.log('🔄 Resetting for next test...');
                await page.goto('about:blank');
                await page.waitForTimeout(1000);
            }
        }
        
        // Final Results Analysis
        console.log('\n' + '='.repeat(60));
        console.log('📊 DROPDOWN INTERACTION TEST RESULTS');
        console.log('='.repeat(60));
        console.log(`✅ Successful tests: ${successCount}/12 (${Math.round(successCount/12*100)}%)`);
        console.log(`❌ Failed tests: ${failureCount}/12 (${Math.round(failureCount/12*100)}%)`);
        
        // Success rate analysis
        if (successCount === 12) {
            console.log('\n🎉 PERFECT! 100% SUCCESS RATE ACHIEVED');
            console.log('✅ All booking attempts completed successfully');
        } else if (successCount >= 10) {
            console.log('\n✅ EXCELLENT! ≥83% success rate (mostly reliable)');
        } else if (successCount >= 8) {
            console.log('\n⚠️ MODERATE: 67-82% success rate (needs improvement)');
        } else {
            console.log('\n❌ POOR: <67% success rate (CRITICAL ISSUES)');
        }
        
        // Failure analysis
        if (failureCount > 0) {
            console.log('\n🚨 FAILURE ANALYSIS:');
            const failures = testResults.filter(r => r.status === 'FAILURE');
            const errorTypes = {};
            
            failures.forEach(failure => {
                const errorType = failure.error.split(':')[0];
                errorTypes[errorType] = (errorTypes[errorType] || 0) + 1;
            });
            
            Object.entries(errorTypes).forEach(([error, count]) => {
                console.log(`  ${error}: ${count} occurrences`);
            });
        }
        
        // Success pattern analysis
        if (successCount > 0) {
            const successes = testResults.filter(r => r.status === 'SUCCESS');
            const avgOptions = successes.reduce((sum, s) => sum + s.availableOptions, 0) / successes.length;
            console.log(`\n📈 Average available time slots: ${Math.round(avgOptions)}`);
            
            const uniqueTimeValues = [...new Set(successes.map(s => s.timeValue))];
            console.log(`📈 Unique time values selected: ${uniqueTimeValues.length}`);
            console.log(`📈 Time values: ${uniqueTimeValues.join(', ')}`);
        }
        
        console.log('\n🎯 PRODUCTION REQUIREMENT: 100% success rate needed');
        console.log('💡 All booking attempts must work reliably for users');
        
        // Keep browser open for final inspection
        console.log('\n🔍 Keeping browser open for 20 seconds for inspection...');
        await page.waitForTimeout(20000);
        
    } catch (error) {
        console.error('\n💥 OVERALL TEST FAILURE:', error.message);
        await page.screenshot({ path: 'dropdown-test-crash.png', fullPage: true });
    } finally {
        await browser.close();
    }
    
    return {
        successCount,
        failureCount,
        totalTests: 12,
        successRate: Math.round(successCount/12*100),
        testResults
    };
}

// Execute the test
if (require.main === module) {
    testDropdownInteractionFix()
        .then((results) => {
            console.log('\n✅ Dropdown interaction test completed');
            
            if (results.successRate === 100) {
                console.log('🎉 BOOKING SYSTEM IS 100% RELIABLE!');
                process.exit(0);
            } else {
                console.log(`❌ BOOKING RELIABILITY ISSUE: Only ${results.successRate}% success rate`);
                console.log('🔧 Fix required before production deployment');
                process.exit(1);
            }
        })
        .catch((error) => {
            console.error('\n❌ Test execution failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testDropdownInteractionFix };