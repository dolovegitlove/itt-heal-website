// Service Type Integration Test
const { chromium } = require('playwright');

describe('Service Type Integration', () => {
  test('90min service should load time slots', async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage();
    
    await page.goto('https://ittheal.com');
    await page.click('[data-service="90min"]');
    await page.click('#next-btn');
    await page.fill('#booking-date', '2025-07-14');
    
    // Should load time slots without errors
    await page.waitForSelector('#booking-time option[value]:not([value=""])', { timeout: 10000 });
    
    const timeOptions = await page.$$('#booking-time option[value]:not([value=""])');
    expect(timeOptions.length).toBeGreaterThan(0);
    
    await browser.close();
  });

  test('API service type mapping', async () => {
    const response = await fetch('https://ittheal.com/api/web-booking/availability/060863f2-0623-4785-b01a-f1760cfb8d14/2025-07-14?service_type=90min_massage');
    expect(response.status).toBe(200);
    
    const data = await response.json();
    expect(data.success).toBe(true);
    expect(data.data.available_slots.length).toBeGreaterThan(0);
  });
});