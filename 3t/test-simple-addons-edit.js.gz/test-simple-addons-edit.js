/**
 * Simple Add-ons Edit Test
 * Tests add-ons removal on existing bookings in admin panel
 */

const { chromium } = require('playwright');

async function testSimpleAddonsEdit() {
    console.log('🧪 Simple Add-ons Edit Test');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Check if any bookings exist
        const bookingCards = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingCards} booking(s)`);

        if (bookingCards === 0) {
            console.log('📝 Creating a test booking first...');
            
            // Create a booking via admin panel
            await page.locator('#admin-nav [href="#create-booking"]').click();
            await page.waitForTimeout(1000);

            // Fill form
            await page.locator('#clientName').fill('Simple Test Client');
            await page.locator('#clientEmail').fill('simple-test@example.com');
            await page.locator('#clientPhone').fill('555-0188');
            
            // Select service
            await page.locator('#serviceType').selectOption('60min');
            await page.waitForTimeout(500);
            
            // Select add-ons if available
            const addons = await page.locator('input[name="addons[]"]').count();
            if (addons > 0) {
                await page.locator('input[name="addons[]"]').first().check();
                console.log('✅ Add-on selected during creation');
            }
            
            // Fill date/time
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const dateTimeStr = tomorrow.toISOString().slice(0, 16);
            await page.locator('#scheduledDate').fill(dateTimeStr);
            
            // Submit
            await page.locator('#createBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);
            
            // Go back to bookings view
            await page.locator('#admin-nav [href="#bookings"]').click();
            await page.waitForTimeout(2000);
        }

        // Wait for bookings to load
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Get first booking
        const firstBooking = page.locator('.booking-card').first();
        const originalText = await firstBooking.textContent();
        console.log('📋 Original booking text:', originalText?.substring(0, 200));

        // Click edit on first booking
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check if modal opened
        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        console.log(`📊 Edit modal opened: ${modalVisible ? '✅' : '❌'}`);

        if (modalVisible) {
            // Check current add-ons
            const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📋 Currently checked add-ons: ${checkedAddons}`);

            if (checkedAddons > 0) {
                console.log('❌ Removing all add-ons...');
                
                // Uncheck all add-ons
                const checkedBoxes = page.locator('#editAddonsContainer input[name="addons[]"]:checked');
                const count = await checkedBoxes.count();
                for (let i = 0; i < count; i++) {
                    await checkedBoxes.nth(i).uncheck();
                    await page.waitForTimeout(300);
                }
                
                console.log('✅ All add-ons unchecked');
            } else {
                // Add an add-on first, then remove it
                console.log('➕ Adding an add-on first...');
                const availableAddons = await page.locator('#editAddonsContainer input[name="addons[]"]').count();
                if (availableAddons > 0) {
                    await page.locator('#editAddonsContainer input[name="addons[]"]').first().check();
                    await page.waitForTimeout(1000);
                    console.log('✅ Add-on added');
                    
                    console.log('❌ Now removing it...');
                    await page.locator('#editAddonsContainer input[name="addons[]"]:checked').uncheck();
                    await page.waitForTimeout(1000);
                    console.log('✅ Add-on removed');
                }
            }

            // Monitor API call
            let apiSuccess = false;
            let apiData = null;
            
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    const postData = request.postData();
                    if (postData) {
                        try {
                            apiData = JSON.parse(postData);
                            console.log('📡 API addons field:', apiData.addons);
                            console.log('📡 API special_requests:', apiData.special_requests);
                        } catch (e) {
                            console.log('📡 API data (non-JSON):', postData.substring(0, 100));
                        }
                    }
                }
            });

            page.on('response', response => {
                if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                    apiSuccess = true;
                    console.log('✅ API call successful');
                }
            });

            // Submit edit
            console.log('💾 Submitting edit...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(3000);

            // Check results
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            console.log(`📊 Modal closed: ${modalClosed ? '✅' : '❌'}`);
            console.log(`📊 API success: ${apiSuccess ? '✅' : '❌'}`);

            // Check if booking card updated
            await page.waitForTimeout(2000);
            const updatedText = await firstBooking.textContent();
            console.log('📋 Updated booking text:', updatedText?.substring(0, 200));

            // Check if add-ons were removed
            const hasAddonsAfter = updatedText?.includes('Add-ons:') && !updatedText?.includes('Add-ons: $0');
            console.log(`📊 Booking still has add-ons: ${hasAddonsAfter ? '❌ YES' : '✅ NO'}`);

            if (apiSuccess && modalClosed && !hasAddonsAfter) {
                console.log('\n🎉 ADD-ONS EDIT FIX IS WORKING!');
                console.log('   - API call successful');
                console.log('   - Modal closed properly');
                console.log('   - Add-ons removed from booking display');
            } else {
                console.log('\n❌ Add-ons edit still has issues');
                if (apiData) {
                    console.log('📊 Check if API data shows addons: []');
                }
            }
        }

        await page.waitForTimeout(5000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'simple-addons-edit-error.png', fullPage: true });
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    testSimpleAddonsEdit().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testSimpleAddonsEdit };