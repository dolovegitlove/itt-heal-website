const { chromium } = require('playwright');

async function debugClosedDateIssue() {
  const browser = await chromium.launch({ 
    headless: false,
    slowMo: 500,
    args: ['--window-size=1200,900']
  });

  try {
    const page = await browser.newPage();
    
    page.on('console', msg => {
      const text = msg.text();
      if (text.includes('closed') || text.includes('available') || text.includes('2025-07-22') || text.includes('validation')) {
        console.log(`[CLOSED] ${text}`);
      }
    });
    
    await page.goto('https://ittheal.com/3t/');
    
    console.log('🚨 DEBUGGING: Closed date validation issue...\n');
    
    await page.click('[data-service="90min"]');
    await page.waitForTimeout(2000);
    
    // Check if 2025-07-22 is properly recognized as closed
    const closedDateCheck = await page.evaluate(() => {
      const closedDates = window.closedDates || [];
      const testDate = '2025-07-22';
      const isInClosedList = closedDates.includes(testDate);
      
      // Check if isDateClosed function exists and works
      const isDateClosedResult = typeof isDateClosed === 'function' ? isDateClosed(testDate) : 'function not found';
      
      return {
        closedDatesCount: closedDates.length,
        sampleClosedDates: closedDates.slice(0, 10),
        testDate: testDate,
        isInClosedList: isInClosedList,
        isDateClosedFunction: typeof isDateClosed,
        isDateClosedResult: isDateClosedResult,
        dateInput: document.getElementById('booking-date')?.value || 'no value'
      };
    });
    
    console.log('📊 CLOSED DATE CHECK:');
    console.log('Closed dates count:', closedDateCheck.closedDatesCount);
    console.log('Sample closed dates:', closedDateCheck.sampleClosedDates);
    console.log('Test date (2025-07-22):', closedDateCheck.testDate);
    console.log('Is in closed list:', closedDateCheck.isInClosedList);
    console.log('isDateClosed function exists:', closedDateCheck.isDateClosedFunction);
    console.log('isDateClosed result:', closedDateCheck.isDateClosedResult);
    console.log('Current date input value:', closedDateCheck.dateInput);
    
    // Test what happens when we try to proceed with a closed date
    if (closedDateCheck.isInClosedList) {
      console.log('\n⚠️ TESTING: Attempting to proceed with CLOSED date (2025-07-22)...');
      
      // Select time
      await page.evaluate(() => {
        const timeSelect = document.getElementById('booking-time');
        if (timeSelect && timeSelect.options.length > 1) {
          timeSelect.selectedIndex = 1;
          timeSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
      
      await page.waitForTimeout(1000);
      
      // Try clicking next
      console.log('🔍 Clicking next with closed date...');
      await page.click('#next-btn');
      await page.waitForTimeout(3000);
      
      const afterClosedDateNext = await page.evaluate(() => {
        const contactStep = document.getElementById('contact-info');
        const datetimeStep = document.getElementById('datetime-selection');
        
        return {
          currentStep: window.currentStep,
          onContactStep: contactStep && window.getComputedStyle(contactStep).display !== 'none',
          stillOnDatetime: datetimeStep && window.getComputedStyle(datetimeStep).display !== 'none'
        };
      });
      
      console.log('📊 After next with closed date:', afterClosedDateNext);
      
      if (afterClosedDateNext.onContactStep) {
        console.log('❌ CRITICAL ISSUE: Closed date validation is NOT working!');
        console.log('Users can proceed with closed dates, which may cause backend errors.');
      } else if (afterClosedDateNext.stillOnDatetime) {
        console.log('✅ Closed date validation is working - user stuck on datetime');
      }
    }
    
    // Now test with a proper available date
    console.log('\n📅 TESTING: Selecting a proper available date...');
    
    const availableDateTest = await page.evaluate(() => {
      const today = new Date();
      const closedDates = window.closedDates || [];
      let availableDate = null;
      
      // Find truly available date
      for (let i = 1; i <= 30; i++) {
        const testDate = new Date(today);
        testDate.setDate(testDate.getDate() + i);
        const dateStr = testDate.toISOString().split('T')[0];
        const dayOfWeek = testDate.getDay();
        
        // Skip weekends and closed dates
        if (dayOfWeek !== 0 && dayOfWeek !== 6 && !closedDates.includes(dateStr)) {
          availableDate = dateStr;
          break;
        }
      }
      
      if (availableDate) {
        const dateInput = document.getElementById('booking-date');
        if (dateInput) {
          console.log('📅 Setting to available date:', availableDate);
          dateInput.value = availableDate;
          dateInput.dispatchEvent(new Event('change', { bubbles: true }));
          return { success: true, availableDate: availableDate };
        }
      }
      
      return { success: false, reason: 'No available date found' };
    });
    
    console.log('Available date test:', availableDateTest);
    
    if (availableDateTest.success) {
      await page.waitForTimeout(2000);
      
      // Select time again
      await page.evaluate(() => {
        const timeSelect = document.getElementById('booking-time');
        if (timeSelect && timeSelect.options.length > 1) {
          timeSelect.selectedIndex = 1;
          timeSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
      
      await page.waitForTimeout(1000);
      
      console.log('🔍 Clicking next with available date...');
      await page.click('#next-btn');
      await page.waitForTimeout(3000);
      
      const afterAvailableDate = await page.evaluate(() => {
        const contactStep = document.getElementById('contact-info');
        return {
          currentStep: window.currentStep,
          onContactStep: contactStep && window.getComputedStyle(contactStep).display !== 'none'
        };
      });
      
      console.log('📊 After next with available date:', afterAvailableDate);
      
      if (afterAvailableDate.onContactStep) {
        console.log('✅ Available date works correctly');
      }
    }
    
    await page.waitForTimeout(3000);
    
  } catch (error) {
    console.error('❌ Closed date debug error:', error);
  } finally {
    await browser.close();
  }
}

debugClosedDateIssue().catch(console.error);