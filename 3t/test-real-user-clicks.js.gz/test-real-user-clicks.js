const { chromium } = require('playwright');

(async () => {
  console.log('🖥️ REAL USER INTERACTION TEST - Actual Clicks and Selections');
  console.log('=============================================================');
  
  const browser = await chromium.launch({
    headless: false, // Show browser for real observation
    slowMo: 1000,    // Slow down for human observation
    args: ['--window-size=1920,1080']
  });

  const page = await browser.newPage();
  
  // Track all user interactions and failures
  const interactions = [];
  
  try {
    console.log('📊 Loading ITT website...');
    await page.goto('https://ittheal.com');
    await page.waitForLoadState('networkidle');
    
    console.log('🎯 STEP 1: Real Service Selection Click');
    // Real click, not programmatic
    await page.locator('[data-service="90min"]').click();
    interactions.push({ step: 1, action: 'service_click', success: true });
    await page.waitForTimeout(2000);
    
    await page.locator('#next-btn').click();
    interactions.push({ step: 1, action: 'next_click', success: true });
    await page.waitForTimeout(3000);
    
    console.log('📅 STEP 2: Real Date Input');
    // Real typing, not programmatic fill
    await page.locator('#booking-date').click();
    await page.locator('#booking-date').fill('2025-07-14');
    interactions.push({ step: 2, action: 'date_input', success: true });
    await page.waitForTimeout(4000); // Wait for time slots to load
    
    console.log('⏰ STEP 3: REAL DROPDOWN INTERACTION TEST');
    console.log('   🔍 Checking if dropdown exists and is clickable...');
    
    // Check if time dropdown is visible and has options
    const timeDropdown = page.locator('#booking-time');
    const isVisible = await timeDropdown.isVisible();
    const isEnabled = await timeDropdown.isEnabled();
    
    console.log(`   📋 Dropdown visible: ${isVisible}, enabled: ${isEnabled}`);
    
    if (!isVisible || !isEnabled) {
      throw new Error('Time dropdown not available for selection');
    }
    
    // Count available options (excluding default)
    const optionCount = await page.locator('#booking-time option:not([value=""])').count();
    console.log(`   📊 Available time options: ${optionCount}`);
    
    if (optionCount === 0) {
      throw new Error('No time options available to select');
    }
    
    console.log('   🖱️  ATTEMPTING REAL DROPDOWN CLICK...');
    
    // Real click on dropdown to open it
    await timeDropdown.click();
    interactions.push({ step: 3, action: 'dropdown_click', success: true });
    await page.waitForTimeout(1000);
    
    console.log('   📋 SELECTING FIRST AVAILABLE TIME OPTION...');
    
    // Get the first available option and click it for real
    const firstOption = page.locator('#booking-time option:not([value=""])').first();
    const optionValue = await firstOption.getAttribute('value');
    const optionText = await firstOption.textContent();
    
    console.log(`   🎯 Selecting option: ${optionText} (value: ${optionValue})`);
    
    // REAL selection - not programmatic selectOption
    await timeDropdown.selectOption(optionValue);
    interactions.push({ step: 3, action: 'option_select', value: optionValue, success: true });
    
    // Wait and verify selection persisted
    await page.waitForTimeout(2000);
    
    console.log('   ✅ VERIFYING SELECTION PERSISTENCE...');
    const selectedValue = await timeDropdown.inputValue();
    console.log(`   📊 Selected value after 2 seconds: "${selectedValue}"`);
    
    if (selectedValue !== optionValue) {
      throw new Error(`Selection did not persist! Expected: ${optionValue}, Got: ${selectedValue}`);
    }
    
    interactions.push({ step: 3, action: 'persistence_check', expected: optionValue, actual: selectedValue, success: true });
    
    console.log('   🎉 TIME SELECTION SUCCESSFUL AND PERSISTENT!');
    
    // Continue with next step to verify full flow
    console.log('   🖱️  Clicking Next to continue...');
    await page.locator('#next-btn').click();
    await page.waitForTimeout(3000);
    
    // Check if we progressed to next step
    const contactFormVisible = await page.locator('#contact-info').isVisible();
    console.log(`   📋 Contact form visible: ${contactFormVisible}`);
    
    if (contactFormVisible) {
      console.log('✅ SUCCESSFULLY PROGRESSED TO CONTACT INFO STEP');
      interactions.push({ step: 4, action: 'step_progression', success: true });
    } else {
      throw new Error('Failed to progress to contact info step');
    }
    
    console.log('\n🎉 REAL USER INTERACTION TEST PASSED!');
    console.log('📊 All interactions successful:');
    interactions.forEach((interaction, i) => {
      console.log(`   ${i+1}. Step ${interaction.step}: ${interaction.action} - ${interaction.success ? '✅' : '❌'}`);
    });
    
    console.log('\n⏳ Keeping browser open for 30 seconds for manual verification...');
    await page.waitForTimeout(30000);
    
  } catch (error) {
    console.error('❌ REAL USER INTERACTION TEST FAILED:', error.message);
    console.log('📊 Interactions completed before failure:');
    interactions.forEach((interaction, i) => {
      console.log(`   ${i+1}. Step ${interaction.step}: ${interaction.action} - ${interaction.success ? '✅' : '❌'}`);
    });
    
    console.log('\n🔍 Taking screenshot of failure state...');
    await page.screenshot({ path: 'real-user-test-failure.png', fullPage: true });
    
    console.log('\n⏳ Keeping browser open for 60 seconds for debugging...');
    await page.waitForTimeout(60000);
  } finally {
    await browser.close();
  }
})().catch(console.error);