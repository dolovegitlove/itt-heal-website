/**
 * Real UI Test: Edit Booking Persistence
 * Tests that booking edits actually persist in the admin interface
 */

const { chromium } = require('playwright');

async function testEditBookingPersistence() {
    console.log('🔧 Testing Edit Booking Persistence with Real UI Interactions');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testSuccess = false;
    let originalBookingData = null;
    let editedBookingData = null;

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(2000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Find the first booking with an edit button
        const firstBooking = await page.locator('.booking-card').first();
        
        // Capture original booking data before editing
        console.log('📋 Capturing original booking data...');
        const originalClientName = await firstBooking.locator('.booking-client').textContent();
        const bookingDetailsText = await firstBooking.textContent();
        
        // Extract email and phone from the booking card text content
        const emailMatch = bookingDetailsText.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
        const phoneMatch = bookingDetailsText.match(/(\d{3}[-.]?\d{3}[-.]?\d{4})/);
        
        const originalEmail = emailMatch ? emailMatch[1] : null;
        const originalPhone = phoneMatch ? phoneMatch[1] : null;
        
        originalBookingData = {
            name: originalClientName?.trim(),
            email: originalEmail?.trim(),
            phone: originalPhone?.trim()
        };
        
        console.log('📊 Original booking data:', originalBookingData);

        // Click the edit button
        console.log('✏️ Clicking edit button...');
        const editButton = firstBooking.locator('.btn:has-text("Edit")');
        await editButton.click();
        await page.waitForTimeout(1000);

        // Wait for edit modal to appear
        console.log('⏳ Waiting for edit modal...');
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Modify booking data with real user interactions
        const newClientName = `Updated Client ${Date.now()}`;
        const newEmail = `updated${Date.now()}@test.com`;
        const newPhone = `555-${Math.floor(Math.random() * 10000)}`;

        console.log('📝 Modifying booking data...');
        
        // Clear and type new client name
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.selectText();
        await page.keyboard.type(newClientName);
        
        // Clear and type new email
        const emailInput = page.locator('#editClientEmail');
        await emailInput.click();
        await emailInput.selectText();
        await page.keyboard.type(newEmail);
        
        // Clear and type new phone
        const phoneInput = page.locator('#editClientPhone');
        await phoneInput.click();
        await phoneInput.selectText();
        await page.keyboard.type(newPhone);

        editedBookingData = {
            name: newClientName,
            email: newEmail,
            phone: newPhone
        };

        console.log('📊 New booking data:', editedBookingData);

        // Submit the form with real user click
        console.log('💾 Saving changes...');
        const saveButton = page.locator('#editBookingForm button[type="submit"]');
        await saveButton.click();
        
        // Wait for the success message or modal to close
        await page.waitForTimeout(3000);
        
        // Check if modal closed (indicates success)
        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        if (!modalVisible) {
            console.log('✅ Edit modal closed - changes likely saved');
        } else {
            console.log('⚠️ Edit modal still open - checking for errors...');
            const errorMessage = await page.locator('.alert-error').textContent().catch(() => null);
            if (errorMessage) {
                console.log('❌ Error message:', errorMessage);
                throw new Error(`Edit failed: ${errorMessage}`);
            }
        }

        // Wait for page to refresh/update
        await page.waitForTimeout(2000);

        // Verify the changes persisted by checking the booking card again
        console.log('🔍 Verifying changes persisted...');
        
        // Reload bookings to ensure we get fresh data
        await page.reload();
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        // Find the same booking (we'll match by the new name)
        const updatedBooking = await page.locator(`.booking-card:has-text("${newClientName}")`).first();
        
        if (await updatedBooking.count() === 0) {
            throw new Error('Updated booking not found - changes may not have persisted');
        }

        // Verify the data actually changed
        const verifiedName = await updatedBooking.locator('.booking-client').textContent();
        const verifiedBookingText = await updatedBooking.textContent();
        
        // Extract email and phone from the updated booking card text content
        const verifiedEmailMatch = verifiedBookingText.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
        const verifiedPhoneMatch = verifiedBookingText.match(/(\d{3}[-.]?\d{3}[-.]?\d{4})/);
        
        const verifiedEmail = verifiedEmailMatch ? verifiedEmailMatch[1] : null;
        const verifiedPhone = verifiedPhoneMatch ? verifiedPhoneMatch[1] : null;

        const verifiedData = {
            name: verifiedName?.trim(),
            email: verifiedEmail?.trim(),
            phone: verifiedPhone?.trim()
        };

        console.log('📊 Verified booking data:', verifiedData);

        // Check if changes actually persisted
        const nameMatches = verifiedData.name === editedBookingData.name;
        const emailMatches = verifiedData.email === editedBookingData.email;
        const phoneMatches = verifiedData.phone === editedBookingData.phone;

        if (nameMatches && emailMatches && phoneMatches) {
            console.log('✅ SUCCESS: All booking changes persisted correctly!');
            testSuccess = true;
        } else {
            console.log('❌ PERSISTENCE FAILURE:');
            console.log(`   Name: ${nameMatches ? '✅' : '❌'} (${verifiedData.name} vs ${editedBookingData.name})`);
            console.log(`   Email: ${emailMatches ? '✅' : '❌'} (${verifiedData.email} vs ${editedBookingData.email})`);
            console.log(`   Phone: ${phoneMatches ? '✅' : '❌'} (${verifiedData.phone} vs ${editedBookingData.phone})`);
            throw new Error('Booking changes did not persist correctly');
        }

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        console.error('🔍 Full error details:', error);
        
        // Take screenshot for debugging
        try {
            await page.screenshot({ path: 'edit-booking-persistence-error.png', fullPage: true });
            console.log('📸 Error screenshot saved as edit-booking-persistence-error.png');
        } catch (screenshotError) {
            console.log('📸 Could not save screenshot:', screenshotError.message);
        }
    } finally {
        await browser.close();
    }

    return {
        success: testSuccess,
        originalData: originalBookingData,
        editedData: editedBookingData,
        error: testSuccess ? null : 'Booking changes did not persist'
    };
}

if (require.main === module) {
    testEditBookingPersistence().then(result => {
        console.log('\n📊 Test Result Summary:');
        console.log(`Success: ${result.success ? '✅' : '❌'}`);
        if (result.originalData) console.log('Original Data:', result.originalData);
        if (result.editedData) console.log('Edited Data:', result.editedData);
        if (result.error) console.log('Error:', result.error);
        
        process.exit(result.success ? 0 : 1);
    }).catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testEditBookingPersistence };