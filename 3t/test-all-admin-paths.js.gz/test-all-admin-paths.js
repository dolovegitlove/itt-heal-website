/**
 * Test All Admin Paths
 * Comprehensive check of all asset and resource paths in admin panel
 */

const https = require('https');

async function testAllAdminPaths() {
    console.log('🧪 Testing ALL Admin Panel Paths');
    
    const pathsToTest = [
        {
            name: 'CSS File',
            url: 'https://ittheal.com/dist/luxury-spa.css',
            expected: 200
        },
        {
            name: 'Favicon',
            url: 'https://ittheal.com/assets/logos/itt-heal-lotus-32.png',
            expected: 200
        },
        {
            name: 'Shared Config JS',
            url: 'https://ittheal.com/shared-config.js',
            expected: 200
        },
        {
            name: 'Shared Payment JS',
            url: 'https://ittheal.com/js/shared-payment.js',
            expected: 200
        },
        {
            name: 'Admin Page',
            url: 'https://ittheal.com/admin/',
            expected: 200
        }
    ];
    
    const results = [];
    
    for (const path of pathsToTest) {
        try {
            console.log(`📡 Testing ${path.name}...`);
            
            const response = await new Promise((resolve, reject) => {
                const req = https.get(path.url, (res) => {
                    resolve({ status: res.statusCode, headers: res.headers });
                });
                req.on('error', reject);
                req.setTimeout(5000, () => reject(new Error('Request timeout')));
            });
            
            const success = response.status === path.expected;
            results.push({
                ...path,
                actual: response.status,
                success
            });
            
            console.log(`   ${success ? '✅' : '❌'} ${path.name}: ${response.status}`);
            
        } catch (error) {
            results.push({
                ...path,
                actual: 'ERROR',
                success: false,
                error: error.message
            });
            console.log(`   ❌ ${path.name}: ERROR - ${error.message}`);
        }
    }
    
    // Check admin page for correct path references
    try {
        console.log('\n📄 Checking Admin Page Path References...');
        
        const adminResponse = await new Promise((resolve, reject) => {
            const req = https.get('https://ittheal.com/admin/', (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => resolve({ status: res.statusCode, data }));
            });
            req.on('error', reject);
            req.setTimeout(10000, () => reject(new Error('Request timeout')));
        });
        
        if (adminResponse.status === 200) {
            const pathChecks = [
                {
                    name: 'CSS Path',
                    pattern: 'href="../dist/luxury-spa.css"',
                    found: adminResponse.data.includes('href="../dist/luxury-spa.css"')
                },
                {
                    name: 'Favicon Path',
                    pattern: 'href="../assets/logos/itt-heal-lotus-32.png"',
                    found: adminResponse.data.includes('href="../assets/logos/itt-heal-lotus-32.png"')
                },
                {
                    name: 'Shared Config Path',
                    pattern: 'src="../shared-config.js"',
                    found: adminResponse.data.includes('src="../shared-config.js"')
                },
                {
                    name: 'Shared Payment Path',
                    pattern: 'src="../js/shared-payment.js"',
                    found: adminResponse.data.includes('src="../js/shared-payment.js"')
                }
            ];
            
            pathChecks.forEach(check => {
                console.log(`   ${check.found ? '✅' : '❌'} ${check.name}: ${check.found ? 'CORRECT' : 'MISSING'}`);
            });
            
            const allPathsCorrect = pathChecks.every(check => check.found);
            const allResourcesLoading = results.every(result => result.success);
            
            console.log('\n📊 SUMMARY:');
            console.log(`✅ All resources accessible: ${allResourcesLoading ? 'YES' : 'NO'}`);
            console.log(`✅ All paths correctly referenced: ${allPathsCorrect ? 'YES' : 'NO'}`);
            
            if (allResourcesLoading && allPathsCorrect) {
                console.log('\n🎯 SUCCESS! All admin panel paths are correct');
                console.log('✅ No more 404 errors for any resources');
                console.log('✅ All relative paths correctly point to parent directory');
                console.log('✅ CSS, favicon, and JavaScript files all load properly');
                return true;
            } else {
                console.log('\n❌ Some paths still have issues');
                results.forEach(result => {
                    if (!result.success) {
                        console.log(`   - ${result.name}: ${result.actual} (expected ${result.expected})`);
                    }
                });
                return false;
            }
        }
        
    } catch (error) {
        console.error('❌ Failed to check admin page paths:', error.message);
        return false;
    }
}

if (require.main === module) {
    testAllAdminPaths().then(success => {
        if (success) {
            console.log('\n🎉 All admin paths test PASSED');
            console.log('\n📝 PATH CORRECTIONS MADE:');
            console.log('   Fixed: href="./dist/luxury-spa.css" → href="../dist/luxury-spa.css"');
            console.log('   Fixed: href="./assets/logos/..." → href="../assets/logos/..."');
            console.log('   Verified: All JavaScript files use correct relative paths');
            process.exit(0);
        } else {
            console.log('\n💥 Admin paths test FAILED');
            process.exit(1);
        }
    });
}

module.exports = { testAllAdminPaths };