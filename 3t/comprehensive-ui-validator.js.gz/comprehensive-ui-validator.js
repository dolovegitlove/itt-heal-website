/**
 * Comprehensive UI Validator
 * Combines multiple validation approaches to catch UI issues proactively
 */

const { chromium } = require('playwright');
const fs = require('fs');

async function comprehensiveUIValidation() {
    console.log('🔍 Comprehensive UI Validation Starting...');
    
    const allIssues = [];
    
    // 1. Static Code Analysis
    console.log('\n📝 Static Code Analysis...');
    const staticIssues = await validateStaticCode();
    allIssues.push(...staticIssues);
    
    // 2. Live UI Testing  
    console.log('\n🌐 Live UI Testing...');
    const liveIssues = await validateLiveUI();
    allIssues.push(...liveIssues);
    
    // 3. Form Functionality Testing
    console.log('\n📋 Form Functionality Testing...');
    const formIssues = await validateFormFunctionality();
    allIssues.push(...formIssues);
    
    // Generate comprehensive report
    generateComprehensiveReport(allIssues);
    
    return allIssues;
}

async function validateStaticCode() {
    const issues = [];
    const adminFile = 'admin/index.html';
    
    if (!fs.existsSync(adminFile)) {
        issues.push({
            type: 'CRITICAL',
            category: 'FILE_MISSING',
            issue: 'Admin file not found',
            location: adminFile
        });
        return issues;
    }
    
    const content = fs.readFileSync(adminFile, 'utf8');
    
    // Check for common patterns that indicate good practices
    const patterns = [
        {
            check: content.includes('submitButton.disabled = true'),
            issue: 'Forms missing loading state (disabled button)',
            type: 'MEDIUM',
            category: 'LOADING_STATE'
        },
        {
            check: content.includes('finally {'),
            issue: 'Forms missing finally blocks for cleanup',
            type: 'HIGH', 
            category: 'ERROR_HANDLING'
        },
        {
            check: content.includes('addEventListener(\'submit\''),
            issue: 'Forms missing proper submit handlers',
            type: 'HIGH',
            category: 'FORM_HANDLING'
        },
        {
            check: content.includes('addons: []'),
            issue: 'Add-ons removal logic missing',
            type: 'MEDIUM',
            category: 'DATA_HANDLING'
        },
        {
            check: content.includes('clear_addons'),
            issue: 'Add-ons clearing flags missing',
            type: 'MEDIUM',
            category: 'DATA_HANDLING'
        }
    ];
    
    patterns.forEach(pattern => {
        if (!pattern.check) {
            issues.push({
                type: pattern.type,
                category: pattern.category,
                issue: pattern.issue,
                location: adminFile
            });
        }
    });
    
    return issues;
}

async function validateLiveUI() {
    const issues = [];
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    
    try {
        // Test admin panel
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);
        
        // Check if admin panel loads
        const adminWorking = await page.locator('h1').count() > 0;
        if (!adminWorking) {
            issues.push({
                type: 'CRITICAL',
                category: 'PAGE_LOAD',
                issue: 'Admin panel does not load',
                location: '/admin'
            });
        }
        
        // Check for JavaScript errors
        const jsErrors = [];
        page.on('console', msg => {
            if (msg.type() === 'error') {
                jsErrors.push(msg.text());
            }
        });
        
        await page.waitForTimeout(2000);
        
        if (jsErrors.length > 0) {
            issues.push({
                type: 'HIGH',
                category: 'JS_ERRORS',
                issue: `JavaScript errors detected: ${jsErrors.slice(0, 3).join('; ')}`,
                location: '/admin'
            });
        }
        
        // Check for edit functionality
        const editButtons = await page.locator('.btn:has-text("Edit")').count();
        if (editButtons === 0) {
            issues.push({
                type: 'HIGH',
                category: 'EDIT_MISSING',
                issue: 'No edit buttons found - edit functionality missing',
                location: '/admin'
            });
        } else {
            // Test edit modal
            try {
                await page.locator('.btn:has-text("Edit")').first().click();
                await page.waitForTimeout(1000);
                
                const modalVisible = await page.locator('#editBookingModal.active').isVisible();
                if (!modalVisible) {
                    issues.push({
                        type: 'HIGH',
                        category: 'MODAL_BROKEN',
                        issue: 'Edit modal does not open',
                        location: '/admin edit functionality'
                    });
                } else {
                    // Check for form elements
                    const nameInput = await page.locator('#editClientName').count();
                    const submitButton = await page.locator('#editBookingForm button[type="submit"]').count();
                    
                    if (nameInput === 0) {
                        issues.push({
                            type: 'HIGH',
                            category: 'FORM_INCOMPLETE',
                            issue: 'Edit form missing name input',
                            location: '/admin edit modal'
                        });
                    }
                    
                    if (submitButton === 0) {
                        issues.push({
                            type: 'CRITICAL',
                            category: 'FORM_BROKEN',
                            issue: 'Edit form missing submit button',
                            location: '/admin edit modal'
                        });
                    }
                }
            } catch (e) {
                issues.push({
                    type: 'HIGH',
                    category: 'EDIT_ERROR',
                    issue: `Edit functionality error: ${e.message}`,
                    location: '/admin edit test'
                });
            }
        }
        
    } catch (error) {
        issues.push({
            type: 'CRITICAL',
            category: 'VALIDATION_ERROR',
            issue: `Live UI validation failed: ${error.message}`,
            location: '/admin'
        });
    } finally {
        await browser.close();
    }
    
    return issues;
}

async function validateFormFunctionality() {
    const issues = [];
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    
    try {
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);
        
        // Check main site booking form
        await page.goto('https://ittheal.com');
        await page.waitForTimeout(2000);
        
        // Check if booking section exists
        const bookingSection = await page.locator('#booking').count();
        if (bookingSection === 0) {
            issues.push({
                type: 'HIGH',
                category: 'BOOKING_MISSING',
                issue: 'Booking section not found on main site',
                location: '/ booking'
            });
        }
        
        // Test form fields
        const formFields = [
            { selector: '#clientName', name: 'Client Name' },
            { selector: '#clientEmail', name: 'Client Email' },
            { selector: '#appointmentDate', name: 'Appointment Date' },
            { selector: '#appointmentTime', name: 'Appointment Time' }
        ];
        
        for (const field of formFields) {
            const exists = await page.locator(field.selector).count();
            if (exists === 0) {
                issues.push({
                    type: 'MEDIUM',
                    category: 'FORM_FIELD_MISSING',
                    issue: `${field.name} field missing from booking form`,
                    location: '/ booking form'
                });
            }
        }
        
    } catch (error) {
        issues.push({
            type: 'HIGH',
            category: 'FORM_VALIDATION_ERROR',
            issue: `Form validation failed: ${error.message}`,
            location: '/ forms'
        });
    } finally {
        await browser.close();
    }
    
    return issues;
}

function generateComprehensiveReport(allIssues) {
    console.log('\n📊 COMPREHENSIVE UI VALIDATION REPORT');
    console.log('=====================================');
    
    if (allIssues.length === 0) {
        console.log('✅ No issues detected! Your UI is in good shape.');
        return;
    }
    
    const critical = allIssues.filter(i => i.type === 'CRITICAL');
    const high = allIssues.filter(i => i.type === 'HIGH');  
    const medium = allIssues.filter(i => i.type === 'MEDIUM');
    
    console.log(`🚨 CRITICAL: ${critical.length} issues (Fix immediately)`);
    console.log(`⚠️  HIGH: ${high.length} issues (Fix before next deployment)`);
    console.log(`⚡ MEDIUM: ${medium.length} issues (Schedule for next sprint)`);
    
    // Group by category
    const byCategory = {};
    allIssues.forEach(issue => {
        if (!byCategory[issue.category]) {
            byCategory[issue.category] = [];
        }
        byCategory[issue.category].push(issue);
    });
    
    console.log('\n📋 Issues by Category:');
    Object.keys(byCategory).forEach(category => {
        console.log(`\n🔧 ${category}:`);
        byCategory[category].forEach((issue, index) => {
            console.log(`  ${index + 1}. [${issue.type}] ${issue.issue}`);
            console.log(`     Location: ${issue.location}`);
        });
    });
    
    console.log('\n🎯 Recommended Actions:');
    if (critical.length > 0) {
        console.log('• 🚨 STOP deployment - critical issues must be fixed first');
    }
    if (high.length > 0) {
        console.log('• ⚠️  Review HIGH issues - may impact user experience significantly');
    }
    console.log('• 🔄 Run this validator regularly (daily/weekly)');
    console.log('• 🧪 Add specific tests for discovered issue patterns');
    console.log('• 📊 Track trends - are issues increasing or decreasing?');
    
    // Save detailed report
    const reportData = {
        timestamp: new Date().toISOString(),
        summary: {
            total: allIssues.length,
            critical: critical.length,
            high: high.length,
            medium: medium.length
        },
        issues: allIssues,
        recommendations: [
            'Implement loading states for all forms',
            'Add proper error handling with finally blocks',
            'Test all edit functionality regularly',
            'Monitor for JavaScript errors',
            'Validate form field presence'
        ]
    };
    
    fs.writeFileSync('ui-validation-report.json', JSON.stringify(reportData, null, 2));
    console.log('\n💾 Detailed report saved to: ui-validation-report.json');
}

if (require.main === module) {
    comprehensiveUIValidation().then(issues => {
        const hasIssues = issues.some(i => i.type === 'CRITICAL' || i.type === 'HIGH');
        process.exit(hasIssues ? 1 : 0);
    }).catch(error => {
        console.error('💥 Comprehensive validation failed:', error);
        process.exit(1);
    });
}

module.exports = { comprehensiveUIValidation };