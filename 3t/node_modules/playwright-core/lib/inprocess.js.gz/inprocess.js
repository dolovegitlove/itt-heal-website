"use strict";
var import_inProcessFactory = require("./inProcessFactory");
module.exports = (0, import_inProcessFactory.createInProcessPlaywright)();
