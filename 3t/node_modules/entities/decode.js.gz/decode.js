// Make exports work in Node < 12
// eslint-disable-next-line no-undef, unicorn/prefer-module
module.exports = require("./dist/commonjs/decode.js");
