"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
/**
 * The version of `tough-cookie`
 * @public
 */
exports.version = '5.1.2';
