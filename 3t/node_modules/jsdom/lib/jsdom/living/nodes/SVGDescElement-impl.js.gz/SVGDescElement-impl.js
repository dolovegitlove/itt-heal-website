"use strict";

const SVGElementImpl = require("./SVGElement-impl").implementation;

class SVGDescElementImpl extends SVGElementImpl {}

module.exports = {
  implementation: SVGDescElementImpl
};
