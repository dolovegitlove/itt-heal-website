"use strict";

const SVGGraphicsElementImpl = require("./SVGGraphicsElement-impl").implementation;

class SVGGElementImpl extends SVGGraphicsElementImpl {}

module.exports = {
  implementation: SVGGElementImpl
};
