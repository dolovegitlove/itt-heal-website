"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLDListElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLDListElementImpl
};
