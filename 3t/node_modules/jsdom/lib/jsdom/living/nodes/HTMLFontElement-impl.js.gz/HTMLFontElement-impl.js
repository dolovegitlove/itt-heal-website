"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLFontElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLFontElementImpl
};
