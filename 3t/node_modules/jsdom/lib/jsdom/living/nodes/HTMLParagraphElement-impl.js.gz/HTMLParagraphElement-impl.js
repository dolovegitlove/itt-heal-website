"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLParagraphElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLParagraphElementImpl
};
