"use strict";

const SVGGraphicsElementImpl = require("./SVGGraphicsElement-impl").implementation;

class SVGDefsElementImpl extends SVGGraphicsElementImpl {}

module.exports = {
  implementation: SVGDefsElementImpl
};
