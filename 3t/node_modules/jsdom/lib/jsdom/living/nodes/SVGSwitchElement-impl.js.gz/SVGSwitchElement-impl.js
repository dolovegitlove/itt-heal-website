"use strict";

const SVGGraphicsElementImpl = require("./SVGGraphicsElement-impl").implementation;

class SVGSwitchElementImpl extends SVGGraphicsElementImpl {}

module.exports = {
  implementation: SVGSwitchElementImpl
};
