"use strict";
const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLEmbedElementImpl extends HTMLElementImpl {}

module.exports = {
  implementation: HTMLEmbedElementImpl
};
