"use strict";

const SVGGraphicsElementImpl = require("./SVGGraphicsElement-impl").implementation;

class SVGSymbolElementImpl extends SVGGraphicsElementImpl {}

module.exports = {
  implementation: SVGSymbolElementImpl
};
