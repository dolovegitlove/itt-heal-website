"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLHtmlElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLHtmlElementImpl
};
