"use strict";

const SVGElementImpl = require("./SVGElement-impl").implementation;

class SVGMetadataElementImpl extends SVGElementImpl {}

module.exports = {
  implementation: SVGMetadataElementImpl
};
