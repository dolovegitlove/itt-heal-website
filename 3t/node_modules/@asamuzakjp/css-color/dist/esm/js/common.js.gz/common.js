const isString = (o) => typeof o === "string" || o instanceof String;
const isStringOrNumber = (o) => isString(o) || typeof o === "number";
export {
  isString,
  isStringOrNumber
};
//# sourceMappingURL=common.js.map
