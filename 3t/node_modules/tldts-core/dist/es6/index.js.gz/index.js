export { parseImpl, getEmptyResult, resetResult, } from './src/factory';
export { default as fastPathLookup } from './src/lookup/fast-path';
export { setDefaults } from './src/options';
//# sourceMappingURL=index.js.map