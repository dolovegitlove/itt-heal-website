/**
 * DEBUG CONSOLE ERRORS
 * Captures and analyzes console errors during booking flow
 */

const { chromium } = require('playwright');

async function debugConsoleErrors() {
    console.log('🔍 Starting Console Error Debug...');
    console.log('🎯 GOAL: Identify JavaScript errors blocking availability loading\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-web-security'
        ]
    });

    const page = await browser.newPage();
    
    // Capture console messages
    const consoleMessages = [];
    const errors = [];
    
    page.on('console', msg => {
        const text = msg.text();
        consoleMessages.push({
            type: msg.type(),
            text: text,
            timestamp: new Date().toISOString()
        });
        
        if (msg.type() === 'error') {
            console.log(`❌ CONSOLE ERROR: ${text}`);
            errors.push(text);
        } else {
            console.log(`📝 CONSOLE ${msg.type().toUpperCase()}: ${text}`);
        }
    });
    
    // Capture network failures
    page.on('response', response => {
        if (!response.ok()) {
            console.log(`🌐 NETWORK ERROR: ${response.status()} ${response.url()}`);
        }
    });
    
    try {
        console.log('📍 Navigate to booking page...');
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(3000);
        
        console.log('📍 Scroll to booking section...');
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(2000);
        
        console.log('📍 Select service...');
        await page.locator('.service-option[data-service="60min"]').click();
        await page.waitForTimeout(2000);
        
        console.log('📍 Click Next...');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(3000);
        
        console.log('📍 Enter Tuesday (closed day)...');
        const dateInput = page.locator('#booking-date');
        await dateInput.click();
        await page.waitForTimeout(500);
        
        await page.keyboard.press('Control+a');
        await page.waitForTimeout(200);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(200);
        
        await page.keyboard.type('2025-07-29');
        await page.waitForTimeout(1000);
        await page.keyboard.press('Tab');
        
        console.log('📍 Wait and observe errors...');
        await page.waitForTimeout(10000);
        
        // Check if BookingAvailability module is loaded
        const moduleLoaded = await page.evaluate(() => {
            return typeof window.BookingAvailability !== 'undefined';
        });
        
        console.log(`\n📋 BookingAvailability module loaded: ${moduleLoaded ? '✅' : '❌'}`);
        
        if (moduleLoaded) {
            // Check methods exist
            const methods = await page.evaluate(() => {
                const ba = window.BookingAvailability;
                return {
                    handleClosedDateError: typeof ba.handleClosedDateError === 'function',
                    handleFetchError: typeof ba.handleFetchError === 'function',
                    suggestNextAvailableDate: typeof ba.suggestNextAvailableDate === 'function'
                };
            });
            
            console.log('📋 Available methods:');
            Object.entries(methods).forEach(([method, exists]) => {
                console.log(`   ${method}: ${exists ? '✅' : '❌'}`);
            });
        }
        
        // Manually trigger the API call to see what happens
        console.log('\n📍 Manually trigger API call...');
        const apiResult = await page.evaluate(async () => {
            try {
                const response = await fetch('/api/web-booking/availability/060863f2-0623-4785-b01a-f1760cfb8d14/2025-07-29?service_type=60min_massage');
                const data = await response.json();
                return {
                    status: response.status,
                    ok: response.ok,
                    data: data
                };
            } catch (error) {
                return {
                    error: error.message
                };
            }
        });
        
        console.log('🌐 API call result:', JSON.stringify(apiResult, null, 2));
        
        // Check current state of time select
        const timeSelectState = await page.evaluate(() => {
            const select = document.getElementById('booking-time');
            const loadingDiv = document.getElementById('time-loading');
            
            return {
                innerHTML: select?.innerHTML || 'NOT FOUND',
                disabled: select?.disabled,
                loadingVisible: loadingDiv?.style.display !== 'none',
                loadingContent: loadingDiv?.innerHTML || 'NOT FOUND'
            };
        });
        
        console.log('\n📋 Time Select State:');
        console.log(`   innerHTML: ${timeSelectState.innerHTML.substring(0, 100)}...`);
        console.log(`   disabled: ${timeSelectState.disabled}`);
        console.log(`   loading visible: ${timeSelectState.loadingVisible}`);
        console.log(`   loading content: ${timeSelectState.loadingContent.substring(0, 100)}...`);
        
        console.log('\n📊 SUMMARY:');
        console.log(`   Console errors: ${errors.length}`);
        console.log(`   Total messages: ${consoleMessages.length}`);
        
        if (errors.length > 0) {
            console.log('\n🚨 ERRORS FOUND:');
            errors.forEach((error, index) => {
                console.log(`   ${index + 1}. ${error}`);
            });
        }
        
        // Take screenshot
        await page.screenshot({ path: 'debug-console-state.png', fullPage: true });
        console.log('\n📸 Screenshot saved: debug-console-state.png');
        
        console.log('\n🔍 Keeping browser open for manual inspection...');
        await page.waitForTimeout(30000);
        
    } catch (error) {
        console.error('\n💥 DEBUG FAILED:', error.message);
    } finally {
        await browser.close();
    }
    
    return {
        errors,
        consoleMessages,
        totalErrors: errors.length
    };
}

// Execute
if (require.main === module) {
    debugConsoleErrors()
        .then((results) => {
            console.log('\n✅ Console error debug completed');
            
            if (results.totalErrors > 0) {
                console.log(`❌ Found ${results.totalErrors} console errors`);
                process.exit(1);
            } else {
                console.log('✅ No console errors found');
                process.exit(0);
            }
        })
        .catch((error) => {
            console.error('\n❌ Debug failed:', error.message);
            process.exit(1);
        });
}

module.exports = { debugConsoleErrors };