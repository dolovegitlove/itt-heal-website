/**
 * Debug Test: Admin Panel Booking Loading
 * Investigates why booking cards aren't loading in the admin panel
 */

const { chromium } = require('playwright');

async function debugAdminPanel() {
    console.log('🔍 Debugging Admin Panel Booking Loading');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Check if we can see the page structure
        console.log('🔍 Checking page title...');
        const title = await page.title();
        console.log('Page title:', title);

        // Check if navigation elements are present
        console.log('🔍 Checking navigation elements...');
        const navButtons = await page.locator('.admin-nav button').count();
        console.log('Navigation buttons found:', navButtons);

        // Click on bookings tab if it exists
        console.log('🔍 Looking for bookings tab...');
        const bookingsTab = await page.locator('button:has-text("Bookings")');
        if (await bookingsTab.count() > 0) {
            console.log('✅ Bookings tab found, clicking...');
            await bookingsTab.click();
            await page.waitForTimeout(3000);
        } else {
            console.log('❌ Bookings tab not found');
        }

        // Check if the bookings section is active
        console.log('🔍 Checking if bookings section is active...');
        const bookingsSection = await page.locator('#bookings.active');
        if (await bookingsSection.count() > 0) {
            console.log('✅ Bookings section is active');
        } else {
            console.log('❌ Bookings section is not active');
            // Try to make it active
            const bookingsDiv = await page.locator('#bookings');
            if (await bookingsDiv.count() > 0) {
                console.log('🔄 Found bookings div, checking classes...');
                const classes = await bookingsDiv.getAttribute('class');
                console.log('Bookings div classes:', classes);
            }
        }

        // Check for loading indicators
        console.log('🔍 Checking for loading indicators...');
        const loadingIndicators = await page.locator('.loading, [data-loading="true"]').count();
        console.log('Loading indicators found:', loadingIndicators);

        // Check for booking cards
        console.log('🔍 Checking for booking cards...');
        const bookingCards = await page.locator('.booking-card').count();
        console.log('Booking cards found:', bookingCards);

        // Check for any error messages
        console.log('🔍 Checking for error messages...');
        const errorMessages = await page.locator('.alert-error, .error-message').count();
        console.log('Error messages found:', errorMessages);

        if (errorMessages > 0) {
            const errorText = await page.locator('.alert-error, .error-message').first().textContent();
            console.log('Error message:', errorText);
        }

        // Check the bookings container directly
        console.log('🔍 Checking bookings container...');
        const bookingsContainer = await page.locator('#bookingsContainer');
        if (await bookingsContainer.count() > 0) {
            const containerHTML = await bookingsContainer.innerHTML();
            console.log('Bookings container HTML length:', containerHTML.length);
            if (containerHTML.length < 100) {
                console.log('Bookings container content:', containerHTML);
            }
        } else {
            console.log('❌ Bookings container not found');
        }

        // Check browser console for errors
        console.log('🔍 Checking browser console...');
        
        // Listen to console messages
        page.on('console', msg => {
            console.log(`Browser console ${msg.type()}: ${msg.text()}`);
        });

        // Check network activity
        console.log('🔍 Monitoring network requests...');
        page.on('response', response => {
            if (response.url().includes('/api/admin/bookings')) {
                console.log(`API Response: ${response.status()} - ${response.url()}`);
            }
        });

        // Wait a bit more to see if anything loads
        console.log('⏳ Waiting to see if bookings load...');
        await page.waitForTimeout(10000);

        // Final check for booking cards
        const finalBookingCards = await page.locator('.booking-card').count();
        console.log('Final booking cards count:', finalBookingCards);

        // Take screenshot for debugging
        await page.screenshot({ path: 'admin-panel-debug.png', fullPage: true });
        console.log('📸 Debug screenshot saved as admin-panel-debug.png');

    } catch (error) {
        console.error('❌ Debug failed:', error.message);
        
        // Take screenshot for debugging
        try {
            await page.screenshot({ path: 'admin-panel-debug-error.png', fullPage: true });
            console.log('📸 Error screenshot saved as admin-panel-debug-error.png');
        } catch (screenshotError) {
            console.log('📸 Could not save screenshot:', screenshotError.message);
        }
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    debugAdminPanel().catch(error => {
        console.error('💥 Debug execution failed:', error);
        process.exit(1);
    });
}

module.exports = { debugAdminPanel };