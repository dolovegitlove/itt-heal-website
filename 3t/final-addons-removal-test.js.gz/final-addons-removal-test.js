/**
 * Final Add-ons Removal Test
 * Quick verification that add-ons removal now works
 */

const { chromium } = require('playwright');

async function finalAddonsRemovalTest() {
    console.log('✨ Final Add-ons Removal Verification');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check current add-ons state
        let checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
        console.log(`📋 Currently checked add-ons: ${checkedAddons}`);

        if (checkedAddons === 0) {
            // Add an add-on to test removal
            console.log('➕ Adding an add-on to test removal...');
            await page.locator('#editAddonsContainer input[name="addons[]"]').first().check();
            await page.waitForTimeout(1000);
            checkedAddons = 1;
        }

        console.log('❌ Removing all add-ons...');
        await page.locator('#editAddonsContainer input[name="addons[]"]:checked').uncheck();
        await page.waitForTimeout(1000);

        // Monitor for the enhanced functionality
        let enhancedFlagsDetected = false;
        let clientValidationWorked = false;
        
        page.on('request', request => {
            if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                const postData = request.postData();
                if (postData) {
                    try {
                        const data = JSON.parse(postData);
                        if (data.clear_addons === true && data.force_addons_update === true) {
                            enhancedFlagsDetected = true;
                            console.log('✅ Enhanced flags detected in API request');
                        }
                    } catch (e) {}
                }
            }
        });

        page.on('console', msg => {
            if (msg.text().includes('Backend did not clear add-ons, forcing client-side update')) {
                clientValidationWorked = true;
                console.log('✅ Client-side validation working');
            }
        });

        console.log('💾 Submitting edit...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForTimeout(3000);

        // Final verification
        console.log('🔍 Final verification...');
        await page.waitForTimeout(2000);
        
        // Re-open edit to check persistence
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);
        
        const finalCheckedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
        console.log(`📋 Add-ons still checked after edit: ${finalCheckedAddons}`);

        console.log('\n📊 Final Results:');
        console.log(`✅ Enhanced flags sent: ${enhancedFlagsDetected ? 'YES' : 'NO'}`);
        console.log(`✅ Client validation worked: ${clientValidationWorked ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons actually removed: ${finalCheckedAddons === 0 ? 'YES' : 'NO'}`);

        const success = finalCheckedAddons === 0;
        console.log(`\n🎯 RESULT: ${success ? '✅ ADD-ONS REMOVAL NOW WORKS!' : '❌ Still has issues'}`);

        if (success) {
            console.log('\n🎉 SUCCESS! You can now remove add-ons when editing bookings!');
            console.log('   The enhanced frontend solution is working correctly.');
        }

        await page.waitForTimeout(2000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    finalAddonsRemovalTest().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { finalAddonsRemovalTest };