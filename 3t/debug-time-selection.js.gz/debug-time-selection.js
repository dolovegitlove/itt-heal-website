const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging time slot selection issue...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  // Step 1: Service selection
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 2: Date selection
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  
  console.log('📅 Checking time select element...');
  
  // Check the time select element in detail
  const timeSelectInfo = await page.evaluate(() => {
    const timeSelect = document.getElementById('booking-time');
    if (!timeSelect) return { error: 'Element not found' };
    
    const rect = timeSelect.getBoundingClientRect();
    const computedStyle = getComputedStyle(timeSelect);
    
    return {
      visible: timeSelect.offsetParent !== null,
      disabled: timeSelect.disabled,
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height
      },
      style: {
        display: computedStyle.display,
        visibility: computedStyle.visibility,
        opacity: computedStyle.opacity,
        pointerEvents: computedStyle.pointerEvents,
        zIndex: computedStyle.zIndex
      },
      optionCount: timeSelect.options.length,
      parentVisible: timeSelect.parentElement ? timeSelect.parentElement.offsetParent !== null : false
    };
  });
  
  console.log('⏰ Time select info:', JSON.stringify(timeSelectInfo, null, 2));
  
  // Try to click and select a time
  console.log('🖱️  Attempting to select a time...');
  
  try {
    // Try clicking the select element
    await page.click('#booking-time');
    console.log('✅ Successfully clicked time select');
    
    // Try selecting an option
    await page.selectOption('#booking-time', '15:00');
    console.log('✅ Successfully selected 15:00 option');
    
    // Check if selection worked
    const selectedValue = await page.evaluate(() => {
      const timeSelect = document.getElementById('booking-time');
      return timeSelect ? timeSelect.value : null;
    });
    
    console.log('📋 Selected value:', selectedValue);
    
  } catch (error) {
    console.log('❌ Selection failed:', error.message);
    
    // Check if element is actually clickable
    const clickable = await page.evaluate(() => {
      const timeSelect = document.getElementById('booking-time');
      if (!timeSelect) return false;
      
      // Check if any element is covering it
      const rect = timeSelect.getBoundingClientRect();
      const centerX = rect.x + rect.width / 2;
      const centerY = rect.y + rect.height / 2;
      const elementAtPoint = document.elementFromPoint(centerX, centerY);
      
      return {
        timeSelectId: timeSelect.id,
        elementAtPointId: elementAtPoint ? elementAtPoint.id : null,
        elementAtPointTag: elementAtPoint ? elementAtPoint.tagName : null,
        isTimeSelectAtPoint: elementAtPoint === timeSelect
      };
    });
    
    console.log('🎯 Clickability check:', clickable);
  }
  
  await browser.close();
})().catch(console.error);