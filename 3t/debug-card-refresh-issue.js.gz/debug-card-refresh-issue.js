/**
 * Debug Card Refresh Issue
 * Detailed debugging of why booking card doesn't refresh
 */

const { chromium } = require('playwright');

async function debugCardRefreshIssue() {
    console.log('🔍 Debug Card Refresh Issue');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        // Check current special_requests content
        const specialRequestsValue = await page.locator('#editSpecialRequests').inputValue();
        console.log('📋 Current special_requests content:');
        console.log(`"${specialRequestsValue}"`);

        // Check current add-ons
        const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
        console.log(`📋 Add-ons currently checked: ${checkedAddons}`);

        if (checkedAddons > 0) {
            console.log('❌ Removing all add-ons and monitoring everything...');

            // Capture all console messages
            const allConsoleMessages = [];
            page.on('console', msg => {
                allConsoleMessages.push(msg.text());
                console.log(`🔍 Console: ${msg.text()}`);
            });

            // Monitor network requests
            const apiRequests = [];
            page.on('request', request => {
                if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                    const postData = request.postData();
                    if (postData) {
                        try {
                            const data = JSON.parse(postData);
                            apiRequests.push(data);
                            console.log('\n📡 API REQUEST SENT:');
                            console.log(`   - addons array:`, JSON.stringify(data.addons));
                            console.log(`   - special_requests:`, `"${data.special_requests}"`);
                            console.log(`   - clear_addons:`, data.clear_addons);
                            console.log(`   - service_price:`, data.service_price);
                            console.log(`   - final_price:`, data.final_price);
                        } catch (e) {
                            console.log('📡 Non-JSON request data');
                        }
                    }
                }
            });

            // Monitor responses  
            const apiResponses = [];
            page.on('response', async response => {
                if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                    try {
                        const data = await response.json();
                        apiResponses.push(data);
                        console.log('\n📡 API RESPONSE RECEIVED:');
                        console.log(`   - success:`, data.success);
                        if (data.booking) {
                            console.log(`   - booking.special_requests:`, `"${data.booking.special_requests}"`);
                            console.log(`   - booking.final_price:`, data.booking.final_price);
                            console.log(`   - booking.total_price:`, data.booking.total_price);
                            console.log(`   - booking.addons_total:`, data.booking.addons_total);
                        }
                    } catch (e) {
                        console.log('📡 Response parsing error');
                    }
                }
            });

            // Remove add-ons
            const addonCheckboxes = page.locator('#editAddonsContainer input[name="addons[]"]:checked');
            const count = await addonCheckboxes.count();
            for (let i = 0; i < count; i++) {
                await addonCheckboxes.nth(0).uncheck();
                await page.waitForTimeout(300);
            }

            // Check special_requests after unchecking
            await page.waitForTimeout(1000);
            const specialRequestsAfterUncheck = await page.locator('#editSpecialRequests').inputValue();
            console.log('\n📋 special_requests after unchecking:');
            console.log(`"${specialRequestsAfterUncheck}"`);

            // Submit
            console.log('\n💾 Submitting edit...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(5000);

            // Analyze what happened
            console.log('\n📊 ANALYSIS:');
            console.log(`✅ API requests made: ${apiRequests.length}`);
            console.log(`✅ API responses received: ${apiResponses.length}`);
            
            // Check if client-side correction was applied
            const correctionApplied = allConsoleMessages.some(msg => 
                msg.includes('Applying client-side add-ons removal correction'));
            console.log(`✅ Client-side correction applied: ${correctionApplied ? 'YES' : 'NO'}`);

            // Check final booking card state
            await page.waitForTimeout(2000);
            const finalCardText = await firstBooking.textContent();
            const finalAddonsCount = (finalCardText.match(/\(\+\$\d+\)/g) || []).length;
            console.log(`📊 Final add-ons in card: ${finalAddonsCount}`);

            if (!correctionApplied) {
                console.log('\n🔧 ISSUE IDENTIFIED: Client-side correction not applying');
                console.log('   Check conditions:');
                if (apiRequests.length > 0) {
                    const req = apiRequests[0];
                    console.log(`   - clear_addons flag: ${req.clear_addons}`);
                    console.log(`   - addons array length: ${req.addons?.length || 0}`);
                }
            }

            if (finalAddonsCount > 0) {
                console.log('\n🔧 BACKEND ISSUE: Server not properly clearing add-ons');
                console.log('   This requires backend changes to respect the clear_addons flag');
            }

        } else {
            console.log('ℹ️ No add-ons to remove');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Debug failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    debugCardRefreshIssue().catch(error => {
        console.error('💥 Debug execution failed:', error);
        process.exit(1);
    });
}

module.exports = { debugCardRefreshIssue };