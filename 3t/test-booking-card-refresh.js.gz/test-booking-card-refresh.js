/**
 * Test Booking Card Refresh After Save
 * Verifies that booking cards update with correct pricing after edit and save
 */

const { chromium } = require('playwright');

async function testBookingCardRefresh() {
    console.log('🔄 Testing Booking Card Refresh After Save');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let testResults = {
        initialCardState: '',
        editModalOpened: false,
        addonsRemoved: false,
        modalPricingUpdated: false,
        saveSuccessful: false,
        cardRefreshed: false,
        finalCardState: '',
        pricingMatches: false
    };

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        // Capture initial card state
        testResults.initialCardState = await firstBooking.textContent();
        console.log('📋 Initial card state captured');
        console.log('   Text preview:', testResults.initialCardState.substring(0, 100));

        // Open edit modal
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        const modalVisible = await page.locator('#editBookingModal.active').isVisible();
        testResults.editModalOpened = modalVisible;
        console.log(`📊 Edit modal opened: ${modalVisible ? '✅' : '❌'}`);

        if (modalVisible) {
            // Check current add-ons and pricing in modal
            const checkedAddons = await page.locator('#editAddonsContainer input[name="addons[]"]:checked').count();
            console.log(`📋 Add-ons currently checked: ${checkedAddons}`);

            if (checkedAddons === 0) {
                // Add an add-on first
                console.log('➕ Adding an add-on to test removal...');
                await page.locator('#editAddonsContainer input[name="addons[]"]').first().check();
                await page.waitForTimeout(1000);
            }

            // Capture initial modal pricing
            const initialModalPrice = await page.locator('#editTotalPriceDisplay').textContent();
            console.log(`💰 Initial modal price: ${initialModalPrice}`);

            // Remove all add-ons
            console.log('❌ Removing all add-ons...');
            const addonCheckboxes = page.locator('#editAddonsContainer input[name="addons[]"]:checked');
            const count = await addonCheckboxes.count();
            for (let i = 0; i < count; i++) {
                await addonCheckboxes.nth(0).uncheck(); // Always uncheck first element
                await page.waitForTimeout(300);
            }
            
            testResults.addonsRemoved = true;

            // Check if modal pricing updated
            await page.waitForTimeout(1000);
            const updatedModalPrice = await page.locator('#editTotalPriceDisplay').textContent();
            testResults.modalPricingUpdated = updatedModalPrice !== initialModalPrice;
            console.log(`💰 Updated modal price: ${updatedModalPrice}`);
            console.log(`📊 Modal pricing updated: ${testResults.modalPricingUpdated ? '✅' : '❌'}`);

            // Monitor console logs for our refresh messages
            const consoleMessages = [];
            page.on('console', msg => {
                const text = msg.text();
                if (text.includes('Forcing complete data refresh') || 
                    text.includes('Updated booking data') ||
                    text.includes('Booking display refresh completed')) {
                    consoleMessages.push(text);
                    console.log(`🔍 Console: ${text}`);
                }
            });

            // Save changes
            console.log('💾 Saving changes...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            await page.waitForTimeout(4000); // Wait for save and refresh

            // Check if modal closed (indicates save success)
            const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
            testResults.saveSuccessful = modalClosed;
            console.log(`📊 Save successful (modal closed): ${modalClosed ? '✅' : '❌'}`);

            if (modalClosed) {
                // Check if refresh console messages appeared
                testResults.cardRefreshed = consoleMessages.length > 0;
                console.log(`📊 Refresh messages detected: ${testResults.cardRefreshed ? '✅' : '❌'}`);
                console.log(`   Messages: ${consoleMessages.length}`);

                // Wait a bit more for refresh to complete
                await page.waitForTimeout(2000);

                // Capture final card state
                testResults.finalCardState = await firstBooking.textContent();
                console.log('📋 Final card state captured');
                console.log('   Text preview:', testResults.finalCardState.substring(0, 100));

                // Compare card states
                const cardChanged = testResults.initialCardState !== testResults.finalCardState;
                console.log(`📊 Card content changed: ${cardChanged ? '✅' : '❌'}`);

                // Check if final card has fewer add-ons/pricing
                const initialAddonsCount = (testResults.initialCardState.match(/\(\+\$\d+\)/g) || []).length;
                const finalAddonsCount = (testResults.finalCardState.match(/\(\+\$\d+\)/g) || []).length;
                
                console.log(`📊 Add-ons in initial card: ${initialAddonsCount}`);
                console.log(`📊 Add-ons in final card: ${finalAddonsCount}`);
                
                testResults.pricingMatches = finalAddonsCount < initialAddonsCount || 
                                           !testResults.finalCardState.includes('Add-ons:');
                
                console.log(`📊 Pricing correctly updated: ${testResults.pricingMatches ? '✅' : '❌'}`);
            }
        }

        // Final assessment
        console.log('\n📊 Booking Card Refresh Test Results:');
        console.log(`✅ Edit modal opened: ${testResults.editModalOpened ? 'YES' : 'NO'}`);
        console.log(`✅ Add-ons removed: ${testResults.addonsRemoved ? 'YES' : 'NO'}`);
        console.log(`✅ Modal pricing updated: ${testResults.modalPricingUpdated ? 'YES' : 'NO'}`);
        console.log(`✅ Save successful: ${testResults.saveSuccessful ? 'YES' : 'NO'}`);
        console.log(`✅ Card refresh triggered: ${testResults.cardRefreshed ? 'YES' : 'NO'}`);
        console.log(`✅ Card pricing updated: ${testResults.pricingMatches ? 'YES' : 'NO'}`);

        const allWorking = testResults.editModalOpened && 
                          testResults.addonsRemoved && 
                          testResults.modalPricingUpdated && 
                          testResults.saveSuccessful && 
                          testResults.pricingMatches;

        console.log(`\n🎯 OVERALL RESULT: ${allWorking ? '✅ BOOKING CARD REFRESH WORKING' : '❌ ISSUES REMAIN'}`);

        if (allWorking) {
            console.log('\n🎉 SUCCESS! Booking card refresh is working correctly:');
            console.log('   - Modal pricing updates when add-ons change');
            console.log('   - Save operation completes successfully');
            console.log('   - Booking card refreshes with updated data');
            console.log('   - Final card shows correct pricing without removed add-ons');
        } else {
            console.log('\n🔧 Areas needing attention:');
            if (!testResults.modalPricingUpdated) console.log('   ❌ Modal pricing not updating');
            if (!testResults.saveSuccessful) console.log('   ❌ Save operation failing');
            if (!testResults.cardRefreshed) console.log('   ❌ Card refresh not triggering');
            if (!testResults.pricingMatches) console.log('   ❌ Card not showing updated pricing');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        await page.screenshot({ path: 'booking-card-refresh-error.png', fullPage: true });
    } finally {
        await browser.close();
    }

    return testResults;
}

if (require.main === module) {
    testBookingCardRefresh().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testBookingCardRefresh };