/**
 * Verify Edit Fix - Final Confirmation
 * Confirms that booking edits now persist correctly
 */

const { chromium } = require('playwright');

async function verifyEditFix() {
    console.log('✅ Final Verification: Edit Booking Persistence Fix');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 300,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    let success = false;

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        const firstBooking = await page.locator('.booking-card').first();
        const originalName = await firstBooking.locator('.booking-client').textContent();
        console.log('📋 Original booking name:', originalName?.trim());

        // Click edit button
        console.log('✏️ Opening edit modal...');
        const editButton = firstBooking.locator('.btn:has-text("Edit")');
        await editButton.click();
        await page.waitForTimeout(2000);

        // Wait for modal
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Make a simple name change
        const testName = `Verified Fix ${Date.now()}`;
        console.log('📝 Changing name to:', testName);
        
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.selectText();
        await page.keyboard.type(testName);

        // Monitor for network requests
        let networkRequestMade = false;
        let responseReceived = false;
        
        page.on('request', request => {
            if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                networkRequestMade = true;
                console.log('📡 PUT request detected - edit is being submitted');
            }
        });
        
        page.on('response', response => {
            if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                responseReceived = true;
                console.log('✅ 200 response received - edit successful');
            }
        });

        // Submit the form
        console.log('💾 Submitting edit...');
        const saveButton = page.locator('#editBookingForm button[type="submit"]');
        await saveButton.click();
        
        // Wait for submission to complete
        await page.waitForTimeout(3000);
        
        // Check if modal closed
        const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
        console.log('📋 Modal closed:', modalClosed);
        
        // Check for success alert
        const successAlert = await page.locator('.alert-success').count();
        console.log('📋 Success alerts:', successAlert);

        // Wait for page to refresh and verify changes
        console.log('🔍 Verifying changes persisted...');
        await page.waitForTimeout(2000);
        
        // Look for the updated booking
        const updatedBooking = await page.locator(`.booking-card:has-text("${testName}")`).count();
        console.log('📋 Updated booking found:', updatedBooking > 0);

        // Summary
        success = modalClosed && networkRequestMade && responseReceived && (updatedBooking > 0);
        
        console.log('\n📊 Fix Verification Results:');
        console.log(`✅ Network request made: ${networkRequestMade ? 'YES' : 'NO'}`);
        console.log(`✅ Response received: ${responseReceived ? 'YES' : 'NO'}`);
        console.log(`✅ Modal closed: ${modalClosed ? 'YES' : 'NO'}`);
        console.log(`✅ Changes visible: ${updatedBooking > 0 ? 'YES' : 'NO'}`);
        console.log(`\n🎯 OVERALL SUCCESS: ${success ? '✅ FIXED' : '❌ STILL BROKEN'}`);

        if (success) {
            console.log('\n🎉 BOOKING EDIT PERSISTENCE IS NOW WORKING CORRECTLY!');
            console.log('   - Form validation issues resolved');
            console.log('   - Service type population timing fixed');
            console.log('   - API calls now execute successfully');
            console.log('   - Changes persist and are visible in the admin panel');
        }

        await page.screenshot({ path: 'verify-edit-fix.png', fullPage: true });
        console.log('📸 Verification screenshot saved');

    } catch (error) {
        console.error('❌ Verification failed:', error.message);
        
        try {
            await page.screenshot({ path: 'verify-edit-fix-error.png', fullPage: true });
            console.log('📸 Error screenshot saved');
        } catch (e) {
            console.log('📸 Could not save screenshot');
        }
    } finally {
        await browser.close();
    }

    return success;
}

if (require.main === module) {
    verifyEditFix().then(success => {
        console.log(`\n${success ? '🎉' : '💥'} Verification ${success ? 'PASSED' : 'FAILED'}`);
        process.exit(success ? 0 : 1);
    }).catch(error => {
        console.error('💥 Verification execution failed:', error);
        process.exit(1);
    });
}

module.exports = { verifyEditFix };