/**
 * Test Add-on Persistence - Verifies add-ons are properly saved and loaded
 */
const { chromium } = require('playwright');

async function testAddonPersistence() {
    console.log('🧪 Testing Add-on Persistence in Edit Form');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Find a booking with add-ons
        console.log('🔍 Looking for booking with add-ons...');
        const bookingWithAddons = await page.locator('.booking-card:has-text("Add-ons:")').first();
        
        if (await bookingWithAddons.count() > 0) {
            // Click edit on this booking
            console.log('✏️ Opening edit form for booking with add-ons...');
            await bookingWithAddons.locator('button:has-text("Edit")').click();
            
            // Wait for modal
            await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
            console.log('📝 Edit modal opened');
            
            // Wait for checkboxes to be populated
            await page.waitForTimeout(500);
            
            // Check which add-ons are selected
            const checkedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
            console.log(`✅ Found ${checkedAddons} add-ons checked`);
            
            // Uncheck all add-ons
            console.log('🔲 Unchecking all add-ons...');
            const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
            const count = await checkboxes.count();
            for (let i = 0; i < count; i++) {
                await checkboxes.nth(0).click(); // Always click the first checked one
                await page.waitForTimeout(300);
            }
            
            // Verify all unchecked
            const stillChecked = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
            console.log(`📊 Add-ons checked after removal: ${stillChecked}`);
            
            // Submit the form
            console.log('💾 Saving without add-ons...');
            await page.locator('#editBookingForm button[type="submit"]').click();
            
            // Wait for success
            await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
            console.log('✅ Booking saved successfully');
            
            // Wait for modal to close
            await page.waitForSelector('#editBookingModal.active', { state: 'hidden', timeout: 5000 });
            
            // Wait for UI refresh
            await page.waitForTimeout(2000);
            
            // Re-open the same booking
            console.log('\n🔄 Re-opening booking to verify add-ons are gone...');
            const sameBooking = await page.locator('.booking-card').first();
            await sameBooking.locator('button:has-text("Edit")').click();
            
            // Wait for modal
            await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
            await page.waitForTimeout(500);
            
            // Check if add-ons are still unchecked
            const recheckedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
            
            if (recheckedAddons === 0) {
                console.log('✅ SUCCESS: Add-ons remain unchecked - persistence working correctly!');
            } else {
                console.log(`❌ FAIL: ${recheckedAddons} add-ons are checked again - persistence issue!`);
            }
            
            // Close modal
            await page.locator('#editBookingModal .modal-header .close').click();
            
        } else {
            console.log('⚠️ No bookings with add-ons found for testing');
            console.log('Creating a test booking with add-ons...');
            
            // You could add code here to create a test booking with add-ons
        }
        
        console.log('\n✅ Add-on Persistence Test Complete!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testAddonPersistence();