/**
 * Debug Calendar Implementation
 */

const { chromium } = require('playwright');

async function debugCalendar() {
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000
    });

    const page = await browser.newPage();
    
    try {
        console.log('🔍 Debug: Loading page...');
        await page.goto('https://ittheal.com', { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(3000);
        
        // Check if scripts are loaded
        const scriptsLoaded = await page.evaluate(() => {
            return {
                bookingAvailability: typeof window.BookingAvailability !== 'undefined',
                calendarBooking: typeof window.CalendarBooking !== 'undefined'
            };
        });
        console.log('📦 Scripts loaded:', scriptsLoaded);
        
        // Scroll to booking section
        await page.locator('#services').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        // Check if service selection elements exist
        const serviceElements = await page.locator('.service-option').count();
        console.log(`🎯 Found ${serviceElements} service options`);
        
        // Click service and debug step progression
        console.log('🖱️  Clicking 90min service...');
        await page.locator('.service-option[data-service="90min"]').click();
        await page.waitForTimeout(2000);
        
        // Check step progression
        const stepVisibility = await page.evaluate(() => {
            return {
                step1: document.getElementById('service-selection').style.display,
                step2: document.getElementById('datetime-selection').style.display,
                calendarContainer: document.getElementById('calendar-container') ? 'exists' : 'missing',
                currentStep: window.currentStep || 'undefined'
            };
        });
        console.log('📊 Step visibility:', stepVisibility);
        
        // Check for errors in console
        const logs = [];
        page.on('console', msg => logs.push(msg.text()));
        
        await page.waitForTimeout(2000);
        console.log('🐛 Console logs:', logs);
        
    } catch (error) {
        console.error('❌ Debug failed:', error);
    } finally {
        await browser.close();
    }
}

debugCalendar();