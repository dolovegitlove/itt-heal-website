/**
 * Check what's blocking the Create New Booking button
 */

// Run this in browser console on the admin page
console.log('🔍 Checking button visibility...');

// Check if bookings section is active
const bookingsSection = document.getElementById('bookings');
console.log('Bookings section exists:', bookingsSection ? 'YES' : 'NO');

if (bookingsSection) {
    console.log('Bookings section active:', bookingsSection.classList.contains('active'));
    
    // If not active, activate it
    if (!bookingsSection.classList.contains('active')) {
        console.log('Activating bookings section...');
        
        // Hide all sections first
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });
        
        // Show bookings section
        bookingsSection.classList.add('active');
        
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector('[data-section="bookings"]').classList.add('active');
        
        console.log('Bookings section activated');
    }
}

// Now check for the button
const createButton = document.querySelector('button[onclick="openCreateBookingModal()"]');
console.log('Create button found:', createButton ? 'YES' : 'NO');

if (createButton) {
    console.log('Button text:', createButton.textContent.trim());
    
    // Check visibility
    const style = window.getComputedStyle(createButton);
    console.log('Button display:', style.display);
    console.log('Button visibility:', style.visibility);
    console.log('Button opacity:', style.opacity);
    
    // Check parent visibility
    const parent = createButton.parentElement;
    const parentStyle = window.getComputedStyle(parent);
    console.log('Parent display:', parentStyle.display);
    console.log('Parent visibility:', parentStyle.visibility);
    
    // Highlight the button
    createButton.style.border = '3px solid red';
    createButton.style.backgroundColor = 'yellow';
    createButton.style.zIndex = '9999';
    
    console.log('✅ Button highlighted with red border and yellow background');
} else {
    console.log('❌ Button not found - checking all buttons in bookings section');
    
    if (bookingsSection) {
        const allButtons = bookingsSection.querySelectorAll('button');
        console.log(`Found ${allButtons.length} buttons in bookings section:`);
        
        allButtons.forEach((btn, index) => {
            console.log(`  ${index + 1}. "${btn.textContent.trim()}" onclick="${btn.getAttribute('onclick')}"`);
        });
    }
}

// Check for JavaScript errors
console.log('Checking for JavaScript errors...');
const errors = [];
const originalError = console.error;
console.error = function(...args) {
    errors.push(args.join(' '));
    originalError.apply(console, args);
};

setTimeout(() => {
    console.log('JavaScript errors detected:', errors.length);
    errors.forEach(error => console.log('Error:', error));
}, 1000);