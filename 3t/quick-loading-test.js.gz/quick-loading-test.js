/**
 * Quick Loading Test
 * Tests just the loading state timing
 */

const { chromium } = require('playwright');

async function quickLoadingTest() {
    console.log('⏳ Quick Loading State Test');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 800,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        const firstBooking = page.locator('.booking-card').first();
        
        console.log('✏️ Opening edit modal...');
        await firstBooking.locator('.btn:has-text("Edit")').click();
        await page.waitForTimeout(2000);

        const submitButton = page.locator('#editBookingForm button[type="submit"]');
        const originalText = await submitButton.textContent();
        console.log(`📋 Original button text: "${originalText}"`);

        // Make a change
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.press('End');
        await page.keyboard.type(' LOAD-TEST');

        // Monitor button text changes
        let buttonStates = [];
        
        const monitorButton = async () => {
            for (let i = 0; i < 50; i++) { // Monitor for 5 seconds
                try {
                    const text = await submitButton.textContent();
                    const disabled = await submitButton.getAttribute('disabled');
                    buttonStates.push({ 
                        time: Date.now(), 
                        text: text?.trim(), 
                        disabled: disabled !== null 
                    });
                    await page.waitForTimeout(100);
                } catch (e) {
                    break;
                }
            }
        };

        // Start monitoring and click at the same time
        console.log('💾 Submitting and monitoring button state...');
        monitorButton(); // Start monitoring in background
        await submitButton.click();
        
        await page.waitForTimeout(5000);

        // Analyze button states
        console.log('\n📊 Button State Timeline:');
        buttonStates.forEach((state, index) => {
            if (index === 0 || state.text !== buttonStates[index-1]?.text || state.disabled !== buttonStates[index-1]?.disabled) {
                console.log(`   ${index}: "${state.text}" (disabled: ${state.disabled})`);
            }
        });

        const foundUpdating = buttonStates.some(state => state.text?.includes('Updating'));
        const foundDisabled = buttonStates.some(state => state.disabled);
        
        console.log(`\n📊 Results:`);
        console.log(`✅ "Updating..." text found: ${foundUpdating ? 'YES' : 'NO'}`);
        console.log(`✅ Button disabled state found: ${foundDisabled ? 'YES' : 'NO'}`);
        
        const loadingWorking = foundUpdating && foundDisabled;
        console.log(`\n🎯 Loading state working: ${loadingWorking ? '✅ YES' : '❌ NO'}`);

        if (!loadingWorking) {
            console.log('\n🔧 This indicates the loading state fix may not be active.');
            console.log('   The button should show "Updating..." and be disabled during submission.');
        }

        await page.waitForTimeout(2000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    quickLoadingTest().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { quickLoadingTest };