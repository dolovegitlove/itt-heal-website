/**
 * Locate Create Button - Visual guide to find the button
 */
const { chromium } = require('playwright');

async function locateCreateButton() {
    console.log('🎯 Locating Create Booking Button - Visual Guide');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 1000
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 STEP 1: Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        console.log('📋 STEP 2: Looking for navigation tabs...');
        
        // Find all navigation items
        const navItems = await page.locator('nav a, nav button, [data-section]').all();
        console.log(`Found ${navItems.length} navigation items:`);
        
        for (let i = 0; i < navItems.length; i++) {
            const item = navItems[i];
            const text = await item.textContent();
            const isActive = await item.evaluate(el => el.classList.contains('active'));
            console.log(`  ${i + 1}. "${text}" ${isActive ? '(ACTIVE)' : ''}`);
        }
        
        console.log('\n🖱️ STEP 3: Clicking on "Bookings" tab...');
        
        // Click on bookings navigation
        const bookingsNav = page.locator('[data-section="bookings"]');
        await bookingsNav.click();
        await page.waitForTimeout(2000);
        
        console.log('✅ Bookings section is now active');
        
        console.log('\n🔍 STEP 4: Looking for the Create button...');
        
        // Find the button
        const createButton = page.locator('button:has-text("Create New Booking")');
        const buttonExists = await createButton.count();
        
        if (buttonExists > 0) {
            console.log('✅ Found Create New Booking button!');
            
            // Get button location info
            const buttonBox = await createButton.boundingBox();
            const buttonText = await createButton.textContent();
            
            console.log('\n📍 BUTTON LOCATION:');
            console.log(`Text: "${buttonText}"`);
            console.log(`Position: x=${buttonBox.x}, y=${buttonBox.y}`);
            console.log(`Size: ${buttonBox.width}x${buttonBox.height}`);
            
            // Check what's around the button
            const parentElement = await createButton.evaluate(button => {
                const parent = button.parentElement;
                return {
                    tagName: parent.tagName,
                    className: parent.className,
                    text: parent.textContent.substring(0, 100)
                };
            });
            
            console.log('\n🏠 BUTTON CONTAINER:');
            console.log(`Parent: <${parentElement.tagName} class="${parentElement.className}">`);
            console.log(`Content preview: "${parentElement.text}..."`);
            
            // Highlight the button by adding a red border
            await createButton.evaluate(button => {
                button.style.border = '3px solid red';
                button.style.boxShadow = '0 0 10px red';
            });
            
            console.log('\n🎯 VISUAL GUIDE:');
            console.log('1. Look at the admin panel in the browser');
            console.log('2. You should see a "Bookings" tab in the navigation');
            console.log('3. Click on the "Bookings" tab');
            console.log('4. Look for the "All Bookings" section');
            console.log('5. The "Create New Booking" button should be at the TOP RIGHT');
            console.log('6. The button is now highlighted with a RED BORDER');
            
            console.log('\n⏰ Waiting 10 seconds so you can see the button...');
            await page.waitForTimeout(10000);
            
            console.log('\n🖱️ STEP 5: Testing the button...');
            await createButton.click();
            
            await page.waitForTimeout(2000);
            
            const modalExists = await page.locator('#createBookingModal.active').count();
            if (modalExists > 0) {
                console.log('✅ SUCCESS: Button clicked and modal opened!');
                
                // Show modal title
                const modalTitle = await page.locator('#createBookingModal .modal-title').textContent();
                console.log(`Modal title: "${modalTitle}"`);
                
                await page.waitForTimeout(3000);
            } else {
                console.log('❌ Modal did not open');
            }
            
        } else {
            console.log('❌ Create button not found');
        }
        
        console.log('\n✅ LOCATION GUIDE COMPLETE');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the location guide
locateCreateButton();