/**
 * Debug Edit Form Submission
 * Captures browser console logs and network requests during edit
 */

const { chromium } = require('playwright');

async function debugEditFormSubmission() {
    console.log('🔍 Debugging Edit Form Submission');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    const logs = [];
    const networkRequests = [];

    // Capture console logs
    page.on('console', msg => {
        const logEntry = `${msg.type()}: ${msg.text()}`;
        logs.push(logEntry);
        console.log(`Browser: ${logEntry}`);
    });

    // Capture network requests
    page.on('request', request => {
        if (request.url().includes('/api/admin/bookings')) {
            networkRequests.push({
                type: 'request',
                method: request.method(),
                url: request.url(),
                headers: request.headers(),
                postData: request.postData()
            });
            console.log(`Network Request: ${request.method()} ${request.url()}`);
        }
    });

    page.on('response', response => {
        if (response.url().includes('/api/admin/bookings')) {
            networkRequests.push({
                type: 'response',
                status: response.status(),
                url: response.url(),
                headers: response.headers()
            });
            console.log(`Network Response: ${response.status()} ${response.url()}`);
        }
    });

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });
        
        const firstBooking = await page.locator('.booking-card').first();
        const originalClientName = await firstBooking.locator('.booking-client').textContent();
        console.log('📋 Original client name:', originalClientName?.trim());

        // Click the edit button
        console.log('✏️ Clicking edit button...');
        const editButton = firstBooking.locator('.btn:has-text("Edit")');
        await editButton.click();
        await page.waitForTimeout(2000);

        // Wait for edit modal to appear
        console.log('⏳ Waiting for edit modal...');
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Get the booking ID from the form
        const bookingId = await page.locator('#editBookingId').inputValue();
        console.log('📝 Editing booking ID:', bookingId);

        // Modify just the client name for simplicity
        const newClientName = `Debug Test ${Date.now()}`;
        console.log('📝 Setting new client name:', newClientName);
        
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.selectText();
        await page.keyboard.type(newClientName);

        // Clear the logs to focus on submission
        logs.length = 0;
        networkRequests.length = 0;

        // Submit the form
        console.log('💾 Submitting form...');
        const saveButton = page.locator('#editBookingForm button[type="submit"]');
        await saveButton.click();
        
        // Wait to capture the submission process
        await page.waitForTimeout(5000);

        // Check if modal is still open
        const modalStillOpen = await page.locator('#editBookingModal.active').isVisible();
        console.log('📋 Modal still open after submission:', modalStillOpen);

        // Check for any alert messages
        const alertSuccess = await page.locator('.alert-success').count();
        const alertError = await page.locator('.alert-error').count();
        console.log('📋 Success alerts:', alertSuccess);
        console.log('📋 Error alerts:', alertError);

        if (alertError > 0) {
            const errorText = await page.locator('.alert-error').first().textContent();
            console.log('❌ Error message:', errorText);
        }

        if (alertSuccess > 0) {
            const successText = await page.locator('.alert-success').first().textContent();
            console.log('✅ Success message:', successText);
        }

        // Log all captured network activity
        console.log('\n📊 Network Activity Summary:');
        networkRequests.forEach((req, index) => {
            console.log(`${index + 1}. ${req.type}: ${req.method || req.status} ${req.url}`);
            if (req.postData) {
                console.log(`   POST Data: ${req.postData}`);
            }
        });

        // Log important console messages
        console.log('\n📊 Important Browser Logs:');
        logs.filter(log => 
            log.includes('error') || 
            log.includes('Edit') || 
            log.includes('response') ||
            log.includes('success')
        ).forEach(log => console.log(`   ${log}`));

        await page.screenshot({ path: 'debug-edit-form.png', fullPage: true });
        console.log('📸 Debug screenshot saved');

    } catch (error) {
        console.error('❌ Debug failed:', error.message);
        
        try {
            await page.screenshot({ path: 'debug-edit-form-error.png', fullPage: true });
            console.log('📸 Error screenshot saved');
        } catch (e) {
            console.log('📸 Could not save screenshot');
        }
    } finally {
        await browser.close();
    }

    return { logs, networkRequests };
}

if (require.main === module) {
    debugEditFormSubmission().catch(error => {
        console.error('💥 Debug execution failed:', error);
        process.exit(1);
    });
}

module.exports = { debugEditFormSubmission };