const { chromium } = require('playwright');

async function testJSSyntax() {
    console.log('🔍 Testing JavaScript syntax on live admin dashboard...');
    
    const browser = await chromium.launch({
        headless: false,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    
    try {
        // Capture console messages and errors
        const messages = [];
        const errors = [];
        
        page.on('console', (msg) => {
            messages.push(`[${msg.type()}] ${msg.text()}`);
        });
        
        page.on('pageerror', (error) => {
            errors.push(error.message);
        });
        
        // Navigate to admin dashboard
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        // Wait for page to fully load
        await page.waitForTimeout(3000);
        
        // Test if functions are available after load
        const testResult = await page.evaluate(() => {
            return {
                toggleSidebarExists: typeof window.toggleSidebar === 'function',
                closeSidebarExists: typeof window.closeSidebar === 'function',
                documentReady: document.readyState,
                sidebarExists: !!document.getElementById('sidebar'),
                overlayExists: !!document.getElementById('sidebarOverlay'),
                menuToggleExists: !!document.querySelector('.menu-toggle'),
                scriptErrors: window.lastError || null
            };
        });
        
        console.log('🧪 Test Results:', testResult);
        console.log('📝 Console Messages:', messages);
        console.log('❌ JavaScript Errors:', errors);
        
        // Try to manually define the functions to see if there's an execution issue
        const manualTest = await page.evaluate(() => {
            try {
                // Try to manually create the functions
                window.testToggleSidebar = function() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    
                    if (sidebar && overlay) {
                        sidebar.classList.toggle('open');
                        overlay.classList.toggle('active');
                        return 'Manual function worked';
                    }
                    return 'Elements not found';
                };
                
                return window.testToggleSidebar();
            } catch (e) {
                return 'Manual function error: ' + e.message;
            }
        });
        
        console.log('🔧 Manual function test:', manualTest);
        
    } catch (error) {
        console.error('❌ Test failed:', error);
    } finally {
        await browser.close();
    }
}

testJSSyntax();