/**
 * Manual Find Button - Step by step guide
 */
const { chromium } = require('playwright');

async function manualFindButton() {
    console.log('🔍 Manual Step-by-Step Button Location Guide');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 1000
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('\n📱 STEP 1: Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(2000);
        
        console.log('\n📍 STEP 2: You should see the left sidebar navigation');
        console.log('Look for these navigation items:');
        console.log('  - Dashboard Overview (active)');
        console.log('  - Bookings Management');
        console.log('  - Schedule & Availability');
        console.log('  - Client Records');
        console.log('  - Payments & Revenue');
        
        await page.waitForTimeout(3000);
        
        console.log('\n🖱️ STEP 3: I will click on "Bookings Management"...');
        
        // Highlight the bookings nav item
        const bookingsNav = page.locator('[data-section="bookings"]');
        await bookingsNav.evaluate(el => {
            el.style.border = '3px solid yellow';
            el.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';
        });
        
        await page.waitForTimeout(2000);
        
        await bookingsNav.click();
        await page.waitForTimeout(2000);
        
        console.log('\n📋 STEP 4: Now looking in the bookings section...');
        
        // Check if the button exists
        const createButton = page.locator('button:has-text("Create New Booking")');
        const buttonExists = await createButton.count();
        
        if (buttonExists > 0) {
            console.log('✅ Found the Create New Booking button!');
            
            // Highlight the button
            await createButton.evaluate(button => {
                button.style.border = '5px solid red';
                button.style.backgroundColor = 'rgba(255, 0, 0, 0.3)';
                button.style.transform = 'scale(1.1)';
            });
            
            console.log('\n🎯 STEP 5: The button should now be highlighted with RED border');
            console.log('Location: In the "All Bookings" section, top-right corner');
            console.log('The button has a plus icon and says "Create New Booking"');
            
            await page.waitForTimeout(3000);
            
            console.log('\n🖱️ STEP 6: Testing the button click...');
            await createButton.click();
            
            await page.waitForTimeout(2000);
            
            const modalExists = await page.locator('#createBookingModal.active').count();
            
            if (modalExists > 0) {
                console.log('✅ SUCCESS: Modal opened! The button works.');
                
                // Highlight the modal
                await page.locator('#createBookingModal').evaluate(modal => {
                    modal.style.border = '5px solid green';
                });
                
                console.log('The create booking form should now be visible in a modal.');
                
            } else {
                console.log('❌ Modal did not open');
            }
            
        } else {
            console.log('❌ Button not found');
            
            // Show what IS visible
            const visibleButtons = await page.locator('button:visible').all();
            console.log('\nVisible buttons found:');
            for (let i = 0; i < visibleButtons.length; i++) {
                const text = await visibleButtons[i].textContent();
                console.log(`  ${i + 1}. "${text.trim()}"`);
            }
        }
        
        console.log('\n⏰ Browser will stay open for 15 seconds...');
        console.log('Please look at the browser window to see the highlighted elements');
        await page.waitForTimeout(15000);
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the manual guide
manualFindButton();