/**
 * SIMPLE BOOKING RELIABILITY TEST
 * Avoids CSP issues by using simple polling instead of waitForFunction
 * Tests the actual booking persistence issue with 12 runs
 */

const { chromium } = require('playwright');

async function testBookingReliabilitySimple() {
    console.log('🚀 Starting Simple Booking Reliability Test...');
    console.log('🎯 TARGET: Identify availability persistence issues');
    console.log('🌐 USING: Live backend at https://ittheal.com\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 300,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-web-security' // Bypass CSP for testing
        ]
    });

    const page = await browser.newPage();
    
    let successCount = 0;
    let failureCount = 0;
    const testResults = [];
    
    try {
        for (let testRun = 1; testRun <= 12; testRun++) {
            console.log(`\n${'='.repeat(15)} TEST RUN ${testRun}/12 ${'='.repeat(15)}`);
            
            try {
                // Step 1: Navigate
                console.log('📍 Navigate to booking...');
                await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
                await page.waitForTimeout(2000);
                
                // Step 2: Scroll to booking
                await page.locator('#booking').scrollIntoViewIfNeeded();
                await page.waitForTimeout(1000);
                
                // Step 3: Select service
                console.log('📍 Select 60-minute service...');
                await page.locator('.service-option[data-service="60min"]').click();
                await page.waitForTimeout(1000);
                
                // Step 4: Click Next
                console.log('📍 Click Next...');
                await page.locator('#next-btn').click();
                await page.waitForTimeout(2000);
                
                // Step 5: Enter date
                console.log('📍 Enter date...');
                const dateInput = page.locator('#booking-date');
                await dateInput.click();
                await page.waitForTimeout(300);
                
                await page.keyboard.press('Control+a');
                await page.waitForTimeout(100);
                await page.keyboard.press('Delete');
                await page.waitForTimeout(100);
                
                // Enter next Monday
                const futureDate = new Date();
                futureDate.setDate(futureDate.getDate() + 14);
                while (futureDate.getDay() !== 1) {
                    futureDate.setDate(futureDate.getDate() + 1);
                }
                
                const dateString = futureDate.toISOString().split('T')[0];
                await page.keyboard.type(dateString);
                await page.waitForTimeout(500);
                await page.keyboard.press('Tab');
                
                console.log(`   Date: ${dateString}`);
                
                // Step 6: Wait for time slots (simple polling)
                console.log('📍 Wait for time slots...');
                
                const timeSelect = page.locator('#booking-time');
                let optionsLoaded = false;
                let attempts = 0;
                const maxAttempts = 30; // 15 seconds
                
                while (!optionsLoaded && attempts < maxAttempts) {
                    attempts++;
                    await page.waitForTimeout(500);
                    
                    try {
                        const isDisabled = await timeSelect.getAttribute('disabled');
                        const optionCount = await timeSelect.locator('option[value]:not([value=""])').count();
                        
                        console.log(`   Attempt ${attempts}: ${optionCount} options, disabled: ${isDisabled}`);
                        
                        if (optionCount > 0 && !isDisabled) {
                            optionsLoaded = true;
                            console.log(`   ✅ Options loaded after ${attempts * 500}ms`);
                        }
                    } catch (error) {
                        console.log(`   Attempt ${attempts}: Error checking - ${error.message}`);
                    }
                }
                
                if (!optionsLoaded) {
                    throw new Error(`Time slots failed to load after ${maxAttempts * 500}ms`);
                }
                
                // Step 7: Select time
                console.log('📍 Select time...');
                
                const options = await timeSelect.locator('option[value]:not([value=""])').all();
                if (options.length === 0) {
                    throw new Error('No time options available after loading');
                }
                
                const firstOptionValue = await options[0].getAttribute('value');
                const firstOptionText = await options[0].textContent();
                
                console.log(`   Selecting: ${firstOptionText} (${firstOptionValue})`);
                
                // Use selectOption for proper dropdown interaction
                await timeSelect.selectOption(firstOptionValue);
                await page.waitForTimeout(1000);
                
                // Step 8: Verify selection persisted
                console.log('📍 Verify selection...');
                
                const selectedValue = await timeSelect.inputValue();
                if (selectedValue !== firstOptionValue) {
                    throw new Error(`Selection failed: expected ${firstOptionValue}, got ${selectedValue}`);
                }
                
                console.log(`   ✅ Selection persisted: ${selectedValue}`);
                
                // Step 9: Test focus loss persistence
                console.log('📍 Test focus persistence...');
                
                await page.locator('body').click();
                await page.waitForTimeout(500);
                
                const persistedValue = await timeSelect.inputValue();
                if (persistedValue !== firstOptionValue) {
                    throw new Error(`Selection lost after focus: expected ${firstOptionValue}, got ${persistedValue}`);
                }
                
                console.log(`   ✅ Survived focus loss`);
                
                // Step 10: Try to proceed
                console.log('📍 Proceed to next step...');
                
                await page.locator('#next-btn').click();
                await page.waitForTimeout(3000);
                
                const contactVisible = await page.locator('#contact-info').isVisible();
                const errorCount = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').count();
                
                if (contactVisible) {
                    console.log(`   ✅ SUCCESS - Reached contact info`);
                    successCount++;
                    testResults.push({
                        run: testRun,
                        status: 'SUCCESS',
                        timeValue: firstOptionValue,
                        timeText: firstOptionText,
                        loadTime: attempts * 500
                    });
                } else if (errorCount > 0) {
                    const errorText = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').first().textContent();
                    throw new Error(`Validation error: ${errorText}`);
                } else {
                    throw new Error('Failed to progress - unknown issue');
                }
                
            } catch (error) {
                console.error(`   ❌ FAILED: ${error.message}`);
                failureCount++;
                testResults.push({
                    run: testRun,
                    status: 'FAILURE',
                    error: error.message
                });
            }
            
            // Reset for next test
            if (testRun < 12) {
                await page.goto('about:blank');
                await page.waitForTimeout(1000);
            }
        }
        
        // RESULTS
        console.log('\n' + '='.repeat(60));
        console.log('📊 BOOKING RELIABILITY TEST RESULTS');
        console.log('='.repeat(60));
        
        const successRate = Math.round(successCount/12*100);
        
        console.log(`✅ Successful: ${successCount}/12 (${successRate}%)`);
        console.log(`❌ Failed: ${failureCount}/12 (${Math.round(failureCount/12*100)}%)`);
        
        if (successRate === 100) {
            console.log('\n🎉 PERFECT! 100% SUCCESS RATE');
            console.log('✅ Booking system is reliable for production');
        } else if (successRate >= 80) {
            console.log('\n✅ GOOD: ≥80% success rate');
            console.log('⚠️  Minor issues but mostly reliable');
        } else {
            console.log('\n❌ POOR: <80% success rate');
            console.log('🚨 CRITICAL ISSUES - Needs fixing');
        }
        
        // Error analysis
        if (failureCount > 0) {
            console.log('\n🔍 FAILURE ANALYSIS:');
            const failures = testResults.filter(r => r.status === 'FAILURE');
            const errorTypes = {};
            
            failures.forEach(failure => {
                const errorKey = failure.error.includes('Time slots failed') ? 'Loading timeout' :
                                failure.error.includes('Selection failed') ? 'Selection persistence' :
                                failure.error.includes('Selection lost') ? 'Focus persistence' :
                                failure.error.includes('Validation error') ? 'Validation error' :
                                'Other error';
                errorTypes[errorKey] = (errorTypes[errorKey] || 0) + 1;
            });
            
            Object.entries(errorTypes).forEach(([error, count]) => {
                console.log(`   ${error}: ${count} times`);
            });
        }
        
        // Performance analysis
        if (successCount > 0) {
            const successes = testResults.filter(r => r.status === 'SUCCESS');
            const avgLoadTime = successes.reduce((sum, s) => sum + s.loadTime, 0) / successes.length;
            console.log(`\n📈 Average load time: ${avgLoadTime}ms`);
        }
        
        console.log('\n🎯 PRODUCTION REQUIREMENT: 100% success rate needed');
        
        // Keep browser open
        console.log('\n🔍 Browser stays open for 15 seconds...');
        await page.waitForTimeout(15000);
        
    } catch (error) {
        console.error('\n💥 TEST SUITE FAILURE:', error.message);
    } finally {
        await browser.close();
    }
    
    return {
        successCount,
        failureCount,
        successRate: Math.round(successCount/12*100),
        testResults
    };
}

// Execute
if (require.main === module) {
    testBookingReliabilitySimple()
        .then((results) => {
            console.log('\n✅ Booking reliability test completed');
            
            if (results.successRate === 100) {
                console.log('🎉 BOOKING SYSTEM IS 100% RELIABLE!');
                process.exit(0);
            } else {
                console.log(`❌ RELIABILITY ISSUE: ${results.successRate}% success rate`);
                process.exit(1);
            }
        })
        .catch((error) => {
            console.error('\n❌ Test failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testBookingReliabilitySimple };