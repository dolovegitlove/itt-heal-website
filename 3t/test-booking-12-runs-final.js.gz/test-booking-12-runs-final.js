/**
 * FINAL BOOKING SYSTEM TEST - 12 RUNS
 * Tests 100% reliability of the booking system with correct selectors
 * Uses proper service selection and dropdown interaction
 */

const { chromium } = require('playwright');

async function testBooking12RunsFinal() {
    console.log('🚀 Starting FINAL 12-Run Booking Reliability Test...');
    console.log('🎯 TARGET: 100% success rate (12/12 successful bookings)');
    console.log('🌐 USING: Live backend at https://ittheal.com\n');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 400,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    let successCount = 0;
    let failureCount = 0;
    const testResults = [];
    
    try {
        for (let testRun = 1; testRun <= 12; testRun++) {
            console.log(`\n${'='.repeat(20)} TEST RUN ${testRun}/12 ${'='.repeat(20)}`);
            
            const testStartTime = Date.now();
            
            try {
                // Step 1: Navigate to live site
                console.log('📍 Step 1: Navigate to live booking page...');
                await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
                await page.waitForTimeout(2000);
                
                // Step 2: Scroll to booking section
                console.log('📍 Step 2: Scroll to booking section...');
                await page.locator('#booking').scrollIntoViewIfNeeded();
                await page.waitForTimeout(1000);
                
                // Step 3: Select service (use 60-minute service)
                console.log('📍 Step 3: Select 60-minute service...');
                const serviceOption = page.locator('.service-option[data-service="60min"]');
                await serviceOption.click();
                await page.waitForTimeout(1000);
                
                // Verify service selection
                const activeService = await page.locator('.service-option.active').getAttribute('data-service-type');
                if (activeService !== '60min_massage') {
                    throw new Error(`Service selection failed: expected 60min_massage, got ${activeService}`);
                }
                console.log(`   ✅ Service selected: ${activeService}`);
                
                // Step 4: Click Next to proceed
                console.log('📍 Step 4: Click Next to proceed to date/time...');
                await page.locator('#next-btn').click();
                await page.waitForTimeout(2000);
                
                // Verify we're on date/time selection
                const datetimeVisible = await page.locator('#datetime-selection').isVisible();
                if (!datetimeVisible) {
                    throw new Error('Failed to navigate to date/time selection');
                }
                console.log('   ✅ Navigated to date/time selection');
                
                // Step 5: Select a valid future date
                console.log('📍 Step 5: Select valid future date...');
                const dateInput = page.locator('#booking-date');
                await dateInput.click();
                await page.waitForTimeout(500);
                
                // Clear and enter a date 2 weeks from now (business day)
                await page.keyboard.press('Control+a');
                await page.waitForTimeout(200);
                await page.keyboard.press('Delete');
                await page.waitForTimeout(200);
                
                // Calculate a Monday 2 weeks from now
                const futureDate = new Date();
                futureDate.setDate(futureDate.getDate() + 14);
                while (futureDate.getDay() !== 1) { // Make it a Monday
                    futureDate.setDate(futureDate.getDate() + 1);
                }
                
                const dateString = futureDate.toISOString().split('T')[0]; // YYYY-MM-DD format
                await page.keyboard.type(dateString);
                await page.waitForTimeout(500);
                await page.keyboard.press('Tab');
                
                console.log(`   Date entered: ${dateString}`);
                
                // Step 6: Wait for availability to load
                console.log('📍 Step 6: Wait for time slots to load...');
                
                const timeSelect = page.locator('#booking-time');
                
                // Wait for dropdown to be enabled and have options
                await page.waitForFunction(() => {
                    const select = document.getElementById('booking-time');
                    if (!select) return false;
                    
                    const options = select.querySelectorAll('option[value]:not([value=""])');
                    return options.length > 0 && !select.disabled;
                }, { timeout: 15000 });
                
                console.log('   ✅ Time slots loaded successfully');
                
                // Step 7: Select time (CRITICAL TEST)
                console.log('📍 Step 7: Select available time...');
                
                const availableOptions = await page.locator('#booking-time option[value]:not([value=""])').all();
                if (availableOptions.length === 0) {
                    throw new Error('No time options available');
                }
                
                // Get the first available time
                const firstOptionValue = await availableOptions[0].getAttribute('value');
                const firstOptionText = await availableOptions[0].textContent();
                
                console.log(`   Available options: ${availableOptions.length}`);
                console.log(`   Selecting: ${firstOptionText} (${firstOptionValue})`);
                
                // Use selectOption() for reliable dropdown selection
                await timeSelect.selectOption(firstOptionValue);
                await page.waitForTimeout(1000);
                
                // Verify selection persisted
                const selectedValue = await timeSelect.inputValue();
                if (selectedValue !== firstOptionValue) {
                    throw new Error(`Time selection did not persist: expected ${firstOptionValue}, got ${selectedValue}`);
                }
                
                console.log(`   ✅ Time selection persisted: ${selectedValue}`);
                
                // Step 8: Test persistence after focus change
                console.log('📍 Step 8: Test selection persistence...');
                
                // Click elsewhere to lose focus
                await page.locator('body').click();
                await page.waitForTimeout(500);
                
                // Verify selection is still there
                const persistedValue = await timeSelect.inputValue();
                if (persistedValue !== firstOptionValue) {
                    throw new Error(`Time selection lost after focus change: expected ${firstOptionValue}, got ${persistedValue}`);
                }
                
                console.log(`   ✅ Time selection survived focus change`);
                
                // Step 9: Proceed to contact info
                console.log('📍 Step 9: Proceed to contact info...');
                
                const nextBtn = page.locator('#next-btn');
                await nextBtn.click();
                await page.waitForTimeout(3000);
                
                // Check if we successfully progressed
                const contactVisible = await page.locator('#contact-info').isVisible();
                const errorElements = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').count();
                
                if (contactVisible) {
                    console.log(`   ✅ Successfully progressed to contact info`);
                    
                    // Fill out contact info to complete the test
                    console.log('📍 Step 10: Fill contact information...');
                    
                    await page.locator('#client-name').fill(`Test User ${testRun}`);
                    await page.waitForTimeout(300);
                    
                    await page.locator('#client-email').fill(`test${testRun}@example.com`);
                    await page.waitForTimeout(300);
                    
                    await page.locator('#client-phone').fill('(555) 123-4567');
                    await page.waitForTimeout(300);
                    
                    console.log('   ✅ Contact information filled');
                    
                    // Try to proceed to verify the booking flow works end-to-end
                    await page.locator('#next-btn').click();
                    await page.waitForTimeout(2000);
                    
                    const paymentVisible = await page.locator('#payment-info').isVisible();
                    if (paymentVisible) {
                        console.log('   ✅ Reached payment step - booking flow complete');
                    }
                    
                    const testDuration = Date.now() - testStartTime;
                    successCount++;
                    testResults.push({
                        run: testRun,
                        status: 'SUCCESS',
                        timeValue: firstOptionValue,
                        timeText: firstOptionText,
                        availableOptions: availableOptions.length,
                        duration: testDuration,
                        date: dateString
                    });
                    
                } else if (errorElements > 0) {
                    const errorText = await page.locator('.error:visible, [style*="color: #dc2626"]:visible').first().textContent();
                    throw new Error(`Validation error prevented progress: ${errorText}`);
                } else {
                    throw new Error('Failed to progress to contact info - no error shown');
                }
                
            } catch (error) {
                console.error(`   ❌ TEST RUN ${testRun} FAILED: ${error.message}`);
                
                const testDuration = Date.now() - testStartTime;
                failureCount++;
                testResults.push({
                    run: testRun,
                    status: 'FAILURE',
                    error: error.message,
                    duration: testDuration
                });
                
                // Take screenshot on failure
                await page.screenshot({ 
                    path: `booking-failure-final-run-${testRun}.png`, 
                    fullPage: true 
                });
                console.log(`   📸 Failure screenshot: booking-failure-final-run-${testRun}.png`);
            }
            
            // Reset for next test
            if (testRun < 12) {
                console.log('🔄 Resetting for next test...');
                await page.goto('about:blank');
                await page.waitForTimeout(1000);
            }
        }
        
        // FINAL RESULTS ANALYSIS
        console.log('\n' + '='.repeat(70));
        console.log('🏆 FINAL BOOKING SYSTEM RELIABILITY TEST RESULTS');
        console.log('='.repeat(70));
        
        const successRate = Math.round(successCount/12*100);
        
        console.log(`✅ Successful bookings: ${successCount}/12 (${successRate}%)`);
        console.log(`❌ Failed bookings: ${failureCount}/12 (${Math.round(failureCount/12*100)}%)`);
        
        // Success rate evaluation
        if (successCount === 12) {
            console.log('\n🎉 PERFECT! 100% SUCCESS RATE ACHIEVED!');
            console.log('✅ Booking system is 100% reliable for production');
            console.log('✅ All 12 booking attempts completed successfully');
            console.log('✅ Time slot persistence works perfectly');
        } else if (successCount >= 10) {
            console.log('\n✅ EXCELLENT! ≥83% success rate');
            console.log('⚠️  Nearly production ready with minor issues');
        } else if (successCount >= 8) {
            console.log('\n⚠️ MODERATE: 67-82% success rate');
            console.log('🔧 Needs improvement before production deployment');
        } else {
            console.log('\n❌ POOR: <67% success rate');
            console.log('🚨 CRITICAL ISSUES - Major fixes required');
        }
        
        // Performance analysis
        if (successCount > 0) {
            const successes = testResults.filter(r => r.status === 'SUCCESS');
            const avgDuration = successes.reduce((sum, s) => sum + s.duration, 0) / successes.length;
            const avgOptions = successes.reduce((sum, s) => sum + s.availableOptions, 0) / successes.length;
            
            console.log(`\n📊 PERFORMANCE METRICS:`);
            console.log(`   Average booking time: ${Math.round(avgDuration/1000)}s`);
            console.log(`   Average time slots available: ${Math.round(avgOptions)}`);
            
            const fastestRun = successes.reduce((min, s) => s.duration < min.duration ? s : min);
            const slowestRun = successes.reduce((max, s) => s.duration > max.duration ? s : max);
            
            console.log(`   Fastest booking: ${Math.round(fastestRun.duration/1000)}s (Run ${fastestRun.run})`);
            console.log(`   Slowest booking: ${Math.round(slowestRun.duration/1000)}s (Run ${slowestRun.run})`);
        }
        
        // Error analysis
        if (failureCount > 0) {
            console.log(`\n🚨 FAILURE ANALYSIS:`);
            const failures = testResults.filter(r => r.status === 'FAILURE');
            const errorTypes = {};
            
            failures.forEach(failure => {
                const errorType = failure.error.split(':')[0];
                errorTypes[errorType] = (errorTypes[errorType] || 0) + 1;
            });
            
            Object.entries(errorTypes).forEach(([error, count]) => {
                console.log(`   ${error}: ${count} occurrence(s)`);
            });
            
            console.log(`\n   Failed runs: ${failures.map(f => f.run).join(', ')}`);
        }
        
        // Recommendation
        console.log(`\n💡 RECOMMENDATION:`);
        if (successRate === 100) {
            console.log(`   ✅ DEPLOY TO PRODUCTION - System is 100% reliable`);
        } else if (successRate >= 90) {
            console.log(`   ⚠️  MONITOR CLOSELY - High reliability but watch for patterns`);
        } else {
            console.log(`   ❌ DO NOT DEPLOY - Fix persistence issues first`);
        }
        
        // Keep browser open for final inspection
        console.log('\n🔍 Keeping browser open for final inspection (20 seconds)...');
        await page.waitForTimeout(20000);
        
    } catch (error) {
        console.error('\n💥 OVERALL TEST SUITE FAILURE:', error.message);
        await page.screenshot({ path: 'booking-test-suite-crash.png', fullPage: true });
    } finally {
        await browser.close();
    }
    
    return {
        successCount,
        failureCount,
        totalTests: 12,
        successRate: Math.round(successCount/12*100),
        testResults
    };
}

// Execute the comprehensive test
if (require.main === module) {
    testBooking12RunsFinal()
        .then((results) => {
            console.log('\n🏁 12-run booking reliability test completed');
            
            if (results.successRate === 100) {
                console.log('🎉 BOOKING SYSTEM CERTIFIED 100% RELIABLE!');
                console.log('✅ Ready for production deployment');
                process.exit(0);
            } else {
                console.log(`❌ BOOKING RELIABILITY ISSUE: ${results.successRate}% success rate`);
                console.log('🔧 Persistence issues require fixing before production');
                process.exit(1);
            }
        })
        .catch((error) => {
            console.error('\n❌ Test execution failed:', error.message);
            process.exit(1);
        });
}

module.exports = { testBooking12RunsFinal };