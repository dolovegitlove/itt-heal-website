/**
 * Complete Edit Fixes Test - UI Refresh + Add-on Persistence
 */
const { chromium } = require('playwright');

async function testEditFixesComplete() {
    console.log('🧪 Testing Complete Edit Fixes - UI Refresh + Add-on Handling');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 300
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 10000 });
        
        // Test 1: UI Refresh
        console.log('\n📊 TEST 1: UI Refresh After Edit');
        const firstBooking = await page.locator('.booking-card').first();
        const originalName = await firstBooking.locator('h3').textContent();
        console.log(`Original name: ${originalName}`);
        
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
        
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.clear();
        const newName = `UI Test ${Date.now()}`;
        await nameInput.type(newName);
        
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        await page.waitForSelector('#editBookingModal.active', { state: 'hidden', timeout: 5000 });
        
        // Check immediate UI update
        await page.waitForTimeout(1000);
        const updatedCard = await page.locator(`.booking-card:has(h3:has-text("${newName}"))`).first();
        const uiRefreshWorks = await updatedCard.isVisible();
        console.log(`✅ UI Refresh: ${uiRefreshWorks ? 'PASSED' : 'FAILED'}`);
        
        // Test 2: Add-on Removal Persistence
        console.log('\n📊 TEST 2: Add-on Removal Persistence');
        
        // Find or use the same booking
        await updatedCard.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
        await page.waitForTimeout(500);
        
        // Check current add-ons
        const checkedBefore = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        console.log(`Add-ons currently checked: ${checkedBefore}`);
        
        if (checkedBefore > 0) {
            // Uncheck all
            const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
            const count = await checkboxes.count();
            for (let i = 0; i < count; i++) {
                await checkboxes.nth(0).click();
                await page.waitForTimeout(200);
            }
            console.log('Unchecked all add-ons');
        } else {
            // Check some add-ons first
            const availableAddons = await page.locator('#editAddonsContainer input[type="checkbox"]');
            const addonCount = await availableAddons.count();
            if (addonCount > 0) {
                await availableAddons.nth(0).click();
                console.log('Checked first add-on for testing');
            }
        }
        
        // Save
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        await page.waitForSelector('#editBookingModal.active', { state: 'hidden', timeout: 5000 });
        await page.waitForTimeout(2000);
        
        // Re-open to verify
        const sameCard = await page.locator(`.booking-card:has(h3:has-text("${newName}"))`).first();
        await sameCard.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 5000 });
        await page.waitForTimeout(500);
        
        const checkedAfter = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const expectedChecked = checkedBefore > 0 ? 0 : 1;
        const addonPersistenceWorks = checkedAfter === expectedChecked;
        
        console.log(`Expected ${expectedChecked} checked, found ${checkedAfter}`);
        console.log(`✅ Add-on Persistence: ${addonPersistenceWorks ? 'PASSED' : 'FAILED'}`);
        
        // Summary
        console.log('\n📋 TEST SUMMARY:');
        console.log(`- UI Refresh: ${uiRefreshWorks ? '✅ PASSED' : '❌ FAILED'}`);
        console.log(`- Add-on Persistence: ${addonPersistenceWorks ? '✅ PASSED' : '❌ FAILED'}`);
        
        if (uiRefreshWorks && addonPersistenceWorks) {
            console.log('\n🎉 ALL TESTS PASSED! Edit functionality is working correctly.');
        } else {
            console.log('\n⚠️ Some tests failed. Check the results above.');
        }
        
    } catch (error) {
        console.error('❌ Test error:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the test
testEditFixesComplete();