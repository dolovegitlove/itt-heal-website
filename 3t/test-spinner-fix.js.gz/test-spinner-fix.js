/**
 * Test Spinner Fix
 * Verifies that the loading spinner is no longer showing
 */

const { chromium } = require('playwright');

async function testSpinnerFix() {
    console.log('🧪 Testing Spinner Fix');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        console.log('🔧 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(5000); // Give time for everything to load

        // Check for any spinning elements
        console.log('🔍 Checking for spinning elements...');
        
        const spinningElements = await page.evaluate(() => {
            const elements = document.querySelectorAll('*');
            const spinning = [];
            
            elements.forEach(el => {
                const styles = window.getComputedStyle(el);
                if (styles.animation.includes('spin') && styles.animation !== 'none') {
                    spinning.push({
                        tagName: el.tagName,
                        className: el.className,
                        id: el.id,
                        animation: styles.animation
                    });
                }
            });
            
            return spinning;
        });

        console.log(`📊 Found ${spinningElements.length} actively spinning elements`);
        
        if (spinningElements.length > 0) {
            spinningElements.forEach((el, i) => {
                console.log(`  ${i + 1}. ${el.tagName}.${el.className}#${el.id}: ${el.animation}`);
            });
        }

        // Check for visible loading elements
        const visibleLoading = await page.locator('.loading:visible').count();
        console.log(`📊 Visible loading elements: ${visibleLoading}`);

        // Check specifically for booking card loading
        const bookingCardLoading = await page.evaluate(() => {
            const bookingCards = document.querySelectorAll('.booking-card');
            let loadingCards = 0;
            
            bookingCards.forEach(card => {
                if (card.classList.contains('loading')) {
                    loadingCards++;
                }
            });
            
            return loadingCards;
        });

        console.log(`📊 Booking cards with loading class: ${bookingCardLoading}`);

        // Visual check for the CSS after pseudo-element
        const hasSpinnerAfter = await page.evaluate(() => {
            const loadingElements = document.querySelectorAll('.loading');
            let hasSpinner = false;
            
            loadingElements.forEach(el => {
                const afterStyles = window.getComputedStyle(el, '::after');
                if (afterStyles.display !== 'none' && afterStyles.content !== 'none') {
                    hasSpinner = true;
                }
            });
            
            return hasSpinner;
        });

        console.log(`📊 CSS ::after spinners visible: ${hasSpinnerAfter ? 'YES' : 'NO'}`);

        // Final assessment
        const spinnerFixed = spinningElements.length === 0 && 
                           visibleLoading === 0 && 
                           !hasSpinnerAfter;

        console.log('\n📊 Spinner Fix Test Results:');
        console.log(`✅ No actively spinning elements: ${spinningElements.length === 0 ? 'YES' : 'NO'}`);
        console.log(`✅ No visible loading elements: ${visibleLoading === 0 ? 'YES' : 'NO'}`);
        console.log(`✅ No CSS spinner after elements: ${!hasSpinnerAfter ? 'YES' : 'NO'}`);
        console.log(`✅ Booking cards not loading: ${bookingCardLoading === 0 ? 'YES' : 'NO'}`);

        console.log(`\n🎯 OVERALL RESULT: ${spinnerFixed ? '✅ SPINNER FIXED' : '❌ SPINNER STILL ACTIVE'}`);

        if (spinnerFixed) {
            console.log('\n🎉 SUCCESS! The persistent loading spinner has been fixed!');
            console.log('   - CSS animation disabled');
            console.log('   - Loading pseudo-elements hidden');
            console.log('   - Booking cards no longer show spinners');
        } else {
            console.log('\n🔧 Some spinning elements may still be active:');
            if (spinningElements.length > 0) console.log('   - Check actively spinning elements above');
            if (visibleLoading > 0) console.log('   - Check visible loading elements');
            if (hasSpinnerAfter) console.log('   - Check CSS ::after pseudo-elements');
        }

        await page.waitForTimeout(3000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    testSpinnerFix().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { testSpinnerFix };