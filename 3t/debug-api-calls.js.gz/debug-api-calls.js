/**
 * Debug API Calls - Monitor actual HTTP requests and responses
 */
const { chromium } = require('playwright');

async function debugAPICalls() {
    console.log('🔍 Debugging API Calls for Add-on Persistence');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        // Monitor network requests
        page.on('request', request => {
            if (request.url().includes('/api/admin/bookings') && request.method() === 'PUT') {
                console.log('\n📡 PUT REQUEST to backend:');
                console.log(`URL: ${request.url()}`);
                console.log(`Method: ${request.method()}`);
                const postData = request.postData();
                if (postData) {
                    try {
                        const data = JSON.parse(postData);
                        console.log(`special_requests: "${data.special_requests}"`);
                        console.log(`clear_addons: ${data.clear_addons}`);
                        console.log(`force_addons_update: ${data.force_addons_update}`);
                    } catch (e) {
                        console.log('Raw post data:', postData);
                    }
                }
            }
        });
        
        page.on('response', response => {
            if (response.url().includes('/api/admin/bookings') && response.request().method() === 'PUT') {
                console.log('\n📡 PUT RESPONSE from backend:');
                console.log(`Status: ${response.status()}`);
                response.json().then(data => {
                    console.log(`Success: ${data.success}`);
                    if (data.booking) {
                        console.log(`Returned special_requests: "${data.booking.special_requests}"`);
                    }
                }).catch(e => console.log('Could not parse response JSON'));
            }
            
            if (response.url().includes('/api/admin/bookings') && response.request().method() === 'GET') {
                console.log('\n📡 GET RESPONSE from backend:');
                response.json().then(data => {
                    if (data.bookings && data.bookings.length > 0) {
                        const firstBooking = data.bookings[0];
                        console.log(`GET special_requests: "${firstBooking.special_requests}"`);
                    }
                }).catch(e => console.log('Could not parse GET response JSON'));
            }
        });
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        const bookingsExist = await page.locator('.booking-card').count();
        console.log(`📋 Found ${bookingsExist} bookings`);
        
        if (bookingsExist === 0) {
            console.log('⚠️ No bookings found, cannot test');
            return;
        }
        
        const firstBooking = await page.locator('.booking-card').first();
        
        console.log('\n📝 STEP 1: Opening edit form...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check current state
        const checkedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const specialRequestsInput = page.locator('#editSpecialRequests');
        const originalSpecialRequests = await specialRequestsInput.inputValue();
        
        console.log(`📊 Current add-ons checked: ${checkedAddons}`);
        console.log(`📋 Original special requests: "${originalSpecialRequests}"`);
        
        if (checkedAddons > 0) {
            console.log('\n🔲 STEP 2: Unchecking all add-ons...');
            
            // Uncheck all add-ons
            const checkboxes = await page.locator('#editAddonsContainer input[type="checkbox"]:checked');
            const count = await checkboxes.count();
            for (let i = 0; i < count; i++) {
                await checkboxes.nth(0).click();
                await page.waitForTimeout(300);
            }
            
            const afterUncheck = await specialRequestsInput.inputValue();
            console.log(`📋 Special requests after unchecking: "${afterUncheck}"`);
        }
        
        console.log('\n💾 STEP 3: Saving changes...');
        await page.locator('#editBookingForm button[type="submit"]').click();
        await page.waitForSelector('.alert.alert-success', { timeout: 10000 });
        console.log('✅ Save completed');
        
        // Wait for modal to close
        await page.waitForTimeout(3000);
        
        console.log('\n🔄 STEP 4: Re-opening to verify...');
        await firstBooking.locator('button:has-text("Edit")').click();
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });
        await page.waitForTimeout(1000);
        
        // Check final state
        const finalCheckedAddons = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').count();
        const finalSpecialRequests = await specialRequestsInput.inputValue();
        
        console.log(`\n📊 FINAL STATE:`);
        console.log(`Add-ons checked: ${finalCheckedAddons}`);
        console.log(`Special requests: "${finalSpecialRequests}"`);
        
        if (finalCheckedAddons > 0) {
            console.log('\n❌ PERSISTENCE ISSUE CONFIRMED');
            console.log('Add-ons are reappearing after save/reload');
            
            // List which add-ons are checked
            const checkedAddonsInfo = await page.locator('#editAddonsContainer input[type="checkbox"]:checked').all();
            for (const addon of checkedAddonsInfo) {
                const value = await addon.getAttribute('value');
                console.log(`  - Checked addon: ${value}`);
            }
        } else {
            console.log('\n✅ NO PERSISTENCE ISSUE');
            console.log('Add-ons were properly removed and stayed removed');
        }
        
    } catch (error) {
        console.error('❌ Debug failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the debug
debugAPICalls();