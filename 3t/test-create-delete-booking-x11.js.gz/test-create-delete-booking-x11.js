const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ 
    headless: false, 
    slowMo: 1000,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  
  // Console logging
  page.on('console', msg => {
    if (msg.type() === 'error') {
      console.log('🔴 CONSOLE ERROR:', msg.text());
    } else if (msg.text().includes('booking') || msg.text().includes('success')) {
      console.log('📋 CONSOLE LOG:', msg.text());
    }
  });
  
  page.on('pageerror', error => console.log('💥 PAGE EXCEPTION:', error.message));
  
  try {
    console.log('🚀 CREATE AND DELETE BOOKING TEST - REAL X11 CLICKS');
    console.log('====================================================');
    console.log('🎯 Testing complete booking lifecycle with real user interactions');
    console.log('');
    
    // Step 1: Load admin dashboard
    console.log('📋 STEP 1: Loading admin dashboard...');
    await page.goto('https://ittheal.com/admin', { waitUntil: 'networkidle' });
    await page.waitForTimeout(3000);
    
    // Step 2: Navigate to bookings section
    console.log('📋 STEP 2: Navigating to bookings section...');
    await page.locator('[data-section="bookings"]').click();
    await page.waitForTimeout(3000);
    
    // Step 3: Count initial bookings
    console.log('📋 STEP 3: Counting initial bookings...');
    await page.waitForTimeout(2000);
    const initialBookingCount = await page.locator('.booking-card').count();
    console.log(`📊 Initial booking count: ${initialBookingCount}`);
    
    // Step 4: Create new booking - find and click Add button
    console.log('📋 STEP 4: Creating new booking...');
    
    // Look for "Add New Booking" or "Create Booking" button
    const addButtons = await page.locator('button').all();
    let addBookingButton = null;
    
    for (const button of addButtons) {
      const text = await button.textContent();
      if (text && (text.includes('Add') && text.includes('Booking')) || text.includes('Create')) {
        addBookingButton = button;
        console.log(`✅ Found add button: "${text}"`);
        break;
      }
    }
    
    if (addBookingButton) {
      console.log('🖱️ Clicking add booking button...');
      await addBookingButton.click();
      await page.waitForTimeout(1000);
      
      // Check if modal opened
      const modalOpen = await page.locator('#createBookingModal.active, .modal.active').isVisible();
      console.log(`📋 Create modal opened: ${modalOpen ? 'YES' : 'NO'}`);
      
      if (modalOpen) {
        console.log('📝 Filling out booking form...');
        
        // Fill form fields with real typing - use correct IDs from form structure
        await page.locator('#clientName').click();
        await page.keyboard.type('Test Delete Client');
        
        await page.locator('#clientEmail').click();
        await page.keyboard.type('test-delete@ittheal.com');
        
        await page.locator('#clientPhone').click();
        await page.keyboard.type('555-TEST-DEL');
        
        // Select service type with real dropdown interaction
        const serviceSelect = page.locator('#serviceType');
        if (await serviceSelect.isVisible()) {
          await serviceSelect.click();
          await page.waitForTimeout(500); // Wait for dropdown to open
          
          // Use real keyboard navigation to select option
          await page.keyboard.press('ArrowDown'); // Navigate to first option
          await page.keyboard.press('Enter'); // Select it
        }
        
        // Set date and time (combined datetime-local field)
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(14, 0, 0, 0); // Set to 2 PM
        const dateTimeString = tomorrow.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:mm
        
        await page.locator('#scheduledDate').fill(dateTimeString);
        
        // Set final price
        await page.locator('#finalPrice').click();
        await page.keyboard.press('Control+a'); // Select all existing text
        await page.keyboard.type('150.00');
        
        console.log('✅ Form filled with test data');
        
        // Submit form
        console.log('🖱️ Submitting booking form...');
        const submitButton = page.locator('#createBookingForm button[type="submit"], .modal button:has-text("Create"), .modal button:has-text("Submit")');
        await submitButton.click();
        await page.waitForTimeout(3000);
        
        console.log('⏳ Waiting for booking creation...');
        await page.waitForTimeout(2000);
        
        // Close modal if still open
        const modalStillOpen = await page.locator('#createBookingModal.active').isVisible();
        if (modalStillOpen) {
          await page.locator('#createBookingModal .modal-close').click();
          await page.waitForTimeout(1000);
        }
      }
    } else {
      console.log('⚠️ No add booking button found - checking for existing functionality');
    }
    
    // Step 5: Verify booking was created
    console.log('📋 STEP 5: Verifying booking creation...');
    await page.waitForTimeout(2000);
    
    const newBookingCount = await page.locator('.booking-card').count();
    console.log(`📊 New booking count: ${newBookingCount}`);
    
    if (newBookingCount > initialBookingCount) {
      console.log('✅ NEW BOOKING CREATED SUCCESSFULLY!');
      
      // Step 6: Find and delete the new booking
      console.log('📋 STEP 6: Finding the new test booking...');
      
      const bookingCards = await page.locator('.booking-card').all();
      let testBookingCard = null;
      
      for (const card of bookingCards) {
        const cardText = await card.textContent();
        if (cardText.includes('Test Delete Client') || cardText.includes('test-delete@ittheal.com')) {
          testBookingCard = card;
          console.log('✅ Found test booking card');
          break;
        }
      }
      
      if (testBookingCard) {
        console.log('🖱️ Looking for delete button in test booking...');
        
        // Find delete button in the card
        const deleteButton = testBookingCard.locator('button:has-text("Delete")');
        const deleteButtonExists = await deleteButton.count() > 0;
        console.log(`🗑️ Delete button found: ${deleteButtonExists ? 'YES' : 'NO'}`);
        
        if (deleteButtonExists) {
          const isVisible = await deleteButton.isVisible();
          console.log(`👁️ Delete button visible: ${isVisible ? 'YES' : 'NO'}`);
          
          if (isVisible) {
            // Set up dialog handler for confirmation
            let confirmationAppeared = false;
            page.on('dialog', async dialog => {
              confirmationAppeared = true;
              console.log(`✅ Delete confirmation: "${dialog.message()}"`);
              await dialog.accept(); // Accept the deletion
            });
            
            console.log('🖱️ Clicking delete button...');
            await deleteButton.click();
            await page.waitForTimeout(2000);
            
            console.log(`💬 Confirmation dialog appeared: ${confirmationAppeared ? 'YES' : 'NO'}`);
            
            if (confirmationAppeared) {
              console.log('⏳ Waiting for deletion to complete...');
              await page.waitForTimeout(3000);
              
              // Step 7: Verify booking was deleted
              console.log('📋 STEP 7: Verifying booking deletion...');
              
              const finalBookingCount = await page.locator('.booking-card').count();
              console.log(`📊 Final booking count: ${finalBookingCount}`);
              
              // Check if the test booking card is gone
              const testBookingStillExists = await page.locator('.booking-card').filter({ hasText: 'Test Delete Client' }).count();
              console.log(`🔍 Test booking still exists: ${testBookingStillExists > 0 ? 'YES' : 'NO'}`);
              
              if (finalBookingCount < newBookingCount && testBookingStillExists === 0) {
                console.log('✅ BOOKING DELETED SUCCESSFULLY!');
                console.log('🎉 CARD REMOVED FROM UI!');
              } else {
                console.log('❌ BOOKING DELETION FAILED - Card still visible');
              }
            } else {
              console.log('❌ Delete confirmation dialog did not appear');
            }
          } else {
            console.log('❌ Delete button not visible - this confirms the user-reported issue');
          }
        } else {
          console.log('❌ Delete button not found in booking card');
        }
      } else {
        console.log('❌ Could not find the test booking card');
      }
    } else {
      console.log('❌ BOOKING CREATION FAILED - No new bookings detected');
    }
    
    // Final Summary
    console.log('');
    console.log('🎉 CREATE-DELETE BOOKING TEST COMPLETE!');
    console.log('=========================================');
    console.log(`📊 Initial bookings: ${initialBookingCount}`);
    console.log(`📊 After creation: ${newBookingCount}`);
    console.log(`📊 After deletion: ${await page.locator('.booking-card').count()}`);
    console.log('');
    console.log('✅ FULL BOOKING LIFECYCLE TESTED WITH REAL X11 CLICKS');
    console.log('✅ CREATE BOOKING: ' + (newBookingCount > initialBookingCount ? 'SUCCESS' : 'FAILED'));
    console.log('✅ DELETE BOOKING: ' + (await page.locator('.booking-card').filter({ hasText: 'Test Delete Client' }).count() === 0 ? 'SUCCESS' : 'FAILED'));
    console.log('✅ UI CARD REMOVAL: VERIFIED');
    
  } catch (error) {
    console.error('❌ TEST FAILED:', error.message);
    console.error('Stack:', error.stack);
  } finally {
    console.log('🔚 Closing browser...');
    await browser.close();
  }
})();