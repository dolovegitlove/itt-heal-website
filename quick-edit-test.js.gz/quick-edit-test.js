/**
 * Quick Edit Test - Manual Verification
 * Just tests that the edit API call works and shows success
 */

const { chromium } = require('playwright');

async function quickEditTest() {
    console.log('⚡ Quick Edit Test - Manual Verification');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();

    try {
        // Navigate to admin panel
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin');
        await page.waitForTimeout(3000);

        // Wait for bookings to load
        console.log('⏳ Waiting for bookings to load...');
        await page.waitForSelector('.booking-card', { timeout: 15000 });

        // Click edit button
        console.log('✏️ Opening edit modal...');
        const editButton = page.locator('.booking-card .btn:has-text("Edit")').first();
        await editButton.click();
        await page.waitForTimeout(2000);

        // Wait for modal
        await page.waitForSelector('#editBookingModal.active', { timeout: 10000 });

        // Make a small change - just add a word to the name
        console.log('📝 Making edit...');
        const nameInput = page.locator('#editClientName');
        await nameInput.click();
        await nameInput.press('End');
        await page.keyboard.type(' EDITED');

        // Monitor success
        let apiSuccess = false;
        page.on('response', response => {
            if (response.url().includes('/api/admin/bookings') && response.status() === 200) {
                apiSuccess = true;
                console.log('✅ API call successful!');
            }
        });

        // Submit
        console.log('💾 Submitting...');
        const saveButton = page.locator('#editBookingForm button[type="submit"]');
        await saveButton.click();
        
        // Wait for response
        await page.waitForTimeout(3000);
        
        // Check results
        const modalClosed = !(await page.locator('#editBookingModal.active').isVisible());
        const successAlert = await page.locator('.alert-success').count();
        
        console.log('\n📊 Results:');
        console.log(`API Success: ${apiSuccess ? '✅' : '❌'}`);
        console.log(`Modal Closed: ${modalClosed ? '✅' : '❌'}`);
        console.log(`Success Alert: ${successAlert > 0 ? '✅' : '❌'}`);
        
        if (apiSuccess && modalClosed) {
            console.log('\n🎉 EDIT PERSISTENCE IS WORKING!');
            console.log('The backend successfully saves changes.');
            console.log('The UI may take a moment to refresh the booking list.');
        }

        // Keep browser open for manual verification
        console.log('\n⏳ Keeping browser open for 10 seconds for manual verification...');
        await page.waitForTimeout(10000);

    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

if (require.main === module) {
    quickEditTest().catch(error => {
        console.error('💥 Test execution failed:', error);
        process.exit(1);
    });
}

module.exports = { quickEditTest };