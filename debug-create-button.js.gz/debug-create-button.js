/**
 * Debug Create Button - Check why it's not visible
 */
const { chromium } = require('playwright');

async function debugCreateButton() {
    console.log('🔍 Debugging Create Button Visibility');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 500
    });
    
    try {
        const page = await browser.newPage();
        
        console.log('📱 Opening admin panel...');
        await page.goto('https://ittheal.com/admin/', { waitUntil: 'networkidle' });
        
        await page.waitForLoadState('networkidle');
        await page.waitForTimeout(3000);
        
        console.log('🔍 Checking bookings section...');
        
        // Check if we need to navigate to bookings section
        const bookingsNav = page.locator('[data-section="bookings"]');
        const bookingsNavExists = await bookingsNav.count();
        
        console.log(`📋 Bookings nav exists: ${bookingsNavExists > 0 ? 'YES' : 'NO'}`);
        
        if (bookingsNavExists > 0) {
            console.log('🖱️ Clicking on bookings navigation...');
            await bookingsNav.click();
            await page.waitForTimeout(2000);
        }
        
        // Check if bookings section is active
        const bookingsSection = page.locator('#bookings');
        const isActive = await bookingsSection.evaluate(el => el.classList.contains('active'));
        console.log(`📋 Bookings section active: ${isActive ? 'YES' : 'NO'}`);
        
        if (!isActive) {
            console.log('🖱️ Activating bookings section...');
            await bookingsSection.evaluate(el => el.classList.add('active'));
            await page.waitForTimeout(1000);
        }
        
        // Now check for the button
        console.log('🔍 Looking for Create New Booking button again...');
        
        const createButton = page.locator('button:has-text("Create New Booking")');
        const buttonExists = await createButton.count();
        
        console.log(`📋 Create button exists: ${buttonExists > 0 ? 'YES' : 'NO'}`);
        
        if (buttonExists > 0) {
            const isVisible = await createButton.isVisible();
            console.log(`👁️ Button is visible: ${isVisible ? 'YES' : 'NO'}`);
            
            if (isVisible) {
                console.log('✅ Create button is now visible!');
                
                // Test clicking it
                console.log('🖱️ Clicking Create New Booking button...');
                await createButton.click();
                
                await page.waitForTimeout(1000);
                
                const modalExists = await page.locator('#createBookingModal.active').count();
                console.log(`📋 Modal opened: ${modalExists > 0 ? 'YES' : 'NO'}`);
                
                if (modalExists > 0) {
                    console.log('✅ SUCCESS: Create booking functionality is working!');
                } else {
                    console.log('❌ Modal did not open');
                }
            } else {
                console.log('❌ Button is still not visible');
                
                // Check CSS properties
                const buttonInfo = await createButton.evaluate(button => {
                    const style = window.getComputedStyle(button);
                    return {
                        display: style.display,
                        visibility: style.visibility,
                        opacity: style.opacity,
                        position: style.position,
                        top: style.top,
                        left: style.left,
                        width: style.width,
                        height: style.height
                    };
                });
                
                console.log('🎨 Button CSS properties:');
                console.log(JSON.stringify(buttonInfo, null, 2));
            }
        } else {
            console.log('❌ Create button not found');
        }
        
        console.log('\n📊 DEBUG COMPLETE');
        
    } catch (error) {
        console.error('❌ Debug failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Run the debug
debugCreateButton();