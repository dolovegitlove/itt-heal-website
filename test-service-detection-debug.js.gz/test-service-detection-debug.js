/**
 * SERVICE DETECTION DEBUG TEST
 * Quick test to verify service selection is working
 */

const { chromium } = require('playwright');

async function testServiceDetection() {
    console.log('🔍 Testing Service Detection...');
    
    const browser = await chromium.launch({
        headless: false,
        slowMo: 1000,
        args: ['--window-size=1920,1080', '--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security']
    });

    const page = await browser.newPage();
    
    // Capture console for debug info
    page.on('console', msg => {
        if (msg.text().includes('🔍 Debug:')) {
            console.log(`   ${msg.text()}`);
        }
    });
    
    try {
        await page.goto('https://ittheal.com', { waitUntil: 'networkidle' });
        await page.waitForTimeout(2000);
        
        await page.locator('#booking').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        console.log('📍 Select 60-minute service...');
        await page.locator('.service-option[data-service="60min"]').click();
        await page.waitForTimeout(1000);
        
        console.log('📍 Check service selection state...');
        const serviceState = await page.evaluate(() => {
            const active = document.querySelector('.service-option.active');
            return {
                found: !!active,
                dataService: active?.dataset?.service,
                dataServiceAttr: active?.getAttribute('data-service'),
                dataServiceType: active?.dataset?.serviceType,
                dataServiceTypeAttr: active?.getAttribute('data-service-type'),
                className: active?.className
            };
        });
        
        console.log('   Service state:', JSON.stringify(serviceState, null, 2));
        
        console.log('📍 Click Next...');
        await page.locator('#next-btn').click();
        await page.waitForTimeout(2000);
        
        console.log('📍 Enter valid date to trigger API call...');
        const dateInput = page.locator('#booking-date');
        await dateInput.click();
        await page.waitForTimeout(300);
        
        await page.keyboard.press('Control+a');
        await page.waitForTimeout(200);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(200);
        
        await page.keyboard.type('2025-07-14');
        await page.waitForTimeout(500);
        await page.keyboard.press('Tab');
        
        console.log('📍 Wait for debug output...');
        await page.waitForTimeout(5000);
        
        console.log('✅ Service detection test completed');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

// Execute
if (require.main === module) {
    testServiceDetection()
        .then(() => process.exit(0))
        .catch(() => process.exit(1));
}

module.exports = { testServiceDetection };