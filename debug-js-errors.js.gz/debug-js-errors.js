const { chromium } = require('playwright');

(async () => {
  console.log('🔍 Debugging JavaScript errors during step transition...');
  
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  
  // Track all console messages and errors
  const logs = [];
  page.on('console', msg => {
    const logEntry = `[${msg.type().toUpperCase()}] ${msg.text()}`;
    logs.push(logEntry);
    console.log('PAGE:', logEntry);
  });
  
  page.on('pageerror', error => {
    const errorEntry = `[PAGEERROR] ${error.message}`;
    logs.push(errorEntry);
    console.log('ERROR:', errorEntry);
  });
  
  // Track uncaught exceptions
  page.on('requestfailed', request => {
    console.log('REQUEST FAILED:', request.url(), request.failure()?.errorText);
  });
  
  await page.goto('https://ittheal.com');
  await page.waitForLoadState('networkidle');
  
  console.log('📊 Initial page loaded');
  
  // Step 1: Service selection
  console.log('🎯 Step 1: Service selection');
  await page.click('[data-service="90min"]');
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 2: Date/time
  console.log('📅 Step 2: Date/time selection');
  await page.fill('#booking-date', '2025-07-14');
  await page.waitForTimeout(3000);
  await page.selectOption('#booking-time', { index: 1 });
  await page.click('#next-btn');
  await page.waitForTimeout(2000);
  
  // Step 3: Client info  
  console.log('👤 Step 3: Client information');
  await page.fill('#client-name', 'Test User');
  await page.fill('#client-email', 'test@example.com');
  await page.fill('#client-phone', '555-123-4567');
  
  console.log('📋 About to click Next button in step 3...');
  
  // Add debugging to the transitionStep function
  await page.evaluate(() => {
    // Override transitionStep to add debugging
    const originalTransitionStep = window.transitionStep;
    if (originalTransitionStep) {
      window.transitionStep = async function(hideElementId, showElementId) {
        console.log('transitionStep called:', hideElementId, '->', showElementId);
        
        const hideElement = document.getElementById(hideElementId);
        const showElement = document.getElementById(showElementId);
        
        console.log('hideElement found:', !!hideElement);
        console.log('showElement found:', !!showElement);
        
        if (!hideElement) console.error('Missing hideElement:', hideElementId);
        if (!showElement) console.error('Missing showElement:', showElementId);
        
        try {
          const result = await originalTransitionStep(hideElementId, showElementId);
          console.log('transitionStep completed successfully');
          return result;
        } catch (error) {
          console.error('transitionStep error:', error);
          throw error;
        }
      };
    } else {
      console.error('transitionStep function not found!');
    }
    
    // Also check the nextStep function
    const nextBtn = document.getElementById('next-btn');
    if (nextBtn) {
      console.log('next-btn found, checking event listeners...');
      // Log when next button is clicked
      nextBtn.addEventListener('click', (e) => {
        console.log('Next button click event fired');
        console.log('Current step before processing:', window.currentStep);
      });
    }
  });
  
  await page.click('#next-btn');
  await page.waitForTimeout(5000); // Wait longer to see all logs
  
  console.log('🔍 All logs collected:');
  logs.forEach(log => console.log('  ', log));
  
  await browser.close();
})().catch(console.error);