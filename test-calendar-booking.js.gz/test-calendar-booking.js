/**
 * Real User Interaction Test for Calendar Booking
 * Tests the new Calendly-style calendar interface
 */

const { chromium } = require('playwright');

async function testCalendarBooking() {
    const browser = await chromium.launch({
        headless: false,
        slowMo: 500,
        args: [
            '--window-size=1920,1080',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await browser.newPage();
    
    try {
        console.log('🧪 Starting Calendar Booking UI Test...');
        
        // Navigate to booking page
        await page.goto('https://ittheal.com', { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(2000);
        
        // Scroll to booking section
        await page.locator('#services').scrollIntoViewIfNeeded();
        await page.waitForTimeout(1000);
        
        console.log('✅ Step 1: Select service (90min - Most Popular)');
        await page.locator('.service-option[data-service="90min"]').click();
        await page.waitForTimeout(1000);
        
        // Verify Step 2 appears with calendar
        const calendarContainer = page.locator('#calendar-container');
        await calendarContainer.waitFor({ state: 'visible', timeout: 5000 });
        console.log('✅ Step 2: Calendar container is visible');
        
        // Test calendar navigation
        console.log('🗓️  Testing calendar navigation...');
        const currentMonth = await page.locator('#current-month').textContent();
        console.log(`Current month displayed: ${currentMonth}`);
        
        // Click next month
        await page.locator('#next-month').click();
        await page.waitForTimeout(500);
        const nextMonth = await page.locator('#current-month').textContent();
        console.log(`After next click: ${nextMonth}`);
        
        // Go back to current month
        await page.locator('#prev-month').click();
        await page.waitForTimeout(500);
        
        // Find and click an available date (business day)
        console.log('📅 Testing date selection...');
        
        // Look for clickable date buttons (not disabled)
        const availableDates = page.locator('.calendar-date:not([disabled])');
        const dateCount = await availableDates.count();
        console.log(`Found ${dateCount} available dates`);
        
        if (dateCount > 0) {
            // Click the first available date
            await availableDates.first().click();
            await page.waitForTimeout(1000);
            
            // Verify time slots section appears
            const timeSlotsSection = page.locator('#time-slots-section');
            await timeSlotsSection.waitFor({ state: 'visible', timeout: 10000 });
            console.log('✅ Time slots section appeared');
            
            // Wait for time slots to load
            await page.waitForTimeout(3000);
            
            // Check if time slots loaded
            const timeSlots = page.locator('.time-slot-button');
            const timeSlotCount = await timeSlots.count();
            console.log(`Found ${timeSlotCount} available time slots`);
            
            if (timeSlotCount > 0) {
                // Click first available time slot
                await timeSlots.first().click();
                await page.waitForTimeout(1000);
                
                // Verify hidden inputs are populated
                const selectedDate = await page.locator('#booking-date').inputValue();
                const selectedTime = await page.locator('#booking-time').inputValue();
                
                console.log(`✅ Date selected: ${selectedDate}`);
                console.log(`✅ Time selected: ${selectedTime}`);
                
                if (selectedDate && selectedTime) {
                    console.log('🎉 Calendar booking test PASSED - Date and time selected successfully');
                    return true;
                } else {
                    console.log('❌ Hidden inputs not populated properly');
                    return false;
                }
            } else {
                console.log('⚠️  No time slots available for selected date');
                return true; // This is acceptable - depends on availability
            }
        } else {
            console.log('❌ No available dates found in calendar');
            return false;
        }
        
    } catch (error) {
        console.error('❌ Calendar booking test failed:', error);
        return false;
    } finally {
        await browser.close();
    }
}

async function testMobileResponsive() {
    const browser = await chromium.launch({
        headless: false,
        slowMo: 300
    });

    const page = await browser.newPage();
    
    try {
        // Set mobile viewport
        await page.setViewportSize({ width: 375, height: 667 });
        
        console.log('📱 Testing mobile responsive calendar...');
        
        await page.goto('https://ittheal.com', { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(2000);
        
        // Test calendar on mobile
        await page.locator('#services').scrollIntoViewIfNeeded();
        await page.locator('.service-option[data-service="90min"]').click();
        await page.waitForTimeout(1000);
        
        const calendarGrid = page.locator('#calendar-grid');
        await calendarGrid.waitFor({ state: 'visible' });
        
        // Check if calendar is properly sized for mobile
        const gridBox = await calendarGrid.boundingBox();
        console.log(`Calendar grid width on mobile: ${gridBox.width}px`);
        
        if (gridBox.width <= 375) {
            console.log('✅ Mobile responsive test PASSED');
            return true;
        } else {
            console.log('❌ Calendar too wide for mobile');
            return false;
        }
        
    } catch (error) {
        console.error('❌ Mobile responsive test failed:', error);
        return false;
    } finally {
        await browser.close();
    }
}

async function runAllTests() {
    console.log('🚀 Starting Calendar Booking Test Suite...\n');
    
    const desktopResult = await testCalendarBooking();
    console.log('\n' + '='.repeat(50) + '\n');
    
    const mobileResult = await testMobileResponsive();
    
    console.log('\n' + '='.repeat(50));
    console.log('📊 TEST RESULTS:');
    console.log(`Desktop Calendar: ${desktopResult ? '✅ PASS' : '❌ FAIL'}`);
    console.log(`Mobile Responsive: ${mobileResult ? '✅ PASS' : '❌ FAIL'}`);
    console.log('='.repeat(50));
    
    if (desktopResult && mobileResult) {
        console.log('🎉 All calendar booking tests PASSED!');
        process.exit(0);
    } else {
        console.log('❌ Some tests failed. Please review and fix issues.');
        process.exit(1);
    }
}

// Run tests
runAllTests().catch(error => {
    console.error('Test suite failed:', error);
    process.exit(1);
});