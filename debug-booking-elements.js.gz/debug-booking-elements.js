const { chromium } = require('playwright');

async function debugElements() {
  console.log('🔍 Debugging booking form elements...\n');
  
  const browser = await chromium.launch({
    headless: true, // Use headless for VPS
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage'
    ]
  });

  try {
    const context = await browser.newContext({
      viewport: { width: 1920, height: 1080 }
    });

    const page = await context.newPage();

    console.log('📊 Loading ITT website...');
    await page.goto('https://ittheal.com');
    await page.waitForLoadState('networkidle');
    
    console.log('✅ Page loaded successfully\n');

    // Check for service options
    console.log('🔍 Looking for service options...');
    const serviceOptions = await page.$$('.service-option');
    console.log(`   Found ${serviceOptions.length} service options`);
    
    for (let i = 0; i < serviceOptions.length; i++) {
      const option = serviceOptions[i];
      const text = await option.textContent();
      const dataService = await option.getAttribute('data-service');
      console.log(`   ${i + 1}. Text: "${text?.trim()}" | data-service: "${dataService}"`);
    }

    // Check for booking form elements
    console.log('\n🔍 Looking for booking form elements...');
    
    const elements = [
      '#booking-date',
      '#booking-time', 
      '#time-loading',
      '#next-btn',
      '#datetime-selection',
      '.service-selection',
      '#service-selection'
    ];

    for (const selector of elements) {
      const element = await page.$(selector);
      const isVisible = element ? await element.isVisible() : false;
      console.log(`   ${selector}: ${element ? '✅ exists' : '❌ missing'} ${isVisible ? '(visible)' : '(hidden)'}`);
    }

    // Check current step visibility
    console.log('\n🔍 Checking step visibility...');
    const steps = [
      '#service-selection',
      '#datetime-selection', 
      '#contact-info',
      '#payment-info',
      '#booking-summary'
    ];

    for (const step of steps) {
      const element = await page.$(step);
      const isVisible = element ? await element.isVisible() : false;
      const display = element ? await element.evaluate(el => getComputedStyle(el).display) : 'none';
      console.log(`   ${step}: ${element ? '✅ exists' : '❌ missing'} | display: ${display} | visible: ${isVisible}`);
    }

    console.log('\n📸 Taking screenshot for analysis...');
    await page.screenshot({ path: 'booking-debug.png', fullPage: true });
    console.log('   Screenshot saved as booking-debug.png');

  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  } finally {
    await browser.close();
  }
}

// Run the debug
debugElements().catch(console.error);